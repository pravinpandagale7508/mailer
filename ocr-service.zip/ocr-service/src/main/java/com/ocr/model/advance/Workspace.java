package com.ocr.model.advance;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.ocr.utils.HashMapConverterForBlob;
import com.ocr.utils.ListConverter;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "workspace")
@Data
@NoArgsConstructor
public class Workspace {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;
	
	@Column(name = "name" ,unique = true)
	private String name;
	
	@Column(name = "user_id" )
	private long userId;
	
	@Column(name = "trash" )
	private boolean trash = false;
	
	@Column(name = "created" )
	private long created;
	
	@Column(name = "updated" )
	private long updated;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object>  templateJson;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object>  ocrJson = new HashMap<>();
	// lis of obj {}
	@Convert(converter = ListConverter.class)
	private List<Map<String, Object>>  ocrJsonList;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> params;

	public Workspace(String name,long userId, long created, long updated, Map<String, Object> templateJson,
			List<Map<String, Object>> ocrJson, Map<String, Object> params,boolean trash) {
		super();
		this.name = name;
		this.userId = userId;
		this.created = created;
		this.updated = updated;
		this.templateJson = templateJson;
		this.ocrJsonList = ocrJson;
		this.params = params;
		this.trash = trash;
	}
	
	
	
	
}
