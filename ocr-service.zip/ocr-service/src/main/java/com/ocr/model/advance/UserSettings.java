package com.ocr.model.advance;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ocr.utils.HashMapConverterForBlob;

import lombok.Data;

@Entity
@Table(name = "user_settings")
@Data
public class UserSettings {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;
	
	@Column(name = "user_id" )
	private long userId;
	
	@Column(name = "num_scans" )
	private long numberOfScans;
	
	@Column(name = "created" )
	private long created;
	
	@Column(name = "updated" )
	private long updated;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> params;
	
}
