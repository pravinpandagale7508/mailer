package com.ocr.model.advance;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ocr.utils.HashMapConverterForBlob;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Template")
@Data
@NoArgsConstructor
public class Template {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;

	@Column(name = "user_id")
	private long userId;
	
	@Column(name = "template_name")
	private String name;
	
	@Column(name = "created" )
	private long created;
	
	@Column(name = "updated" )
	private long updated;
	
	@Column(name = "trash" )
	private boolean trash;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> templateJson;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> params;

	public Template(long user_id, String templateName, long created, long updated, Map<String, Object> templateJson,
			Map<String, Object> params,boolean trash) {
		super();
		this.userId = user_id;
		this.name = templateName;
		this.created = created;
		this.updated = updated;
		this.templateJson = templateJson;
		this.params = params;
		this.trash = trash;
	}

	
	
	
}
