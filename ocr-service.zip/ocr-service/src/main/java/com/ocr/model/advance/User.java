package com.ocr.model.advance;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ocr.utils.HashMapConverterForBlob;

import lombok.Data;

@Entity
@Table(name = "user")
@Data
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private long id;
	
	@Column(name = "manager_id")
	private long managerId;
	
	@Column(name = "api_key" ,unique = true)
	private String apiKey;
	
	@Column(name = "user_name" ,unique = true)
	private String userName;
	
	@Column(name = "password" )
	private String password;
	
	@Column(name = "email" ,unique = true)
	private String email;
	
	@Column(name = "mobile" )
	private String mobile;
	
	@Column(name = "created" )
	private long created;
	
	@Column(name = "updated" )
	private long updated;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> params;
	
}
