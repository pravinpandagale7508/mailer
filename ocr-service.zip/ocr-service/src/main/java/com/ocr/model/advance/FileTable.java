package com.ocr.model.advance;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.ocr.utils.HashMapConverterForBlob;
import com.ocr.utils.ListConverter;

import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "file_table")
@NoArgsConstructor
@Data
public class FileTable {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO) 
	@Column(name = "id")
	private long id;
	
	@Column(name = "wid")
	private long wid;

	@Column(name = "file_name")
	private String fileName;
	
	@Lob
	@Column(name = "uploaded_file")
	private byte[] uploadedFile;
	
	@Column(name = "user_id")
	private long user_id;
	
	@Column(name = "page_width")
	private double page_width;
	
	@Column(name = "page_height")
	private double page_height;
	
	@Convert(converter = ListConverter.class)
	@Column(name = "list")
	private List<Map<String, Object>> list;
	
	@Column(name = "orglist")
	@Convert(converter = ListConverter.class)
	private List<Map<String, Object>> orglist;
	
	@Convert(converter = HashMapConverterForBlob.class)
	private Map<String, Object> params;


	public FileTable(long wid, String fileName, byte[] bytes, long userId, double width, double height,
			List<Map<String, Object>> list, List<Map<String, Object>> orglist,
			HashMap params2) {
		// TODO Auto-generated constructor stub
		super();
		this.wid = wid;
		this.fileName = fileName;
		this.uploadedFile = bytes;
		this.user_id = userId;
		this.page_width = width;
		this.page_height = height;
		this.list = list;
		this.orglist = orglist;
		
	}

	

	
	
	
}
