package com.ocr.utils;

import java.io.ByteArrayOutputStream;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.PumpStreamHandler;

public class ScriptUtils {
	/*
	 * public static void runPythonScript() throws Exception { StringWriter writer =
	 * new StringWriter(); ScriptContext context = new SimpleScriptContext();
	 * context.setWriter(writer); Options.importSite = false; ScriptEngineManager
	 * manager = new ScriptEngineManager(); List<ScriptEngineFactory> factories =
	 * manager.getEngineFactories(); ScriptEngine engine; for (ScriptEngineFactory
	 * factory : factories) { if (factory.getEngineName().equals("jython")) { engine
	 * = factory.getScriptEngine(); break; } } engine =
	 * manager.getEngineByName("python"); engine.eval(new FileReader("Test.py"),
	 * context); }
	 */
	public static int runPythonScript(String command,String pythonFileName,String pdfName,String templateName,String docName) throws Exception {
		/*String line = command+" " + pythonFileName+" "+pdfName+" "+templateName+" "+docName;
		CommandLine cmdLine = CommandLine.parse(line);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		PumpStreamHandler streamHandler = new PumpStreamHandler(outputStream);
		DefaultExecutor executor = new DefaultExecutor();
		executor.setStreamHandler(streamHandler);
		return executor.execute(cmdLine);
		*/
		return 0;

	}
}
