package com.ocr.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.persistence.AttributeConverter;
public class ListConverter implements AttributeConverter<List<Object>, byte[]> {

	@Override
	public byte[] convertToDatabaseColumn(List<Object> arg0) {
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		ObjectOutputStream out;
		try {
			out = new ObjectOutputStream(byteOut);
			out.writeObject(arg0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return byteOut.toByteArray();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object> convertToEntityAttribute(byte[] arg0) {
		ByteArrayInputStream byteIn = new ByteArrayInputStream(arg0);
	    ObjectInputStream in;
	    List<Object> data2 = null;
		try {
			in = new ObjectInputStream(byteIn);
			data2 = (List<Object> ) in.readObject();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data2;
	}

}
