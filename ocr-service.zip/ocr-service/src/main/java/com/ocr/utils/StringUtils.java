package com.ocr.utils;

public class StringUtils {

	public static String getFileNameWithOutExtension(String fileName) {
		return fileName.substring(0,fileName.indexOf('.'));
	}

	public static String getFileName(int id, String fileName) {
		return fileName.substring(0,fileName.indexOf("."))+id+fileName.substring(fileName.indexOf("."));
	}
}
