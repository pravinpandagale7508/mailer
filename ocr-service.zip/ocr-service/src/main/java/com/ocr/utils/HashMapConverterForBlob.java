package com.ocr.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Map;

import javax.persistence.AttributeConverter;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

public class HashMapConverterForBlob implements AttributeConverter<Map<String, Object>, Blob> {

	@Override
	public Blob convertToDatabaseColumn(Map<String, Object> arg0) {
		ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
		ObjectOutputStream out;
		Blob blob = null;

		try {
			out = new ObjectOutputStream(byteOut);
			out.writeObject(arg0);
			blob = new SerialBlob(byteOut.toByteArray());
		} catch (SerialException e) {
			e.printStackTrace();
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return blob;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Object> convertToEntityAttribute(Blob blob) {

		ByteArrayInputStream byteIn = null;
		try {
			byteIn = new ByteArrayInputStream(blob.getBytes(1, (int) blob.length()));
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ObjectInputStream in;
		Map<String, Object> data2 = null;
		try {
			in = new ObjectInputStream(byteIn);
			data2 = (Map<String, Object>) in.readObject();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data2;
	}

}
