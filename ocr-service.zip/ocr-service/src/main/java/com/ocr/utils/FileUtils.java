package com.ocr.utils;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Comparator;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.ImageType;
import org.apache.pdfbox.rendering.PDFRenderer;
import org.apache.pdfbox.tools.imageio.ImageIOUtil;
import org.springframework.web.multipart.MultipartFile;

import com.adobe.pdfservices.operation.ExecutionContext;
import com.adobe.pdfservices.operation.auth.Credentials;
import com.adobe.pdfservices.operation.exception.SdkException;
import com.adobe.pdfservices.operation.exception.ServiceApiException;
import com.adobe.pdfservices.operation.exception.ServiceUsageException;
import com.adobe.pdfservices.operation.io.FileRef;
import com.adobe.pdfservices.operation.pdfops.ExportPDFOperation;
import com.adobe.pdfservices.operation.pdfops.OCROperation;
import com.adobe.pdfservices.operation.pdfops.options.exportpdf.ExportPDFTargetFormat;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class FileUtils {
	public static ByteArrayOutputStream generateDocFile(InputStream inputStream, String fileName) {

		try {

			// Initial setup, create credentials instance.
			Credentials credentials = Credentials.serviceAccountCredentialsBuilder()
					.fromFile("pdfservices-api-credentials.json").build();
			ExecutionContext executionContext = ExecutionContext.create(credentials);
			ExportPDFOperation exportPdfOperation = ExportPDFOperation.createNew(ExportPDFTargetFormat.DOCX);
			FileRef sourceFileRef = FileRef.createFromStream(inputStream, "application/pdf");
			exportPdfOperation.setInput(sourceFileRef);
			// Execute the operation.
			FileRef result = exportPdfOperation.execute(executionContext);
			ByteArrayOutputStream oStream = new ByteArrayOutputStream();
			result.saveAs(oStream);
			return oStream;
		} catch (ServiceApiException | IOException | SdkException | ServiceUsageException ex) {
			return null;
		}
	}
	
	 public static File[] convertPdf2Png(File inputPdfFile) throws IOException {
	        Path path = Files.createTempDirectory("tessimages");
	        File imageDir = path.toFile();

	        PDDocument document = null;
	        try {
	            document = PDDocument.load( inputPdfFile);
	            PDFRenderer pdfRenderer = new PDFRenderer(document);
	            for (int page = 0; page < document.getNumberOfPages(); ++page) {
	                BufferedImage bim = pdfRenderer.renderImageWithDPI(page, 300, ImageType.RGB);

	                // suffix in filename will be used as the file format
	                String filename = String.format("workingimage%04d.png", page + 1);
	                ImageIOUtil.writeImage(bim, new File(imageDir, filename).getAbsolutePath(), 300);
	            }
	        } catch (IOException ioe) {
	            //logger.error("Error extracting PDF Document => " + ioe);
	        } finally {
	            if (imageDir.list().length == 0) {
	                imageDir.delete();
	            }

	            if (document != null) {
	                try {
	                    document.close();
	                } catch (Exception e) {
	                }
	            }
	        }

	        // find working files
	        File[] workingFiles = imageDir.listFiles(new FilenameFilter() {

	            @Override
	            public boolean accept(File dir, String name) {
	                return name.toLowerCase().matches("workingimage\\d{4}\\.png$");
	            }
	        });

	        // workingFiles should be non-null here if the operation completed successfully
	        // https://docs.oracle.com/javase/7/docs/api/java/io/File.html#listFiles()
	        if (workingFiles == null) {
	            // Instead of throwing a NullPointerException, throw an IOException instead
	            // Clients of this library shouldn't be catching NullPointerExceptions thrown by this library
	            throw new IOException("Error extracting PDF Document");
	        }

	        Arrays.sort(workingFiles, new Comparator<File>() {
	            @Override
	            public int compare(File f1, File f2) {
	                return f1.getName().compareTo(f2.getName());
	            }
	        });

	        return workingFiles;
	    }
	
	public static ByteArrayOutputStream generatePdfFile(InputStream inputStream, String fileName) {

		try {

			// Initial setup, create credentials instance.
			Credentials credentials = Credentials.serviceAccountCredentialsBuilder()
					.fromFile("pdfservices-api-credentials.json").build();
            ExecutionContext executionContext = ExecutionContext.create(credentials);
            OCROperation ocrOperation = OCROperation.createNew();
            
            // Set operation input from a source file.
            FileRef source = FileRef.createFromStream(inputStream, "application/pdf");
            ocrOperation.setInput(source);

            // Execute the operation
            FileRef result = ocrOperation.execute(executionContext);
            ByteArrayOutputStream oStream = new ByteArrayOutputStream();
			result.saveAs(oStream);
			return oStream;
            
		} catch (ServiceApiException | IOException | SdkException | ServiceUsageException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	

	public static void cleanFiles(String pdfFileName, String docFileName, String templateFileName, String jsonFile) {
		File file = new File(pdfFileName);
		file.delete();
		file = new File(docFileName);
		file.delete();
		file = new File(templateFileName);
		file.delete();
		file = new File(jsonFile);
		file.delete();

		// //System.out.println("Deleted Successfully....");

	}

	public static String readFile(String fileName) throws Exception {
		String res = "";
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		String line = reader.readLine();
		while (line != null) {
			res = res + line;
			line = reader.readLine();
		}
		reader.close();
		return res;
	}

	public static void cleanFiles(String pdfFileName, String docFileName) {
		File file = new File(pdfFileName);
		if (file.exists())
			file.delete();

		file = new File(docFileName);
		if (file.exists())
			file.delete();
	}

	public static void cleanFiles(String fileName) {
		File file = new File(fileName);
		if (file.exists())
			file.delete();

	}

	public static String serializationString(Object dto) {

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
		String dtoAsString = null;
		try {
			dtoAsString = objectMapper.writeValueAsString(dto);
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		return dtoAsString;
	}
	public static File convertMultiPartToFile(MultipartFile file ) throws IOException {
	    File convFile = new File( file.getOriginalFilename() );
	    FileOutputStream fos = new FileOutputStream( convFile );
	    fos.write( file.getBytes() );
	    fos.close();
	    return convFile;
	}
}
