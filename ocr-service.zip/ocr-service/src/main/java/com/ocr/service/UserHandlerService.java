/**
 * 
 */
package com.ocr.service;

import com.ocr.dto.ResponseDto;
import com.ocr.model.advance.User;

/**
 * @author User
 *
 */
public interface UserHandlerService {
	User register(User user);
	User login(String userName,String password);
}
