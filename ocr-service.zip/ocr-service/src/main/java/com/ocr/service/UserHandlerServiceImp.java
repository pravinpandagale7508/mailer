package com.ocr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ocr.model.advance.User;
import com.ocr.repository.UserRepo;
@Service
public class UserHandlerServiceImp implements UserHandlerService {
	@Autowired
	private UserRepo userRepo;
	@Override
	public User register(User user) {
		// TODO Auto-generated method stub
		User u = userRepo.save(user);
		u.setManagerId(u.getId());
		return userRepo.save(u);
	}

	@Override
	public User login(String userName, String password) {
		User existingUser = userRepo.getByUserName(userName);
		return existingUser;
	}
	

}