package com.ocr.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.google.gson.JsonArray;

public class ReadTableWord {
	static String temp = "";
	private static JsonArray tempArray = new JsonArray();
	static String cellValue;

	public static String extractText(FileInputStream fis, int numCol) throws IOException {

		XWPFDocument doc = new XWPFDocument(fis);
		List<XWPFTable> tables = doc.getTables();
		temp = "[";
		tempArray = new JsonArray();
		for (XWPFTable table : tables) {
			String t1 = "[";
			 JsonArray t1Arr = new JsonArray();
			for (XWPFTableRow row : table.getRows()) {
				 t1 += "[";
				 JsonArray t2Arr = new JsonArray();
				boolean stop = false;
				for (XWPFTableCell cell : row.getTableCells()) {
					// System.out.println(cell.getText());
					String sFieldValue = cell.getText();
					if (sFieldValue.trim().equals("")) {
						stop = true;
						break;
					}

					t1 += "\"" + sFieldValue + "\",";
					t2Arr.add(sFieldValue);
//						//System.out.println("\t");
				}
				if (stop) {
					break;
				}
				t1 = t1.substring(0, t1.length() - 1);
				t1 += "],";
				t1Arr.add(t2Arr);
				
			}
			t1 = t1.substring(0, t1.length() - 1);
			if(t1.charAt(t1.length() - 1)==',') {
				t1 = t1.substring(0, t1.length() - 1);
			}
			t1 += "]";
			tempArray.add(t1Arr);
			temp += t1 + ",";
		}
		temp = temp.substring(0, temp.length() - 1);
		temp += "]";
		return tempArray.toString();
	}

}