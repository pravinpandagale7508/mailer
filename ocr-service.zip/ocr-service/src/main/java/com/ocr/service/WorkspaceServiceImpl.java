package com.ocr.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ocr.model.advance.FileTable;
import com.ocr.model.advance.Template;
import com.ocr.model.advance.User;
import com.ocr.model.advance.Workspace;
import com.ocr.repository.FileTableRepo;
import com.ocr.repository.TemplateRepo;
import com.ocr.repository.UserRepo;
import com.ocr.repository.WorkspaceRepo;

@Service
public class WorkspaceServiceImpl {
	@Autowired
	private WorkspaceRepo workspaceRepo;
	@Autowired
	private FileTableRepo fileTableRepo;
	@Autowired
	private TemplateRepo templateRepo;

	@Autowired
	private UserRepo userRepo;

	public User getUserByApiKey(String api) {
		return userRepo.getByApiKey(api);
	}
	
	public Template findByIdAndUserId(long id,long user_id) {
		return templateRepo.findByIdAndUserId(id, user_id);
	}

	public Workspace updateWorkspace(Map<String, Object> data) {
		long workspaceId = Long.parseLong(data.get("id").toString());
		Workspace w = workspaceRepo.findById(workspaceId).get();
		Map<String, Object> templateJson = new HashMap<>();
		Map<String, Object> ocrJson = new HashMap<>();
		Map<String, Object> params = new HashMap<>();
		List<Map<String, Object>> ocrJsonList = new ArrayList<>();
		boolean trash = false;
		if (data.get("templateJson") != null) {
			templateJson = (Map<String, Object>) data.get("templateJson");
		}

		if (data.get("ocrJsonList") != null) {
			ocrJsonList = (List<Map<String, Object>>) data.get("ocrJsonList");
		}
		if (data.get("ocrJson") != null) {
			ocrJson = (Map<String, Object>)data.get("ocrJson");
		}
		if (data.get("trash") != null) {
			trash = (boolean) data.get("trash");
		}
		if (data.get("params") != null) {
			params = (Map<String, Object>) data.get("params");
		}else {
			params.put("lastId", 1);
		}
		//w.setOcrJsonList(ocrJson);
		w.setTemplateJson(templateJson);
		w.setTrash(trash);
		w.setOcrJson(ocrJson);
		w.setParams(params);
		return workspaceRepo.save(w);
	}

	public Workspace getWorkspaceByName(String name) {
		return workspaceRepo.findByName(name);
	}

	public FileTable getFileTableData(Map<String, Object> data) {
		long file_table_id = Long.parseLong(data.get("file_table_id").toString());
		FileTable w = fileTableRepo.findById(file_table_id).get();
		return w;
	}
	
	public FileTable updateOcrFileTableData(Map<String, Object> data) {
		long file_table_id = Long.parseLong(data.get("file_table_id").toString());
		FileTable w = fileTableRepo.findById(file_table_id).get();
		Map<String, Object> params = (Map<String, Object>) data.get("params");
		w.setParams(params);
		
		return fileTableRepo.save(w);
	}

	public Workspace addWorkspace(Map<String, Object> data) throws Exception { // .findById(id).get();
		long userId = Long.parseLong(data.get("userId").toString());
		String name = data.get("name").toString();
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> templateJson = new HashMap<>();
		List<Map<String, Object>> ocrJson = new ArrayList<>();
		if (data.get("templateJson") != null) {
			templateJson = (Map<String, Object>) data.get("templateJson");
		}

		if (data.get("ocrJson") != null) {
			ocrJson = (List<Map<String, Object>>) data.get("ocrJson");
		}

		if (data.get("params") != null) {
			params = (Map<String, Object>) data.get("params");
		}
		params.put("lastId", 1);
		return workspaceRepo.save(new Workspace(name, userId, new Date().getTime(), new Date().getTime(), templateJson,
				ocrJson, params, false));
	}

	public Template addTemplate(Map<String, Object> data) {
		long userId = Long.parseLong(data.get("userId").toString());
		String name = data.get("name").toString();
		Map<String, Object> params = new HashMap<>();
		Map<String, Object> templateJson = new HashMap<>();
		if (data.get("params") != null) {
			params = (Map<String, Object>) data.get("params");
		}
		if (data.get("templateJson") != null) {
			templateJson = (Map<String, Object>) data.get("templateJson");
		}

		return templateRepo.save(
				new Template(userId, name, new Date().getTime(), new Date().getTime(), templateJson, params, false));
	}

	public Template moveTemplateToTrashCurrent(Map<String, Object> data) {
		long id = Long.parseLong(data.get("id").toString());
		boolean trash = (boolean) data.get("trash");
		Template t = templateRepo.findById(id).get();
		t.setTrash(trash);
		return templateRepo.save(t);
	}

	public List<Workspace> getWorkspaceList() {
		return workspaceRepo.findAll();
	}

	public List<Workspace> getActiveWorkspaceList() {
		return workspaceRepo.findAllByTrash(false);
	}

	public List<Workspace> getActiveInactiveWorkspaceList(boolean trash) {
		return workspaceRepo.findAllByTrash(trash);
	}

	public List<Template> getActiveInactiveTemplateList(boolean trash) {
		return templateRepo.findAllByTrash(trash);
	}

	public List<Template> getTemplateList() {
		return templateRepo.findAll();
	}

	public Workspace updateFileToWorkspace(long workspaceId) {
		Workspace w = workspaceRepo.findById(workspaceId).get();
		return workspaceRepo.save(w);
	}

	public Workspace updateWorkspace(long workspaceId, Map<String, Object> ocrMap) {
		Workspace w = workspaceRepo.findById(workspaceId).get();
		List<Map<String, Object>> ocr = w.getOcrJsonList();
		if (ocr == null) {
			ocr = new ArrayList<>();
		}
		ocr.add(ocrMap);
		w.setOcrJsonList(ocr);
		return workspaceRepo.save(w);
	}

	public FileTable addFile(FileTable f) {
		FileTable t = fileTableRepo.save(f);
		return t;
	}
}
