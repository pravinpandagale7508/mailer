package com.ocr.constants;

public class OcrConstants {
	public static final int SUCCESS = 1;
	public static final int NOT_FOUND = 4;
	public static final int FAILED = 5;
	
}
