package com.ocr.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ocr.model.advance.User;


@Repository
public interface UserRepo extends JpaRepository<User, Long> {

	User getByUserName(String userName);
	User getByApiKey(String apiKey);
}