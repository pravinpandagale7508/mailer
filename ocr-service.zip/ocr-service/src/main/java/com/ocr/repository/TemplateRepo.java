package com.ocr.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ocr.model.advance.FileTable;
import com.ocr.model.advance.Template;
import com.ocr.model.advance.User;
import com.ocr.model.advance.Workspace;


@Repository
public interface TemplateRepo extends JpaRepository<Template, Long> {
	List<Template> findAllByTrash(boolean trash);
	Template findByIdAndUserId(long id,long user_id);
}