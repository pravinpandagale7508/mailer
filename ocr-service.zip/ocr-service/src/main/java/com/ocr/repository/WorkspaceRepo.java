package com.ocr.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ocr.model.advance.User;
import com.ocr.model.advance.Workspace;


@Repository
public interface WorkspaceRepo extends JpaRepository<Workspace, Long> {
	List<Workspace> findAllByTrash(boolean trash);
	Workspace findByName(String name);
}