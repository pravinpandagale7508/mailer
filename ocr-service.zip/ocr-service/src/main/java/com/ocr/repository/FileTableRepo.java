package com.ocr.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ocr.model.advance.FileTable;
import com.ocr.model.advance.User;
import com.ocr.model.advance.Workspace;


@Repository
public interface FileTableRepo extends JpaRepository<FileTable, Long> {
}