package com.ocr.controller;

import java.util.Date;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ocr.constants.OcrConstants;
import com.ocr.dto.ResponseDto;
import com.ocr.model.advance.User;
import com.ocr.service.UserHandlerServiceImp;
import com.ocr.utils.Utility;

@RestController
@RequestMapping(path = "/user")
public class UserController {

	/*
	 * @Autowired private FileStorageService storageService;
	 */

	@Autowired 
	private UserHandlerServiceImp userService;

	@PostMapping("/userHandler")
	public Object handleRequest(@RequestBody Map<String, Object> requestMap, HttpServletResponse response,
			HttpServletRequest request) {
		String caseName = (String) requestMap.get("opcode");
		System.out.println(caseName);
		switch (caseName) {
		case "register": {
			String message = "";
			try {
				String userName = (String) requestMap.get("userName");
				String password = (String) requestMap.get("password");	
				String email = (String) requestMap.get("email");
				String mobile = (String) requestMap.get("mobile");
				User u = new User();
				u.setUserName(userName);
				u.setPassword(password);
				u.setParams(new HashedMap<>());
				u.setMobile(mobile);
				u.setEmail(email);
				u.setCreated(new Date().getTime());
				u.setUpdated(new Date().getTime());
				UUID uuid = Utility.getUUID();
				u.setApiKey(uuid.toString());
				User u1 =userService.register(u);
				message = "Register: ";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, u1);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				// message = "Could not upload the file: " + file.getOriginalFilename() + ". " +
				// e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "login": {
			String message = "";
			try {
				User u = new User();
				String userName = (String) requestMap.get("userName");
				String password = (String) requestMap.get("password");				
				u = userService.login(userName, password);
				
				if(u==null) {
					message = "user not found: ";
					ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
					return ResponseEntity.status(HttpStatus.OK).body((dto));
				}
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, u);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				// message = "Could not upload the file: " + file.getOriginalFilename() + ". " +
				// e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "logout": {
			String message = "";
			try {

				message = "logged out: ";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, "");
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				// message = "Could not upload the file: " + file.getOriginalFilename() + ". " +
				// e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		default:
			ResponseDto dto = new ResponseDto(OcrConstants.FAILED, "", null);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);

		}

	}

}