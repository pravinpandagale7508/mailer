package com.ocr.controller;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections4.map.HashedMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ocr.constants.OcrConstants;
import com.ocr.dto.ResponseDto;
import com.ocr.dto.WorkspaceDto;
import com.ocr.model.advance.FileTable;
import com.ocr.model.advance.Template;
import com.ocr.model.advance.User;
import com.ocr.model.advance.Workspace;
import com.ocr.service.WorkspaceServiceImpl;
import com.ocr.utils.FileUtils;
import com.ocr.utils.Utility;

import net.sourceforge.tess4j.ITessAPI.TessPageIteratorLevel;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.ITesseract.RenderedFormat;
import net.sourceforge.tess4j.OCRResult;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.Word;

@RestController
@RequestMapping(path = "/ocr")
public class OCRController {

	/*
	 * @Autowired private FileStorageService storageService;
	 */

	@Autowired
	private WorkspaceServiceImpl workspaceServiceImpl;

	@PostMapping("/ocrHandler")
	public Object handleRequest(@RequestBody Map<String, Object> requestMap, HttpServletResponse response,
			HttpServletRequest request) {
		String caseName = (String) requestMap.get("opcode");
		switch (caseName) {
		case "addWorkspace": {
			String message = "";
			try {
				String name = requestMap.get("name").toString();
				if(workspaceServiceImpl.getWorkspaceByName(name)!=null) {
					message = "Workspace already exists ";
					ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
					return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
				}
				Workspace w = workspaceServiceImpl.addWorkspace(requestMap);
				message = "Workspace created succesfully ";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}

		case "updateWorkspace": {
			String message = "";
			try {
				Workspace w = workspaceServiceImpl.updateWorkspace(requestMap);
				message = "Workspace updated succesfully ";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getFileTableData": {
			String message = "";
			try {
				FileTable w = workspaceServiceImpl.getFileTableData(requestMap);
				message = "FileTable ";
				Map<String, Object> fileTableMap = Utility.convertObjToMap(w);
				//Map<String, Object> fileTableMap = new HashMap<>();
				String encodeToString = Base64.getEncoder().encodeToString(w.getUploadedFile());
				System.out.println(encodeToString);
				fileTableMap.put("fileBase64", encodeToString);
				//fileTableMap.put("file", );
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message,fileTableMap);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "updateOcrFileTableData": {
			String message = "";
			try {
				FileTable w = workspaceServiceImpl.updateOcrFileTableData(requestMap);
				message = "FileTable ";
				Map<String, Object> fileTableMap = Utility.convertObjToMap(w);
				//Map<String, Object> fileTableMap = new HashMap<>();
				String encodeToString = Base64.getEncoder().encodeToString(w.getUploadedFile());
				System.out.println(encodeToString);
				fileTableMap.put("fileBase64", encodeToString);
				//fileTableMap.put("file", );
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message,fileTableMap);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getWorkspaceList": {
			String message = "";
			try {
				List<Workspace> w = workspaceServiceImpl.getWorkspaceList();
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getActiveWorkspaceList": {
			String message = "";
			try {
				List<Workspace> w = workspaceServiceImpl.getActiveWorkspaceList();
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "moveTemplateToTrashCurrent": {
			String message = "";
			try {
				Template w = workspaceServiceImpl.moveTemplateToTrashCurrent(requestMap);
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not update the template " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getActiveInactiveWorkspaceList": {
			String message = "";
			try {
				boolean trash =(boolean) requestMap.get("trash");
				List<Workspace> w = workspaceServiceImpl.getActiveInactiveWorkspaceList(trash);
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getActiveInactiveTemplateList": {
			String message = "";
			try {
				boolean trash =(boolean) requestMap.get("trash");
				List<Template> w = workspaceServiceImpl.getActiveInactiveTemplateList(trash);
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "getTemplateList": {
			String message = "";
			try {
				List<Template> w = workspaceServiceImpl.getTemplateList();
				message = "";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Workspace " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		case "addTemplate": {
			String message = "";
			try {
				Template w = workspaceServiceImpl.addTemplate(requestMap);
				message = "Template created succesfully ";
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, w);
				return ResponseEntity.status(HttpStatus.OK).body((dto));
			} catch (Exception e) {
				e.printStackTrace();
				message = "Could not create the Template " + e.getMessage();
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
		}
		default:
			ResponseDto dto = new ResponseDto(OcrConstants.FAILED, "", null);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);

		}

	}
	public List<Map<String, Object>> mergeObject(Map<String, Object> objX,Map<String, Object> objY,int indexX,int indexY,List<Map<String, Object>>list) {
		Map<String, Object> res = new HashMap<>();
		double x = Double.parseDouble(objX.get("x").toString())>=Double.parseDouble(objY.get("x").toString())?Double.parseDouble(objY.get("x").toString()):Double.parseDouble(objX.get("x").toString());
		double y = Double.parseDouble(objX.get("y").toString())>=Double.parseDouble(objY.get("y").toString())?Double.parseDouble(objY.get("y").toString()):Double.parseDouble(objX.get("y").toString());
		double width = Double.parseDouble(objX.get("x").toString())>=Double.parseDouble(objY.get("x").toString())?( Double.parseDouble(objX.get("x").toString())- Double.parseDouble(objY.get("x").toString())+ Double.parseDouble(objX.get("width").toString())):( Double.parseDouble(objY.get("x").toString())- Double.parseDouble(objX.get("x").toString())+ Double.parseDouble(objY.get("width").toString()));
		double height = (Double.parseDouble(objX.get("y").toString())+Double.parseDouble(objX.get("height").toString()))>Double.parseDouble(objY.get("y").toString())+Double.parseDouble(objY.get("height").toString())?(Double.parseDouble(objX.get("y").toString())+Double.parseDouble(objX.get("height").toString())-y):(Double.parseDouble(objY.get("y").toString())+Double.parseDouble(objY.get("height").toString())-y);
		
		res.put("x", x);
		res.put("y", y);
		res.put("width", width);
		res.put("height", height);
		String text = Double.parseDouble(objX.get("x").toString())<Double.parseDouble(objY.get("x").toString())?(objX.get("text").toString()+" "+ objY.get("text").toString()):(objY.get("text").toString()+" "+ objX.get("text").toString());
		res.put("text", text);
		list.set(indexX, res);
		list.remove(indexY);
		
		return list;
	}
	public Map<String, Object> getRequiredData(double x,double y,List<Map<String, Object>> list) {
		for (int i = 0; i < list.size(); i++) {
			Map<String, Object> objI = list.get(i);
			if(y<=    Double.parseDouble(objI.get("y").toString())  +Double.parseDouble(objI.get("height").toString())  && y>=     Double.parseDouble(objI.get("y").toString())   ) {
				if(x<=    Double.parseDouble(objI.get("x").toString())  +Double.parseDouble(objI.get("width").toString()) &&  x>=     Double.parseDouble(objI.get("x").toString()) ) {
					return objI;
				}
			}
		}
		return null;		
	}
	public List<Map<String, Object>> processSlider(List<Map<String, Object>> list,double rangeX,double rangeY) {
		boolean bComp = true;
		int ii = 0;
        int jj = 0;
        do {
        	bComp = true;
        	for (int i = 0; i < list.size(); i++) {
        		Map<String, Object> objI = list.get(i);
        		for (int j = i + 1; j < list.size()-1; j++) {
        			Map<String, Object> objJ = list.get(j);
        			
        			boolean cond1 = (Double.parseDouble(objI.get("x").toString())+Double.parseDouble(objI.get("width").toString()))>(Double.parseDouble(objJ.get("x").toString())-rangeX);
    				boolean cond2=(Double.parseDouble(objI.get("x").toString())+Double.parseDouble(objI.get("width").toString()))<(Double.parseDouble(objJ.get("x").toString())+rangeX);
    				
    				boolean cond3 = (Double.parseDouble(objJ.get("x").toString())+Double.parseDouble(objJ.get("width").toString()))>(Double.parseDouble(objI.get("x").toString())-rangeX);
    				boolean cond4=(Double.parseDouble(objJ.get("x").toString())+Double.parseDouble(objI.get("width").toString()))<(Double.parseDouble(objI.get("x").toString())+rangeX);
    				
        			
        			if((Double.parseDouble(objI.get("y").toString()) -  Double.parseDouble(objJ.get("y").toString()))<rangeY && (Double.parseDouble(objJ.get("y").toString())-Double.parseDouble(objI.get("y").toString())<rangeY)) {
        				if(cond1 && cond2) {
        					bComp = false;
                            ii = i;
                            jj = j;
                            break;
        				}else if(cond3&&cond4) {
        					bComp = false;
                            ii = i;
                            jj = j;
                            break;
        				}
        			}
    			}
                if (!bComp) {
                    break;
                }
			}
        	
        	if (!bComp) {
        		list = mergeObject(list.get(ii), list.get(jj), ii, jj, list);
                // processSlider(tI)

            }
		} while (!bComp);
        
		return list;
	}
	@PostMapping("/process/{templateID}/{apiKey}")
	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file, @PathVariable("templateID") String templateID,
			@PathVariable("apiKey") String apiKey) {
		String message = "";
		File f = null;
		try {
			// FileTable table = storageService.store(file);

			ITesseract instance;
			instance = new Tesseract();
			instance.setTessVariable("user_defined_dpi", "70");
			instance.setDatapath("D:\\tessdata");

			f = FileUtils.convertMultiPartToFile(file);

			System.out.println(file.getContentType());
			if (file.getContentType().equals("application/pdf")) {
				File[] results = FileUtils.convertPdf2Png(f);
				try {
					f = results[0];
				} catch (Exception e) {
					e.printStackTrace();
					message = "Could not process file: " + file.getOriginalFilename() + ". " + e.getMessage();
					ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
					return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
				}
				
			}
			BufferedImage bi = ImageIO.read(f);

			String outputbase = "D:\\tessdata";
			List<RenderedFormat> formats = new ArrayList<RenderedFormat>(
					Arrays.asList(RenderedFormat.HOCR, RenderedFormat.PDF, RenderedFormat.TEXT));
			instance.setVariable(ITesseract.DOCUMENT_TITLE, "My document");
			OCRResult resultOCRResult = instance.createDocumentsWithResults(bi, f.getPath(), outputbase, formats,
					TessPageIteratorLevel.RIL_WORD);
			System.out.println(resultOCRResult.getWords());
			List<Map<String, Object>> resultOCRResultMapList = new ArrayList<>();
			for (Word word : resultOCRResult.getWords()) {
				// logger.info(word.toString());
				System.out.println(word.getText());
				Rectangle rect = word.getBoundingBox();
				Map<String, Object> m = new HashMap<>();
				m.put("x", rect.x);
				m.put("y", rect.y);
				m.put("width", rect.width);
				m.put("height", rect.height);
				m.put("text", word.getText());
				resultOCRResultMapList.add(m);
			}

			message = "Uploaded the file successfully with id: ";
			Map<String, Object> listMap = new HashMap<>();
			//listMap.put("list", resultOCRResultMapList);
			//listMap.put("orgList", resultOCRResultMapList);
			//listMap.put("fileWidth", bi.getWidth());
			//listMap.put("fileHeight", bi.getHeight());
			
			//FileTable fileTable = new FileTable(workspaceId, file.getName(), file.getBytes(), userId, Double.parseDouble(bi.getWidth() + ""), Double.parseDouble(bi.getHeight() + ""), resultOCRResultMapList, resultOCRResultMapList,  new HashMap());
			
			//fileTable = workspaceServiceImpl.addFile(fileTable);
			
			Map<String, Object> ocrMap = new HashMap<>();			
			//ocrMap.put("file_table_id",fileTable.getId());
			//ocrMap.put("claimed_by_user_id",userId);
			//ocrMap.put("status",false);
			//Workspace w = workspaceServiceImpl.updateWorkspace(workspaceId, ocrMap);
			
			User u = workspaceServiceImpl.getUserByApiKey(apiKey);
			if(u!=null) {
				// by id and user
				Template template = workspaceServiceImpl.findByIdAndUserId(Long.parseLong(templateID),u.getId());
				Map<String, Object> templateJson = template.getTemplateJson();
				double rangeX = templateJson.get("rangeX")!=null?Double.parseDouble(templateJson.get("rangeX").toString()):0 ;
				double rangeY = templateJson.get("rangeY")!=null?Double.parseDouble(templateJson.get("rangeY").toString()):0 ;
				// templatejson witn rangeX and rangeY
				System.out.println(templateJson);
				List<Map<String, Object>> fields = (List<Map<String, Object>>) templateJson.get("fields");
				List<Map<String, Object>> cost_items = (List<Map<String, Object>>) templateJson.get("cost_items");
				// merge with this using orglist 
				List<Map<String, Object>> orgList = new ArrayList<Map<String,Object>>(resultOCRResultMapList);
				System.out.println(orgList);
				List<Map<String, Object>> mergedList = processSlider(resultOCRResultMapList, rangeX, rangeY);
				System.out.println(mergedList);
				List<Map<String, Object>> newFields = new ArrayList<>();
				for (int i = 0; i < fields.size(); i++) {
					Map<String, Object> field = fields.get(i);
					List<Map<String, Object>> points = (List<Map<String, Object>>) field.get("points");
					for (int j = 0; j < points.size(); j++) {
						Map<String, Object> point = points.get(j);
						double pointX = Double.parseDouble(point.get("x").toString());
						double pointY = Double.parseDouble(point.get("y").toString());
						Map<String, Object> data = getRequiredData(pointX, pointY, mergedList);
						if(data!=null) {
							String val = field.get("value").toString();
							if(val.length()==0) {
								val = data.get("text").toString();
							}
							field.put("value", val);
						}
					}
					newFields.add(field);					
				}
				List<Map<String, Object>> newCost_items = new ArrayList<>();
				for (int i = 0; i < cost_items.size(); i++) {
					Map<String, Object> cost = cost_items.get(i);
					List<Map<String, Object>> items = (List<Map<String, Object>>) cost.get("items");
					List<Map<String, Object>> newItems = new ArrayList<>();
					for (int j = 0; j < items.size(); j++) {
						Map<String, Object> item = items.get(j);
						item.put("label","");
						List<Map<String, Object>> points = (List<Map<String, Object>>) item.get("points");
						for (int k = 0; k < points.size(); k++) {
							Map<String, Object> point = points.get(k);
							double pointX = Double.parseDouble(point.get("x").toString());
							double pointY = Double.parseDouble(point.get("y").toString());
							Map<String, Object> data = getRequiredData(pointX, pointY, mergedList);
							if(data!=null) {
								String val = item.get("label").toString();
								if(val.length()==0) {
									val = data.get("text").toString();
								}
								item.put("label", val);
							}
						}
						
						newItems.add(item);
					}
					
					cost.put("items",newItems);
					newCost_items.add(cost);
				}
				
				templateJson.put("fields", newFields);
				templateJson.put("cost_items", newCost_items);
				//templateJson.put("list", mergedList);
				//templateJson.put("orgList", orgList);
				template.setTemplateJson(templateJson);
				Map<String, Object> map = new HashMap<>();				
					Map<String, Object> ocrJson = new HashMap<>();
					ocrJson.put("orgList", orgList);
					ocrJson.put("list", mergedList);
				map.put("ocrJson",ocrJson);
				map.put("templateJson",templateJson);
				ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, "", map);
				return ResponseEntity.status(HttpStatus.OK).body((FileUtils.serializationString(dto)));
			}else {
				ResponseDto dto = new ResponseDto(OcrConstants.FAILED, "Manager not exists", null);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
			}
			//String encodeToString = Base64.getEncoder().encodeToString(fileTable.getUploadedFile());
			//System.out.println(encodeToString);
			//listMap.put("file_table_id", fileTable.getId());
			//listMap.put("workspace", Utility.convertObjToMap(w));
			//ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, listMap);
			//return ResponseEntity.status(HttpStatus.OK).body((FileUtils.serializationString(dto)));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the file: " + file.getOriginalFilename() + ". " + e.getMessage();
			ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
		} finally {
			if (f != null) {
				f.delete();
			}
		}
	}
	
	@PostMapping("/uploadFile")
	public ResponseEntity<Object> uploadFile(@RequestParam("file") MultipartFile file,
			@RequestParam("workspaceId") long workspaceId, @RequestParam("userId") long userId) {
		String message = "";
		File f = null;
		try {
			// FileTable table = storageService.store(file);

			ITesseract instance;
			instance = new Tesseract();
			instance.setTessVariable("user_defined_dpi", "70");
			instance.setDatapath("D:\\tessdata");

			f = FileUtils.convertMultiPartToFile(file);

			System.out.println(file.getContentType());
			if (file.getContentType().equals("application/pdf")) {
				File[] results = FileUtils.convertPdf2Png(f);
//				for (File result : results) {
//					System.out.println(result);
//					f = result;
//				}
				try {
					f = results[0];
				} catch (Exception e) {
					e.printStackTrace();
					message = "Could not process file: " + file.getOriginalFilename() + ". " + e.getMessage();
					ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
					return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
				}
				
			}
			BufferedImage bi = ImageIO.read(f);

			String outputbase = "D:\\tessdata";
			List<RenderedFormat> formats = new ArrayList<RenderedFormat>(
					Arrays.asList(RenderedFormat.HOCR, RenderedFormat.PDF, RenderedFormat.TEXT));
			instance.setVariable(ITesseract.DOCUMENT_TITLE, "My document");
			OCRResult resultOCRResult = instance.createDocumentsWithResults(bi, f.getPath(), outputbase, formats,
					TessPageIteratorLevel.RIL_WORD);
			System.out.println(resultOCRResult.getWords());
			List<Map<String, Object>> resultOCRResultMapList = new ArrayList<>();
			for (Word word : resultOCRResult.getWords()) {
				// logger.info(word.toString());
				System.out.println(word.getText());
				Rectangle rect = word.getBoundingBox();
				Map<String, Object> m = new HashMap<>();
				m.put("x", rect.x);
				m.put("y", rect.y);
				m.put("width", rect.width);
				m.put("height", rect.height);
				m.put("text", word.getText());
				resultOCRResultMapList.add(m);
			}

			message = "Uploaded the file successfully with id: ";
			Map<String, Object> listMap = new HashMap<>();
			listMap.put("list", resultOCRResultMapList);
			listMap.put("orgList", resultOCRResultMapList);
			listMap.put("fileWidth", bi.getWidth());
			listMap.put("fileHeight", bi.getHeight());
			
			FileTable fileTable = new FileTable(workspaceId, file.getOriginalFilename(), file.getBytes(), userId, Double.parseDouble(bi.getWidth() + ""), Double.parseDouble(bi.getHeight() + ""), resultOCRResultMapList, resultOCRResultMapList,  new HashMap());
			
			fileTable = workspaceServiceImpl.addFile(fileTable);
			
			Map<String, Object> ocrMap = new HashMap<>();	
			ocrMap.put("file_name",fileTable.getFileName());
			ocrMap.put("file_table_id",fileTable.getId());
			ocrMap.put("claimed_by_user_id",userId);
			ocrMap.put("status",false);
			String encodeToString = Base64.getEncoder().encodeToString(fileTable.getUploadedFile());
			System.out.println(encodeToString);
			listMap.put("fileBase64", encodeToString);
			Workspace w = workspaceServiceImpl.updateWorkspace(workspaceId, ocrMap);
			w.setOcrJson(listMap);
			
			
			listMap.put("file_table_id", fileTable.getId());
			Map<String, Object> m = Utility.convertObjToMap(w);
			listMap.put("workspace", Utility.convertObjToMap(w));
			ResponseDto dto = new ResponseDto(OcrConstants.SUCCESS, message, listMap);
			return ResponseEntity.status(HttpStatus.OK).body((FileUtils.serializationString(dto)));
		} catch (Exception e) {
			e.printStackTrace();
			message = "Could not upload the file: " + file.getOriginalFilename() + ". " + e.getMessage();
			ResponseDto dto = new ResponseDto(OcrConstants.FAILED, message, null);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(dto);
		} finally {
			if (f != null) {
				f.delete();
			}
		}
	}

}