package com.ocr.dto;

import com.ocr.model.advance.FileTable;
import com.ocr.model.advance.Workspace;

public class WorkspaceDto {
	private Workspace workspace;
	private FileTable fileTable;
	
	public Workspace getWorkspace() {
		return workspace;
	}
	public void setWorkspace(Workspace workspace) {
		this.workspace = workspace;
	}
	public FileTable getFileTable() {
		return fileTable;
	}
	public void setFileTable(FileTable fileTable) {
		this.fileTable = fileTable;
	}
	
}
