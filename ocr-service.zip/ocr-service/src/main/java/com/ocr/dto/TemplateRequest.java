package com.ocr.dto;

public class TemplateRequest {

	private int id;
	public TemplateRequest() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
