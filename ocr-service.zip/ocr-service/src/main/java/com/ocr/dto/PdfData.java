package com.ocr.dto;

import java.util.Date;

public class PdfData {
	private String s;
	private String l;
	private String t;
	private String b;
	private String r;
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	public String getT() {
		return t;
	}
	public void setT(String t) {
		this.t = t;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public String getR() {
		return r;
	}
	public void setR(String r) {
		this.r = r;
	}
	
}
