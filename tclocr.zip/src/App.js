import logo from './logo.svg';
import './fontawesome/font-awesome.min.css';
import './App.css';

import React from 'react';
import { LandingPage } from './LandingPage'
export const App = props => {
    return (
        <React.Fragment>
            <LandingPage/>


        </React.Fragment>
    );
}

export default App;
