import base64 from 'binary-base64';
import './fontawesome/font-awesome.min.css';
import RectangleSelection from "react-rectangle-selection"
import './App.css';
import './loader.scss';
import { v4 as uuidv4 } from 'uuid';
import { useEffect, useState, useRef } from 'react';
import React from 'react';
import { styled, alpha } from '@mui/material/styles';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { FaAngleDown, FaAngleUp } from "react-icons/fa";
import { BrowserRouter as Router, Link, Route, Routes, useNavigate, useLocation } from 'react-router-dom';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import TableViewOutlined from '@mui/icons-material/TableViewOutlined';
import { RadioGroup, Radio, FormLabel, Box, FormControlLabel, Checkbox, Grid, Button, Paper, Table, TableHead, TableBody, TableContainer, TableCell, TableRow, Typography, } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import TextButton from '@mui/material/IconButton';
import { TextField, SelectField, TextFieldLegacy } from './style-guide';
import { FaPlus, FaCaretRight, FaMinus, FaCloudDownloadAlt, FaLevelDownAlt, FaArrowAltCircleLeft, FaArrowAltCircleRight, FaTrashAlt, FaUndo } from "react-icons/fa";
import DocViewer, { DocViewerRenderers } from "react-doc-viewer";
import DocCustomRenderer from "./DocCustomRenderer";
import { Template } from './component/template/template'
import { CustomItemDlg } from './component/ItemCreation/CustomItem'
import { ItemTable } from './component/ItemTable/ItemTable'
import { Header } from './component/header/header'
import Login from './component/Login/Login';
import Registration from './component/Registration/Registration';
import logo from './one-sm-black.png';
import { Dialog, Snackbar } from './style-guide';
import { setTemplates, setFileTable, setMoreRowDocData, setMergeData, setSelectedIdentifier, setSelectedItemSelection, setSelectedTemplateTable, expandTemplateItem, setSelectedTemplate, setBoundingElements, setTemplateTableList, setPdfHeightWidth, setCordinates, onChangeDocs, onLoading, setItemHeaders1, setItemHeaders, setDocs, setPdfData, setDocData, setItemHeader } from './reducers/templateSlicer';
import { updateOcrFileTableData,getFileTableData, moveTemplateToTrashCurrent, getActiveInactiveWorkspaceList, getActiveWorkspaceList, addTemplate, updateWorkspace, getWorkspaceList, addWorkspace, getTemplate, uploadFile, downloadDocx, loadFiles, extractFiles, exportItems, uploadTemplate, getActiveInactiveTemplateList, getExtraDataListByKeys } from './reducers/requestHandler';
import { template_type, test_b_doc, test_b_pdf } from './constants/globleConstants'
import { snackbarToggle } from './reducers/snackbarSlicer';
export const LandingPage = props => {
    const { admin, currentPage, isLoading } = useSelector(state => state.session);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const canvas = useRef();
    const [isLogin, setIsLogin] = useState(false);
    const [bOpenLeftPanal, setBOpenLeftPanal] = useState(true);
    let ctx = null;
    // const navigate = useNavigate();
    const { snackbar } = useSelector(state => state.snackbar);
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const [bDraw, setBDraw] = useState(false);

    const [openItemIdentifierOrderModal, setOpenItemIdentifierOrderModal] = useState(false);
    const onHandleOpenItemIdentifierModal = () => setOpenItemIdentifierOrderModal(true);
    const onHandleCancelItemIdentifierModal = () => setOpenItemIdentifierOrderModal(false);

    const [openItemSelectionOrderModal, setOpenItemSelectionOrderModal] = useState(false);
    const onHandleOpenItemSelectionModal = () => setOpenItemSelectionOrderModal(true);
    const onHandleCancelItemSelectionModal = () => setOpenItemSelectionOrderModal(false);

    const [itemList, setItemList] = useState([]);
    const [openItemOrderModal, setOpenItemOrderModal] = useState(false);
    const onHandleOpenItemModal = () => setOpenItemOrderModal(true);
    const onHandleCancelItemModal = () => setOpenItemOrderModal(false);

    const [openHeaderOrderModal, setOpenHeaderOrderModal] = useState(false);
    const onHandleOpenHeaderModal = () => setOpenHeaderOrderModal(true);
    const onHandleCancelHeaderModal = () => setOpenHeaderOrderModal(false);
    const { selectedTemplateTable, selectedItemSelection, mergeData, moreRowDocData, selectedIdentifier, templateTableList, selectedTemplate, templateList, docs, bLoading, docData, pdfData, itemHeaders, itemHeaders1, pdfHeightWidth } = useSelector(state => state.template);
    const [listOfTemplates, setListOfTemplates] = useState([]);
    const [templateTableList2, setTemplateTableList2] = useState(selectedTemplateTable.name + "");
    const [templateName, setTemplateName] = useState(selectedTemplateTable.name + "");
    const [value, setValue] = useState(
        selectedTemplateTable
            ? {
                name: selectedTemplateTable.name,
                id: selectedTemplateTable.id,
            }
            : {
                id: null,
                name: null,
            },
    );
    
    const [selectedItemIndex, setSelectedItemIndex] = useState(0);
    const [selectedInvoiceData, setSelectedInvoiceData] = useState({});
    const [selectedWorkspaceFile, setSelectedWorkspaceFile] = useState({});
    const [selectedItem, setSelectedItem] = useState({});
    const [workspaceName, setWorkspaceName] = useState("");
    const [workspace, setWorkspace] = useState({ name: "" });
    const [workspaceList, setWorkspaceList] = useState([]);
    const [workspaceListAll, setWorkspaceListAll] = useState([]);
    const [tPdfData1, settPdfData1] = useState([]);
    const [sliderObj, setSliderOBj] = useState({value:0});
    const [sliderObjY, setSliderOBjY] = useState({value:0});
    const [slider, setSlider] = useState(0);
    const [sliderY, setSliderY] = useState(0);
    const [openWorkspaceOrderModal, setOpenWorkspaceOrderModal] = useState(false);
    const mergeObject = (i, j, ii, jj, o) => {
        var res = {
            x: i.x >= j.x ? j.x : i.x,
            y: i.y >= j.y ? j.y : i.y,
            width: i.x >= j.x ? (i.x - j.x + i.width) : (j.x - i.x + j.width),
            height: i.height
        }
        res.height = (i.y + i.height) > (j.y + j.height) ? (i.y + i.height - res.y) : (j.y + j.height - res.y)
        var tPdfData = JSON.parse(JSON.stringify(o))
        tPdfData[ii].x = res.x;
        tPdfData[ii].y = res.y;
        tPdfData[ii].width = res.width;
        tPdfData[ii].height = res.height;

        tPdfData[ii].text = i.x < j.x ? (i.text + " " + j.text) : (j.text + " " + i.text);

        tPdfData.splice(jj, 1);
        settPdfData1(tPdfData)
        //window.setTimeout(drawGrid_2,1000)
        return tPdfData;
    }
    const processSlider = (o) => {
        var bComp = true;
        var ii = 0;
        var jj = 0;
        var obj = JSON.parse(JSON.stringify(o))
        do {
            bComp = true;
            for (var i = 0; i < obj.length - 1; i++) {

                for (var j = i + 1; j < obj.length; j++) {
                    if ((obj[i].y - obj[j].y) < Number(sliderObjY.value) && (obj[j].y - obj[i].y) < Number(sliderObjY.value)) {
                        if ((obj[i].x + obj[i].width) > (obj[j].x - Number(sliderObj.value)) && (obj[i].x + obj[i].width) < (obj[j].x + Number(sliderObj.value))) {
                            bComp = false;
                            ii = i;
                            jj = j;
                            break;

                        } else if ((obj[j].x + obj[j].width) > (obj[i].x - Number(sliderObj.value)) && (obj[j].x + obj[j].width) < (obj[i].x + Number(sliderObj.value))) {
                            bComp = false;
                            ii = i;
                            jj = j;
                            break;
                        }

                    }
                }
                if (bComp) {
                    console.log("1")
                }
                if (!bComp) {
                    break;
                }
            }

            if (!bComp) {
                obj = mergeObject(obj[ii], obj[jj], ii, jj, obj)
                // processSlider(tI)

            }
        } while (!bComp);

        dispatch(setPdfData(obj))
        var w = JSON.parse(JSON.stringify(workspace));
        w.ocrJson.list = obj;
        w.templateJson.rangeX = sliderObj.value;
        w.templateJson.rangeY = sliderObjY.value;
        setWorkspace(w);

    }
    const onHandleOpenWorkspaceModal = () => {
        setOpenWorkspaceOrderModal(true);
        setWorkspaceName("")
    }
    const onHandleCancelWorkspaceModal = () => setOpenWorkspaceOrderModal(false);

    const [openMergeOrderModal, setOpenMergeOrderModal] = useState(false);
    const [lastId, setLastId] = useState(workspace.params?.lastId);
    const onHandleOpenMergeModal = () => {

        setOpenMergeOrderModal(true);
    }
    const onHandleCancelMergeModal = () => setOpenMergeOrderModal(false);

    const [bActiveWorkspace, setBActiveWorkspace] = useState(true);
    const [openManageWorkspaceOrderModal, setOpenManageWorkspaceOrderModal] = useState(false);
    const onHandleOpenManageWorkspaceModal = () => {
        getWorkspaceList(dispatch, {}, function (data) {
            setWorkspaceListAll(data.data)
        })
        //dispatch(setDocs([]));
        setOpenManageWorkspaceOrderModal(true);
    }
    const onHandleCancelManageWorkspaceModal = () => setOpenManageWorkspaceOrderModal(false);

    const [bActiveTemplate, setBActiveTemplate] = useState(true);
    const [openManageTemplateOrderModal, setOpenManageTemplateOrderModal] = useState(false);
    const onHandleOpenManageTemplateModal = () => {
        getActiveInactiveTemplateList(dispatch, { trash: false }, function (data) {
            setListOfTemplates(data.data)
        })
        //dispatch(setDocs([]));
        setOpenManageTemplateOrderModal(true);
    }
    const onHandleCancelManageTemplateModal = () => setOpenManageTemplateOrderModal(false);

    const [openWorkspaceListOrderModal, setOpenWorkspaceListOrderModal] = useState(false);
    const onHandleOpenWorkspaceListModal = () => {
        getActiveWorkspaceList(dispatch, {}, function (data) {
            var t = []
            for (var i = 0; i < data.data.length; i++) {
                if (!data.data[i].trash) {
                    t.push(data.data[i])
                }
            }
            setWorkspaceList(t)
        })
        dispatch(setPdfData([]));
        var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
        if (canvas.length!=0) {
            var ctx = null;
            ctx = canvas[0].getContext('2d');
            ctx.clearRect(0, 0, canvas[0].width, canvas[0].height);
        }
        dispatch(setDocs([]));
        setOpenWorkspaceListOrderModal(true);
        
    }
    const onHandleCancelWorkspaceListModal = () => setOpenWorkspaceListOrderModal(false);
    const applyWorkSpace = () => {

        var w = workspaceList.find(role => role.id === workspace?.id);
        const type = 'application/pdf';
        let base64data = `data:${type};base64,${w?.ocrJson?.fileBase64}`;

        if (w?.ocrJson?.fileBase64) {
            dispatch(onChangeDocs({
                uri: base64data
            }))
        }

        dispatch(setPdfData(w?.ocrJson?.list))
        dispatch(setPdfHeightWidth({
            h: w?.ocrJson?.fileWidth,
            w: w?.ocrJson?.fileHeight,
        }))
        setSliderOBj({ value: w?.templateJson?.rangeX })
        setSliderOBjY({ value: w?.templateJson?.rangeY })
        setWorkspace(w)
        setLastId(w.params?.lastId)
    };

    const [template, setTemplate] = useState({});
    const [openTemplateListOrderModal, setOpenTemplateListOrderModal] = useState(false);

    const onHandleOpenTemplateListModal = () => {
        getActiveInactiveTemplateList(dispatch, {trash:false}, function (data) {
            setListOfTemplates(data.data)
        })
        // dispatch(setDocs([]));
        setOpenTemplateListOrderModal(true);
    }
    const onHandleCancelTemplateListModal = () => setOpenTemplateListOrderModal(false);


    const [openItemCreationNewModal, setOpenItemCreationNewModal] = useState(false);
    const onHandleOpenItemCreationNew = () => setOpenItemCreationNewModal(true);
    const onHandleCancelItemCreationNew = () => setOpenItemCreationNewModal(false);

    const [openItemCreationModal, setOpenItemCreationModal] = useState(false);
    const onHandleOpenItemCreation = () => setOpenItemCreationModal(true);
    const onHandleCancelItemCreation = () => setOpenItemCreationModal(false);

    const [openTemplateOrderModal, setOpenTemplateOrderModal] = useState(false);
    const onHandleOpenTemplateModal = () => setOpenTemplateOrderModal(true);
    const onHandleCancelTemplateModal = () => setOpenTemplateOrderModal(false);

    const [openTemplateTableOrderModal, setOpenTemplateTableOrderModal] = useState(false);
    const onHandleOpenTemplateTableModal = () => setOpenTemplateTableOrderModal(true);
    const onHandleCancelTemplateTableModal = () => setOpenTemplateTableOrderModal(false);

    const [selectedElements, setSelectedElements] = useState([]);
    const [isItems, setIsItems] = useState(false);
    const [openOrderModal, setOpenOrderModal] = useState(false);
    const onHandleOpenModal = () => {
        setOpenOrderModal(true);
        setField("")
    };
    const onHandleCancelModal = () => setOpenOrderModal(false);

    const toolbarStyle = {
        minHeight: '70px',
        color: '#131119',
        width: 'calc(100vw - 50px)',
        justifyContent: 'start',
        alignItems: 'center',
        flexDirection: 'start',
        float: 'left'
    };
    var cOrdi = {}
    function getPos(el) {
        // yay readability
        for (var lx = 0, ly = 0; el != null; lx += el.offsetLeft, ly += el.offsetTop, el = el.offsetParent);

        return { x: lx, y: ly };
    }
    var setCanvasOnlick = function () {

    }
    /*useEffect(() => {
        if (admin.data.session) {
            setIsLogin(true);
        }
        if (openItemOrderModal) {
            onHandleOpenItemModal();
            dispatch(setDocData([...docData]));
        }
        if (selectedTemplate.id == -1 || selectedTemplate.name === 'Item Identifier' || selectedTemplate.id == -2 || selectedTemplate.name === 'Item Selection') {
            return;
        }
        window.setTimeout(drawGrid_2, 1500);
        if (docs.length > 0)
            window.setTimeout(drawFromTemplate, 1500);
    }, [selectedTemplate, bDraw]);*/

    useEffect(() => {
        drawGrid_2()
    }, [pdfData, workspace]);
    

    

    const loadTemplateList = () => {
        getActiveInactiveTemplateList(dispatch, null, function (data) {
            setTemplateTableList2(data.data)
            dispatch(setTemplateTableList(data.data));
            onHandleOpenTemplateTableModal()
        });
    }
    const clearData = (event) => {

        var tArr = []
        for (var i = 0; i < templateList.length; i++) {
            var tI = JSON.parse(JSON.stringify(templateList[i]));
            tI.bSelected = false;
            tI.width = "";
            tI.height = "";
            tI.top = "";
            tI.left = "";
            tI.bott = "";
            tI.right = "";
            tI.numPage = "";
            tI.text = "";
            tArr.push(tI)
        }
        dispatch(setTemplates(tArr))
        dispatch(setSelectedTemplate({ id: 0 }));
        dispatch(setDocs([]));
        dispatch(setPdfData([]));
        dispatch(setDocData([]));
        dispatch(setFileTable([]))
        dispatch(setMoreRowDocData([]))
        dispatch(setMergeData({}))
    }
    const handleMergeData = (mDockData) => {
        var t = []
        var mergSet = {}
        if (mDockData.length) {
            t = mDockData[0]
            //mergSet[mDockData[0][0].length] = [...t];

        }
        for (var k = 0; k < mDockData.length; k++) {
            var table = mDockData[k];
            if (!mergSet[mDockData[k][0].length]) {
                mergSet[mDockData[k][0].length] = []
            }
            for (var j = 0; j < table.length; j++) {
                var tI = JSON.parse(JSON.stringify(table[j]));
                tI.push("");
                tI.push("");
                mergSet[mDockData[k][0].length].push(tI)
            }

            if (t.length < table.length) {
                t = table;
            }
        }
        var biggerKey = 0;

        Object.keys(mergSet).filter(function (obj, ind) {
            if (biggerKey < obj) {
                biggerKey = obj
            }
        })
        var t1 = [];
        t = mergSet[biggerKey];
        setRvalue(biggerKey);
        dispatch(setMoreRowDocData(mergSet[biggerKey]))
        dispatch(setMergeData(mergSet))

    }
    const changeHandler = (event) => {
        dispatch(onLoading(true))

        var formData = new FormData();
        formData.append("workspaceId", workspace?.id)
        formData.append("userId", admin?.data?.data?.id)
        for (var i = 0; i < event.target.files.length; i++) {
            formData.append("file", event.target.files[i], event.target.files[i].name);
            const reader = new FileReader()

            reader.onabort = () => {
                dispatch(snackbarToggle({ type: 'error', message: `Not a proper file` }));
                return;
            }
            reader.onerror = () => {
                dispatch(snackbarToggle({ type: 'error', message: `Not a proper file` }));
                return;
            }
            reader.onload = () => {
                // Do whatever you want with the file contents
                const binaryStr = reader.result
                /*dispatch(onChangeDocs({
                    uri: binaryStr
                }))*/

                uploadFile(dispatch, formData, function (data) {
                    dispatch(onLoading(false))
                    setWorkspace(data.data.workspace);
                    return;
                    dispatch(setFileTable(data.data))
                    dispatch(setPdfData(data.data.list))
                    setWorkspace(data.data.workspace);
                    dispatch(setPdfHeightWidth({
                        h: data.data.fileWidth,
                        w: data.data.fileHeight,
                    }))
                    const type = 'application/pdf';
                    let base64data = `data:${type};base64,${data.data.fileBase64}`;
                    dispatch(onChangeDocs({
                        uri: base64data
                    }))
                    dispatch(onLoading(false))
                    drawGrid_2()
                })
            }
            reader.readAsDataURL(event.target.files[i])
        }
        return;


        uploadFile(dispatch, formData, function (data) {

            loadFiles(dispatch, { id: data.data.id }, function (response) {

                extractFiles(dispatch, { id: data.data.id }, function (response1) {
                    dispatch(setFileTable(data.data))
                    dispatch(setPdfHeightWidth({
                        h: response1.data.data.fileHeight,
                        w: response1.data.data.fileWidth,
                    }))
                    // template set start
                    setValue(prev => ({ ...prev, name: response1.data.template.name }))
                    dispatch(setSelectedTemplateTable((response1.data.template)));
                    var list = JSON.parse(response1.data.template.data);
                    if (list == null) {
                        list = [];
                    }
                    var t = [...templateList];
                    var t1 = [];
                    for (var i = 0; i < list?.length; i++) {
                        list[i].bSelected = false;
                        t1.push(list[i]);
                    }
                    if (t1.length) {
                        dispatch(setTemplates(t1));
                    }
                    // template set end
                    const type = 'application/pdf';
                    let base64data = `data:${type};base64,${data.data.pdfFile}`;
                    dispatch(onChangeDocs({
                        uri: base64data
                    }))
                    var mDockData = test_b_doc;

                    fetch("/ocr/" + data.data.fileName + "_doc.json")
                        .then(response => {
                            return response.json();
                        })
                        .then(function (jsondata) {
                            mDockData = jsondata;
                            dispatch(setDocData(jsondata))
                            handleMergeData(mDockData)
                        });

                    fetch("/ocr/" + data.data.fileName + "_pdf.json")
                        .then(response => {
                            return response.json();
                        })
                        .then(jsondata => dispatch(setPdfData(jsondata)));


                })
                dispatch(onLoading(false));
                /* const type = 'application/pdf';
                 let base64data = `data:${type};base64,${data.data.pdfFile}`;
                 dispatch(onChangeDocs({
                     uri: base64data
                 }))
                 dispatch(onLoading(false))
                 */
            })

        }, function (data) {
            dispatch(snackbarToggle({ type: 'error', message: data.data.message }));
        })
    };
    var boundingElements1 = []
    const setBoundingsToTamplate = () => {
        var t = 0, l = 0, b = 0, r = 0;
        var text = "";
        /* for (var i = 0; i < boundingElements1.length; i++) {
             for (var j = i; j < boundingElements1.length; j++) {
                 if (boundingElements1[i].t < boundingElements1[j].t) {
                     var temp = boundingElements1[j];
                     boundingElements1[j] = boundingElements1[i];
                     boundingElements1[i] = temp;
                 }
             }
             text = text + boundingElements1[i].s + ", "
         }*/
        boundingElements1.sort(function (a, b) {
            return (a.t - b.t);
        });

        for (var i = 0; i < boundingElements1.length - 1; i++) {
            text = text + boundingElements1[i].text + ", "
        }
        if (boundingElements1.length)
            text = text + boundingElements1[boundingElements1.length - 1].s;

        for (var i = 0; i < boundingElements1.length; i++) {
            if (t > boundingElements1[i].t || t == 0)
                t = boundingElements1[i].t
            if (b < boundingElements1[i].b || b == 0)
                b = boundingElements1[i].b
            if (l > boundingElements1[i].l || l == 0)
                l = boundingElements1[i].l
            if (r < boundingElements1[i].r || r == 0)
                r = boundingElements1[i].r
        }

        var template = {
            ...selectedTemplate,
            top: t,
            left: l,
            bott: b,
            right: r,
            text: text
        }
        dispatch(setBoundingElements(boundingElements1));
        dispatch(expandTemplateItem(template));
        dispatch(setSelectedTemplate(template));
    }
    const fillTemplateJsonFromFileData = (tableDataList) => {
        var w = JSON.parse(JSON.stringify(workspace));
        var tArr = []
        for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
            var tI = JSON.parse(JSON.stringify(workspace?.templateJson?.fields[i]));
            var dByKey = tableDataList.find(role => role.id === tI.id)
            tI.value = dByKey.data;
            tArr.push(tI)
        }

        var tArr1 = []
        for (var i = 0; i < w.templateJson.cost_items?.length; i++) {
            var tI = JSON.parse(JSON.stringify(w.templateJson.cost_items[i]));
            for (var j = 0; j < tI.items.length; j++) {
                var dByKey = tableDataList.find(role => role.id === tI.items[j].id)
                tI.items[j].label = dByKey.data;
            }
            tArr1.push(tI)
        }
        w.templateJson.cost_items = tArr1;
        w.templateJson.fields = tArr;
        setWorkspace(w)
    }
    const clearTemplateTextPoints = () => {
        var w = JSON.parse(JSON.stringify(workspace));
        var tArr = []
        for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
            var tI = JSON.parse(JSON.stringify(workspace?.templateJson?.fields[i]));
            tI.value = "";
            tI.points = []
            tArr.push(tI)
        }

        var tArr1 = []
        for (var i = 0; i < w.templateJson.cost_items?.length; i++) {
            var tI = JSON.parse(JSON.stringify(w.templateJson.cost_items[i]));
            for (var j = 0; j < tI.items.length; j++) {
                tI.items[j].label = "";
                tI.items[j].points = [];
            }
            tArr1.push(tI)
        }
        w.templateJson.cost_items = tArr1;
        w.templateJson.fields = tArr;
        w.templateJson.rangeX = sliderObj.value
        w.templateJson.rangeY = sliderObjY.value
        setWorkspace(w)

    }
    const drawFromTemplate = () => {
        if (!selectedTemplate.bSelected) {
            return;
        }
        var elem11 = document.getElementsByClassName('react-pdf__Page__textContent');
        if (elem11.length == 0) {
            window.setTimeout(drawFromTemplate, 1000);
        }
        var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
        var ctx = null;
        if (canvas[0]) {
            ctx = canvas[0].getContext('2d');
        }
        var x = selectedTemplate.left * elem11[0].offsetWidth / pdfHeightWidth.w;
        var y = selectedTemplate.top * elem11[0].offsetHeight / pdfHeightWidth.h;
        var h = (selectedTemplate.bott - selectedTemplate.top) * elem11[0].offsetHeight / pdfHeightWidth.h;
        var w = (selectedTemplate.right - selectedTemplate.left) * elem11[0].offsetWidth / pdfHeightWidth.w;


        if (ctx) {
            if (w != 0 && h != 0) {
                ctx.beginPath();
                ctx.strokeStyle = "blue";
                ctx.lineWidth = 1;
                ctx.rect(x - 5 < 0 ? 0 : x * window.devicePixelRatio - 5, y - 5 < 0 ? 0 : y * window.devicePixelRatio - 5, w * window.devicePixelRatio + 10, h * window.devicePixelRatio + 10);
                ctx.stroke();
            }
        }
    }

    function handleMouseClick(e) {
        var data = getMouseClick(e)
        console.log(data)
        if (data) {

            var w = JSON.parse(JSON.stringify(workspace));
            if (isItems) {
                w.templateJson.cost_items[selectedItem.indexParent].items[selectedItem.indexChild].label = w.templateJson.cost_items[selectedItem.indexParent].items[selectedItem.indexChild].label + " " + data.text


                if (!w.templateJson.cost_items[selectedItem.indexParent].items[selectedItem.indexChild].points) {
                    w.templateJson.cost_items[selectedItem.indexParent].items[selectedItem.indexChild].points = []
                }
                w.templateJson.cost_items[selectedItem.indexParent]?.items[selectedItem.indexChild]?.points?.push({
                    x: data.x,
                    y: data.y,
                    height: data.height,
                    width: data.width,
                })
            } else {
                var tArr = []
                for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
                    var tI = JSON.parse(JSON.stringify(workspace?.templateJson?.fields[i]));

                    if (tI.label == selectedElements.label) {
                        tI.value = tI.value + " " + data.text;
                        if (!tI.points) {
                            tI.points = []
                        }
                        tI.points.push({
                            x: data.x,
                            y: data.y,
                            height: data.height,
                            width: data.width,
                        })
                    }
                    tArr.push(tI)
                }
                w.templateJson.fields = tArr;
            }
            setWorkspace(w)
            drawGrid_2()
            //dispatch(setTemplates(tArr))
        }
    }
    function handleMouseClick1(w1) {
        var w = JSON.parse(JSON.stringify(w1));

        

        var bComp = true;
        var ii = 0;
        var jj = 0;
        var obj = JSON.parse(JSON.stringify(w.ocrJson.orgList))
        do {
            bComp = true;
            for (var i = 0; i < obj.length - 1; i++) {

                for (var j = i + 1; j < obj.length; j++) {
                    if ((obj[i].y - obj[j].y) < Number(w?.templateJson.rangeY) && (obj[j].y - obj[i].y) < Number(w?.templateJson.rangeY)) {
                        if ((obj[i].x + obj[i].width) > (obj[j].x - Number(w?.templateJson.rangeX)) && (obj[i].x + obj[i].width) < (obj[j].x + Number(w?.templateJson.rangeX))) {
                            bComp = false;
                            ii = i;
                            jj = j;
                            break;

                        } else if ((obj[j].x + obj[j].width) > (obj[i].x - Number(w?.templateJson.rangeX)) && (obj[j].x + obj[j].width) < (obj[i].x + Number(w?.templateJson.rangeX))) {
                            bComp = false;
                            ii = i;
                            jj = j;
                            break;
                        }

                    }
                }
                if (bComp) {
                    console.log("1")
                }
                if (!bComp) {
                    break;
                }
            }

            if (!bComp) {
                obj = mergeObject(obj[ii], obj[jj], ii, jj, obj)
                // processSlider(tI)

            }
        } while (!bComp);
        w.ocrJson.list = obj;

        



        var getData = function (x, y) {
            for (var i = 0; i < w?.ocrJson?.list.length; i++) {
                if (y <= w?.ocrJson?.list[i].y + w?.ocrJson?.list[i].height && y >= w?.ocrJson?.list[i].y) {
                    if (x <= w?.ocrJson?.list[i].x + w?.ocrJson?.list[i].width && x >= w?.ocrJson?.list[i].x) {
                        return w?.ocrJson?.list[i]
                    }
                }
                /*if (w?.ocrJson?.list[i].x == x && w?.ocrJson?.list[i].y == y) {
                    return w?.ocrJson?.list[i]
                }*/
            }
        }

        for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
            var points = w?.templateJson?.fields[i].points;
            w.templateJson.fields[i].value = "";
            for (var j = 0; j < points.length; j++) {
                var data = getData(points[j].x, points[j].y) /* getMouseClick({
                    clientX: points[j].x,
                    clientY: points[j].y,
                });*/

                if (data) {
                    if (w.templateJson.fields[i].value.length == 0) {
                        w.templateJson.fields[i].value = data.text;
                    } else {
                        w.templateJson.fields[i].value = w?.templateJson?.fields[i].value + " " + data.text;
                    }
                    
                }
            }
        }

        for (var i = 0; i < w.templateJson.cost_items?.length; i++) {
            
            for (var k = 0; k < w.templateJson.cost_items[i].items.length; k++) {
                w.templateJson.cost_items[i].items[k].label = "";
                var points = w.templateJson.cost_items[i].items[k].points ;
                for (var j = 0; j < points.length; j++) {
                    var data = getData(points[j].x, points[j].y) 

                    if (data) {
                        if (w.templateJson.cost_items[i].items[k].label.length == 0) {
                            w.templateJson.cost_items[i].items[k].label = data.text;
                        } else {
                            w.templateJson.cost_items[i].items[k].label = w.templateJson.cost_items[i].items[k].label + " " + data.text;
                        }

                    }
                }
            }
        }


        //setSlider(Number(w?.templateJson?.rangeX))
        //setSliderY(Number(w?.templateJson?.rangeY))
        setSliderOBj({ value: w?.templateJson?.rangeX })
        setSliderOBjY({ value: w?.templateJson?.rangeY })

        dispatch(setPdfData(w.ocrJson.list))
        setWorkspace(w)
        window.setTimeout(function () { drawGrid_2() },10)
    }
    function getMouseClick(event) {
        var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
        var elem11 = document.getElementsByClassName('react-pdf__Page__textContent');
        var pdfDoc = document.getElementsByClassName('react-pdf__Document');
        var sTop = pdfDoc[0].scrollTop;
        window.setTimeout(function () {
            var pdfDoc1 = document.getElementsByClassName('react-pdf__Document');
            pdfDoc1[0].scrollTop = sTop;
        }, 500)

        if (canvas[0]) {
            var rect = canvas[0].getBoundingClientRect();
            var x1 = event.clientX - rect.left;
            var y1 = event.clientY - rect.top;
            for (var i = 0; i < pdfData.length; i++) {
                var x = pdfData[i].x * elem11[0].offsetWidth / pdfHeightWidth.h;
                var y = pdfData[i].y * elem11[0].offsetHeight / pdfHeightWidth.w;
                var h = (pdfData[i].height) * elem11[0].offsetHeight / pdfHeightWidth.w;
                var w = (pdfData[i].width) * elem11[0].offsetWidth / pdfHeightWidth.h;



                if (x1 >= x && x1 <= x + w) {
                    if (y1 >= y && y1 <= y + h) {
                        var dat = {
                            x: x1 * pdfHeightWidth.h / elem11[0].offsetWidth,
                            y: y1 * pdfHeightWidth.w / elem11[0].offsetHeight,
                            height: pdfData[i].height,
                            width: pdfData[i].width,
                            text: pdfData[i].text,
                        }
                        return dat
                    }
                }
            }
        }
        return false;
    }

    const drawGrid_2 = () => {
        // return;
        var elem11 = document.getElementsByClassName('react-pdf__Page__textContent');
        // if (elem11.length == 0|| !bDraw) {            
        if (elem11.length == 0) {
            window.setTimeout(drawGrid_2, 1500);
            return;
        }
        var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
        var ctx = null;
        if (canvas[0]) {
            var div = document.getElementById("dynamicId");
            //var style = elem11[0].style;
            //div.style.position = "absolute"
            div.style.top = canvas[0].getBoundingClientRect().top + "px";
            div.style.left = canvas[0].getBoundingClientRect().left + "px";
            div.style.width = canvas[0].getBoundingClientRect().width + "px";
            div.style.height = canvas[0].getBoundingClientRect().height + "px";

            //div.style.background = "red";
            //div.id = "dynamicId"
            //document.body.appendChild(div)
            ctx = canvas[0].getContext('2d');
            //ctx.clearRect(0, 0, canvas[0].width, canvas[0].height);

            /*canvas.addEventListener('click', function (evt) {
                var data = getMousePos(canvas, evt);
                console.log(data)
                
            }, false);*/
        }
        for (var i = 0; i < pdfData.length; i++) {


            var x = pdfData[i].x * elem11[0].offsetWidth / pdfHeightWidth.h;
            var y = pdfData[i].y * elem11[0].offsetHeight / pdfHeightWidth.w;
            var h = (pdfData[i].height) * elem11[0].offsetHeight / pdfHeightWidth.w;
            var w = (pdfData[i].width) * elem11[0].offsetWidth / pdfHeightWidth.h;
            if (ctx) {
                ctx.beginPath();
                //ctx.fillText(pdfData[i].text + window.devicePixelRatio,x,y+h)
                ctx.strokeStyle = "#000000";
                ctx.lineWidth = 1;

                //ctx.rect(x-2, y-2, w+4, h+4)
                ctx.rect(x - 2 < 0 ? 0 : (x * window.devicePixelRatio - 2), y - 2 < 0 ? 0 : (y * window.devicePixelRatio - 2), w * window.devicePixelRatio + 4, h * window.devicePixelRatio + 4);
                ctx.stroke();
            }
        }
    }
    const handleSubmission = () => {
        var fileInput = document.getElementById('file');
        var element = document.getElementById("file_container");
        if (fileInput) {
            element.removeChild(fileInput);
        }
        var x = document.createElement("INPUT");
        x.setAttribute("type", "file");
        x.setAttribute("id", 'file');
        x.style.display = "none";
        element.appendChild(x);
        clearData()
        document.getElementById("file").addEventListener("change", changeHandler, true);
        document.getElementById('file').click();

    };
    var cordinates = {
        origin: [0, 0],
        target: [0, 0]
    }
    const [field, setField] = useState("");
    const [listText, setListText] = useState("");
    const [checked, setChecked] = useState(false);
    const handleTemplateTable = (event, data) => {
        setChecked(event.target.checked);
        // setValue(prev => ({ ...prev, params: t }))
    }
    const [rValue, setRvalue] = useState(0);
    const handleRChange = (event) => {
        setRvalue(event.target.value);
    };
    const handleClose = () => {
        setAnchorEl(null);
        setFileMemuOpen(false);
    };
    const handleCloseWorkspace = () => {
        setAnchorElWorkspace(null);
        setWorkspaceMemuOpen(false);
    };
    const [bFileMemuOpen, setFileMemuOpen] = useState(false);
    const handleClick = event => {
        setFileMemuOpen(true);
        setAnchorEl(event.currentTarget);
    };
    const [bWorkspaceMemuOpen, setWorkspaceMemuOpen] = useState(false);
    const handleWorkspaceClick = event => {
        setWorkspaceMemuOpen(true);
        setAnchorElWorkspace(event.currentTarget);
    };
    const [anchorElWorkspace, setAnchorElWorkspace] = useState(null);
    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const openWorkspace = Boolean(anchorElWorkspace);
    const StyledMenu = styled(props => (
        <Menu
            elevation={0}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
            }}
            transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
            }}
            {...props}
        />
    ))(({ theme }) => ({
        '& .MuiPaper-root': {
            borderRadius: 6,
            minWidth: 180,
            color: theme.palette.mode === 'light' ? 'rgb(55, 65, 81)' : theme.palette.grey[300],
            boxShadow:
                'rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px',
            '& .MuiMenu-list': {
                padding: '4px 0',
            },
            '& .MuiMenuItem-root': {
                '& .MuiSvgIcon-root': {
                    fontSize: 18,
                    color: theme.palette.text.secondary,
                    marginRight: theme.spacing(1.5),
                },
                '&:active': {
                    backgroundColor: alpha(theme.palette.primary.main, theme.palette.action.selectedOpacity),
                },
            },
        },
    }));

    return (
        <Paper sx={{ width: '100%', overflow: 'hidden', maxHeight: '98.3vh' }}>
            <div id="dynamicId" onMouseDown={(e) => {
                handleMouseClick(e)
            }} style={{ zIndex: "999", position: "absolute", top: 0, left: 0, height: 0, width: 0 }}></div>

                {openItemCreationModal && (
                <CustomItemDlg handleMergeData={handleMergeData} open={openItemCreationModal} title={'Item Selection'} onHandleCancel={onHandleCancelItemCreation} />
            )}
            {openItemSelectionOrderModal && (
                <Dialog maxWidth={'xl'} sx={{ background: '#f5f5f8', minWidth: '50vw', color: '#232028' }} open={openItemSelectionOrderModal} title={'Item Selection'} onHandleCancel={onHandleCancelItemSelectionModal}>
                    <Grid justifyContent='flex-start' container item lg={12} >
                        <RadioGroup
                            aria-labelledby="demo-controlled-radio-buttons-group"
                            name="controlled-radio-buttons-group"
                            value={rValue}
                            onChange={handleRChange}
                            style={{ width: '100%' }}
                        >
                            <TableContainer>
                                {Object.keys(mergeData)?.length > 0 && Object.keys(mergeData).map((dData1, index1) => (
                                    <Table sx={{ marginTop: 2 }}>
                                        <TableBody>
                                            <TableRow sx={{ '& > *': { border: '', fontSize: '14px !important', margin: 0, padding: '10px',  } }} onClick={function () {
                                                setRvalue(dData1);
                                                dispatch(setSelectedItemSelection(dData1))
                                                var tI1 = { ...selectedTemplate, numPage: dData1, text: dData1 }
                                                dispatch(setSelectedTemplate(tI1));
                                                var tArr = []
                                                for (var i = 0; i < templateList.length; i++) {
                                                    var tI = JSON.parse(JSON.stringify(templateList[i]));

                                                    if (tI1.id == tI.id) {
                                                        tI.numPage = dData1;
                                                        tI.text = dData1;
                                                    }
                                                    tArr.push(tI)
                                                }
                                                dispatch(setTemplates(tArr))
                                                dispatch(setMoreRowDocData(mergeData[dData1]))
                                            }}>

                                                <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px' }} >

                                                    <ListItemButton>
                                                        <FormControlLabel style={{ fontSize: '0.8rem', maxWidth: '40vw', padding: '5px', color: '#232028' }} value={dData1} control={<Radio color={'warning'} />} label={mergeData[dData1][0][0] + ", " + mergeData[dData1][0][1] + " ...."} />
                                                    </ListItemButton>

                                                </TableCell>
                                            </TableRow>

                                        </TableBody>
                                    </Table>
                                ))
                                }
                            </TableContainer>
                        </RadioGroup>
                    </Grid>

                </Dialog>
            )}
            {openItemIdentifierOrderModal && (
                <Dialog maxWidth={'xl'} sx={{ background: '#f5f5f8', minWidth: '50vw', color: '#232028' }} open={openItemIdentifierOrderModal} title={'Item Identifier'} onHandleCancel={onHandleCancelItemIdentifierModal}>
                    <Grid justifyContent='flex-start' container item lg={12} >
                        <TableContainer>
                            <Table>
                                <TableBody>
                                    <TableRow sx={{ '& > *': { borderBottom: 'none', fontSize: '10px !important', margin: 0, padding: '1px',  } }}>
                                        {moreRowDocData?.length > 0 && moreRowDocData[0].map((dData, index) => (

                                            <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px' }} >

                                                {index < moreRowDocData[0].length - 2 && <Grid justifyContent='flex-start' container item lg={12} >
                                                    <Grid sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} item lg={12} >
                                                        Header-{index + 1}
                                                    </Grid>
                                                    <Grid sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginTop: -1.6 }} item lg={12} >
                                                        <Button variant='contained' sx={{ mt: 2 }}  onClick={function () {

                                                            dispatch(setSelectedIdentifier(index))
                                                            var tI1 = { ...selectedTemplate, numPage: index, text: 'Header- ' + (index + 1) }
                                                            dispatch(setSelectedTemplate(tI1));
                                                            var tArr = []
                                                            for (var i = 0; i < templateList.length; i++) {
                                                                var tI = JSON.parse(JSON.stringify(templateList[i]));

                                                                if (tI1.id == tI.id) {
                                                                    tI.numPage = index;
                                                                    tI.text = 'Header- ' + (index + 1);
                                                                }
                                                                tArr.push(tI)
                                                            }
                                                            dispatch(setTemplates(tArr))
                                                        }}>
                                                            {dData}
                                                        </Button>
                                                    </Grid>

                                                </Grid>
                                                }

                                            </TableCell>
                                        ))
                                        }
                                    </TableRow>

                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Grid>
                    <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                        <Button variant='text' sx={{ display: 'flex', justifyContent: 'end', alignItems: 'end', marginTop: 2, textTransform: 'none !important', fontWeight: 'bold', fontSize: '16px' }}  onClick={function () { }}>
                            Selected Item Identifier Header-{selectedIdentifier + 1}
                        </Button>
                    </Box>
                </Dialog>
            )}
            {openItemOrderModal && (
                <Dialog maxWidth={'xl'} sx={{ background: '#f5f5f8', color: '#232028' }} open={openItemOrderModal} title={'Items'} onHandleCancel={onHandleCancelItemModal}>

                    {/*{workspace?.templateJson?.cost_items?.map((t, index) => (<>*/}
                    {itemList?.map((t, index) => (<>
                        <Grid container item key={uuidv4()}>
                            <TextButton sx={{ ml: 0, mt: 0, padding: 0 }} onClick={function (event) {
                                var temp = JSON.parse(JSON.stringify(itemList))
                                temp.splice(index, 1)
                                setItemList(temp)
                            }} style={{ fontSize: 17, color: '#131119' }}>
                                <FaMinus style={{ marginRight: 1, padding: 5 }} />
                            </TextButton>

                            <TextField
                                lg={10}
                                value={t.label}
                                onBlur={event => {
                                    var temp = JSON.parse(JSON.stringify(itemList))
                                    temp[index].label = event.target.value;
                                    temp[index].index = index;
                                    setItemList(temp)

                                }}
                                color={'#232028'}
                                label={'Item Name'}
                            />
                        </Grid>
                    </>))}
                    <Button variant='text'  onClick={function () {
                        var w = JSON.parse(JSON.stringify(workspace))
                        if (!workspace?.templateJson?.cost_items) {

                            if (!w.templateJson) {
                                w.templateJson = {
                                    cost_items: []
                                }
                            } else {
                                w.templateJson.cost_items = []
                            }


                        }
                        /* w?.templateJson?.cost_items?.push({*/
                        var lastI = lastId + 1;
                        setLastId(lastI)
                        var items = [...itemList]
                        items?.push({
                            index: "",
                            label: "",
                            items: [
                                {
                                    id: lastI,
                                    label: "",
                                    value: "",
                                    points: []
                                }
                            ]
                        })
                        setItemList(items)
                        //setWorkspace(w)

                    }}>
                        +  Add
                    </Button>

                    <Button variant='text'  onClick={function () {
                        var w = JSON.parse(JSON.stringify(workspace))
                        if (!workspace?.templateJson?.cost_items) {

                            if (!w.templateJson) {
                                w.templateJson = {
                                    cost_items: []
                                }
                            } else {
                                w.templateJson.cost_items = []
                            }


                        }
                        w.templateJson.cost_items = [...itemList]

                        setWorkspace(w)
                        onHandleCancelItemModal()
                    }}>
                        OK
                    </Button>
                </Dialog>
            )}

            {openWorkspaceOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: 'black' }} open={openWorkspaceOrderModal} title={'Workspace'} onHandleCancel={onHandleCancelWorkspaceModal}>
                    <Grid container item justifyContent='center' lg={12}>
                        <TextField
                            lg={9}
                            value={workspaceName}
                            onChange={event => setWorkspaceName(event.target.value)}
                            color={'#232028'}
                            label={'Workspace Name'}
                        />
                    </Grid>
                    <Grid container item justifyContent='center' lg={12}>
                        <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                            dispatch(setDocs([]));
                            addWorkspace(dispatch, {
                                name: workspaceName,
                                userId: admin?.data?.data?.id
                            }, function (data) {
                                console.log(data)
                                if (data.data.status == 5) {
                                    dispatch(snackbarToggle({ type: 'error', message: data.data.message }));
                                    return;
                                }
                                setWorkspace(data.data)
                                clearData()
                                onHandleCancelWorkspaceModal();
                            })
                        }}>
                            Save
                        </Button>
                        <Button variant='contained' sx={{ mt: 2 }}  onClick={onHandleCancelWorkspaceModal}>
                            Cancel
                        </Button>
                    </Grid>
                </Dialog>
            )}

            {openMergeOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: 'black' }} open={openMergeOrderModal} title={'Merge'} onHandleCancel={() => {


                    onHandleCancelMergeModal()
                }}>
                    <Grid container item justifyContent='center' alignItems="center" alignContent="center" lg={12}>
                        <Grid container item justifyContent='center' alignItems="center" alignContent="center" lg={12}>
                            Are you sure. You want to merge.
                        </Grid>
                        <Grid container item justifyContent='center' alignItems="center" alignContent="center" lg={12}>
                            <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                                clearTemplateTextPoints();
                                //processSlider(workspace?.ocrJson?.orgList)
                                processSlider(selectedInvoiceData?.orglist)
                               
                                onHandleCancelMergeModal()
                            }}>
                                OK
                            </Button>
                        </Grid>
                    </Grid>

                </Dialog>
            )}

            {openWorkspaceListOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: '#232028' }} open={openWorkspaceListOrderModal} title={'WorkspaceList'} onHandleCancel={() => {

                    applyWorkSpace()
                    onHandleCancelWorkspaceListModal()
                }}>
                    <Grid container item justifyContent='center' lg={12}>
                        <SelectField
                            
                            value={workspace?.id}
                            lg={12}
                            onChange={function (event) {
                                var w = workspaceList.find(role => role.id === event.target.value);
                                /*const type = 'application/pdf';
                                let base64data = `data:${type};base64,${w?.ocrJson?.fileBase64}`;

                                if (w?.ocrJson?.fileBase64) {
                                    dispatch(onChangeDocs({
                                        uri: base64data
                                    }))
                                }

                                dispatch(setPdfData(w?.ocrJson?.list))
                                dispatch(setPdfHeightWidth({
                                    h: w?.ocrJson?.fileWidth,
                                    w: w?.ocrJson?.fileHeight,
                                }))*/
                                setWorkspace(w)

                                //setWorkspace(prev => ({ ...prev, id: response1.data.template.name }))

                            }}
                            bNew={true}
                            callBackForNew={function (data, itm) {

                            }}
                            msx={{ color: "white" }}
                            label={""}
                            options={workspaceList}
                        />
                        <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                            
                            applyWorkSpace()
                            onHandleCancelWorkspaceListModal()
                        }}>
                            OK
                        </Button>
                    </Grid>

                </Dialog>
            )}
            {openManageTemplateOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: 'black' }} open={openManageTemplateOrderModal} title={'Manage Template'} onHandleCancel={() => {
                    onHandleCancelManageTemplateModal()
                }}>
                    <Grid container item justifyContent='flex-start' lg={12} >
                        <Grid container item justifyContent='flex-start' lg={6}>
                            <Button variant='contained' sx={{ mt: 2, mr: 2, background: bActiveTemplate ? "green" : "" }} onClick={function () {
                                //getActiveInactiveTemplateList
                                setBActiveTemplate(true)
                                getActiveInactiveTemplateList(dispatch, { trash: false }, function (data) {
                                    setListOfTemplates(data.data)
                                })
                            }}>
                                Active
                            </Button>
                            <Button variant='contained' sx={{ mt: 2, mr: 2, background: !bActiveTemplate ? "green" : "" }} onClick={function () {
                                setBActiveTemplate(false)
                                getActiveInactiveTemplateList(dispatch, { trash: true }, function (data) {

                                    setListOfTemplates(data.data)
                                })
                            }}>
                                History
                            </Button>
                        </Grid>
                        {bActiveTemplate && < Grid container item justifyContent='flex-start' lg={12} sx={{ border: "1px solid", marginTop: "10px", height: "60vh", overflow: "auto", width: "100vw" }} alignContent="flex-start">

                            {listOfTemplates?.map((t, index) => (<>

                                {!t.trash && <Grid container item justifyContent='flex-start' lg={12} justifyContent="flex-start" alignItems="flex-start" sx={{ ml: 2 }}>
                                    <Grid container item justifyContent='flex-start' lg={8}>
                                        {t.name} ({t.id})
                                    </Grid>
                                    <Grid container item justifyContent='flex-start' lg={4}>
                                        <Button disabled={t.id == Template?.id} variant='text' sx={{ m: 1 }} onClick={function () {
                                            var w = JSON.parse(JSON.stringify(t))
                                            w.trash = true;
                                            moveTemplateToTrashCurrent(dispatch, w, function (data) {

                                                getActiveInactiveTemplateList(dispatch, { trash: false }, function (data) {
                                                    setListOfTemplates(data.data)
                                                })
                                            })
                                        }}>
                                            <FaTrashAlt />
                                        </Button>
                                    </Grid>
                                </Grid>}
                            </>))}

                        </Grid>}
                        {!bActiveTemplate && <Grid container item justifyContent='center' lg={12} sx={{ border: "1px solid", marginTop: "10px", height: "60vh", overflow: "auto", width: "100vw" }} alignContent="flex-start">

                            {listOfTemplates?.map((t, index) => (<>

                                {t.trash && <Grid container item justifyContent='flex-start' lg={12} justifyContent="flex-start" alignItems="flex-start" sx={{ ml: 2 }}>
                                    <Grid container item justifyContent='flex-start' lg={8}>
                                        {t.name}
                                    </Grid>
                                    <Grid container item justifyContent='flex-start' lg={4}>
                                        <Button disabled={t.id == Template?.id} variant='text' sx={{ m: 1 }} onClick={function () {
                                            var w = JSON.parse(JSON.stringify(t))
                                            w.trash = false;
                                            moveTemplateToTrashCurrent(dispatch, w, function (data) {

                                                getActiveInactiveTemplateList(dispatch, { trash: true }, function (data) {
                                                    setListOfTemplates(data.data)
                                                })
                                            })
                                        }}>
                                            <FaUndo />
                                        </Button>
                                    </Grid>
                                </Grid>}
                            </>))}

                        </Grid>
                        }
                    </Grid>

                </Dialog>
            )}

            {openManageWorkspaceOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: 'black' }} open={openManageWorkspaceOrderModal} title={'Manage Workspace'} onHandleCancel={() => {
                    onHandleCancelManageWorkspaceModal()
                }}>
                    <Grid container item justifyContent='flex-start' lg={12} >
                        <Grid container item justifyContent='flex-start' lg={6}>
                            <Button variant='contained' sx={{ mt: 2, mr: 2, background: bActiveWorkspace?"green":"" }} onClick={function () {
                                //getActiveInactiveWorkspaceList
                                setBActiveWorkspace(true)
                                getActiveInactiveWorkspaceList(dispatch, {trash:false}, function (data) {
                                    setWorkspaceList(data.data)
                                })
                            }}>
                                Active
                            </Button>
                            <Button variant='contained' sx={{ mt: 2, mr: 2, background: !bActiveWorkspace ? "green" : "" }} onClick={function () {
                                setBActiveWorkspace(false)
                                getActiveInactiveWorkspaceList(dispatch, { trash: true }, function (data) {

                                    setWorkspaceList(data.data)
                                })
                            }}>
                                History
                            </Button>
                        </Grid>
                        {bActiveWorkspace && < Grid container item justifyContent='flex-start' lg={12} sx={{ border: "1px solid", marginTop: "10px", height: "60vh", overflow:"auto" }} alignContent="flex-start">

                            {workspaceListAll?.map((t, index) => (<>

                                {!t.trash && <Grid container item justifyContent='flex-start' lg={12} justifyContent="flex-start" alignItems="flex-start" sx={{ml:2}}>
                                    <Grid container item justifyContent='flex-start' lg={8}>
                                        {t.name}
                                    </Grid>
                                    <Grid container item justifyContent='flex-start' lg={4}>
                                        <Button disabled={t.id == workspace?.id} variant='text' sx={{ m: 1 }} onClick={function () {
                                            var w = JSON.parse(JSON.stringify(t))
                                            w.trash = true;
                                            updateWorkspace(dispatch, w, function (data) {
                                                if (data.status == 1) {
                                                    dispatch(snackbarToggle({ type: 'success', message: 'Workspace moved to history successfully' }));
                                                    getWorkspaceList(dispatch, {}, function (data) {
                                                        setWorkspaceListAll(data.data)
                                                    })
                                                }

                                            })
                                        }}>
                                            <FaTrashAlt />
                                        </Button>
                                    </Grid>
                                </Grid>}
                            </>))}

                        </Grid>}
                        {!bActiveWorkspace && <Grid container item justifyContent='center' lg={12} sx={{ border: "1px solid", marginTop: "10px", height: "60vh", overflow: "auto" ,width:"100vw"}} alignContent="flex-start">

                            {workspaceListAll?.map((t, index) => (<>

                                {t.trash && <Grid container item justifyContent='flex-start' lg={12} justifyContent="flex-start" alignItems="flex-start" sx={{ ml: 2 }}>
                                    <Grid container item justifyContent='flex-start' lg={8}>
                                        {t.name}
                                    </Grid>
                                    <Grid container item justifyContent='flex-start' lg={4}>
                                        <Button disabled={t.id == workspace?.id} variant='text' sx={{ m: 1 }} onClick={function () {
                                            var w = JSON.parse(JSON.stringify(t))
                                            w.trash = false;
                                            updateWorkspace(dispatch, w, function (data) {
                                                if (data.status == 1) {
                                                    dispatch(snackbarToggle({ type: 'success', message: 'Workspace restored successfully' }));
                                                    getWorkspaceList(dispatch, {}, function (data) {
                                                        setWorkspaceListAll(data.data)
                                                    })
                                                }

                                            })
                                        }}>
                                            <FaUndo />
                                        </Button>
                                    </Grid>
                                </Grid>}
                            </>))}

                        </Grid>
                        }
                    </Grid>

                </Dialog>
            )}

            {openTemplateListOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: '#232028' }} open={openTemplateListOrderModal} title={'Template List'} onHandleCancel={onHandleCancelTemplateListModal}>
                    <Grid container item justifyContent='center' lg={12}>
                        <SelectField
                            value={template.id}
                            lg={12}
                            onChange={function (event) {
                                var w = listOfTemplates.find(role => role.id === event.target.value);
                                setTemplate(w)
                            }}
                            bNew={true}
                            callBackForNew={function (data, itm) {

                            }}
                            msx={{ color: "white" }}
                            label={""}
                            options={listOfTemplates}
                        />
                        <Button variant='contained' sx={{ mt: 2 }}  onClick={() => {
                            var w = listOfTemplates.find(role => role.id === template.id);
                           // setTemplate(w)
                            var work = JSON.parse(JSON.stringify(workspace))
                            work.templateJson = w.templateJson
                           
                            handleMouseClick1(work)
                            //getMouseClick(event);
                            onHandleCancelTemplateListModal()
                        }}>
                            OK
                        </Button>
                    </Grid>

                </Dialog>
            )}
            {openTemplateOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: '#232028' }} open={openTemplateOrderModal} title={'Template'} onHandleCancel={onHandleCancelTemplateModal}>

                    <TextField
                        lg={9}
                        value={value.name}
                        onChange={event => setValue(prev => ({ ...prev, name: event.target.value }))}
                        color={'#232028'}
                        label={'Template Name'}
                    />
                    {!listOfTemplates.find(role => role.name === value.name) && <FormLabel sx={{ color: "green" }}>New Template with name {value.name} will be added.</FormLabel>}
                    {listOfTemplates.find(role => role.name === value.name) && <FormLabel sx={{ color: "red" }}>Are you sure, you want to update {value.name} template.</FormLabel>}
                    <Grid container item justifyContent='flex-end' lg={12}>
                        <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                            var t = { ...workspace?.templateJson, rangeX: sliderObj.value, rangeY: sliderObjY.value }
                            addTemplate(dispatch, {
                                userId: admin?.data?.data?.id,
                                name: value.name,
                                templateJson: t
,

                            }, function () {
                                onHandleCancelTemplateModal()
                            })
                        }}>
                            Save
                        </Button>
                        <Button variant='contained' sx={{ mt: 2 }}  onClick={onHandleCancelTemplateModal}>
                            Cancel
                        </Button>
                    </Grid>
                </Dialog>
            )}
            {openTemplateTableOrderModal && (
                <Dialog sx={{ background: '#f5f5f8', minWidth: '35vw', color: '#232028' }} open={openTemplateTableOrderModal} title={'Template List'} onHandleCancel={onHandleCancelTemplateTableModal}>
                    <TextField
                        lg={12}
                        value={listText}
                        onChange={function (event) {
                            setListText(event.target.value)
                            var tArr = []
                            for (var i = 0; i < templateTableList.length; i++) {
                                var tI = JSON.parse(JSON.stringify(templateTableList[i]));

                                if (tI.name.trim().toLowerCase().includes(event.target.value.toLowerCase())) {
                                    tArr.push(tI)
                                }
                            }
                            if (event.target.value.length == 0) {
                                tArr = [...templateTableList]
                            }
                            setTemplateTableList2(tArr)
                        }}
                        color={'#232028'}
                        label={'Search list item'}
                    />
                    <Grid container item justifyContent='flex-start' alignItems='flex-start' alignContent="flex-start" lg={12} sx={{ minHeight: '500px', maxHeight: '500px', minWidth: '35vw !important', maxWidth: '35vw !important', overflow: 'auto', border: '1px solid gray' }}>

                        {templateTableList2.map((t, index) => (
                            <Grid key={t?.id || uuidv4()} container item justifyContent='flex-start' alignItems='flex-start' alignContent="flex-start" lg={12} sx={{ marginTop: 1 }}>
                                {false && <FormControlLabel control={<Checkbox checked={checked} onChange={function (event) {
                                    setChecked(event.target.checked);
                                }} />} label={t.name} />}
                                {false && <FormLabel sx={{ color: '#232028' }}> {t.name}</FormLabel>}


                                {false && <Button onClick={function () {
                                    getTemplate(dispatch, t.id, function (response) {
                                        setValue(prev => ({ ...prev, name: response.data.name }))
                                        dispatch(setSelectedTemplateTable((response.data)));
                                        var list = JSON.parse(response.data.data);
                                        var t = [...templateList];
                                        for (var j = 0; j < t.length; j++) {
                                            var tI = JSON.parse(JSON.stringify(t[j]));
                                            tI.bSelected = false;
                                            for (var i = 0; i < list.length; i++) {
                                                list[i].bSelected = false;
                                                if (list[i].id == tI.id) {
                                                    tI = list[i];
                                                }
                                            }
                                        }

                                        dispatch(setTemplates(t));
                                    })
                                    onHandleCancelTemplateTableModal();
                                }} variant='contained'>
                                    Select
                                </Button>}
                                <ListItem style={{ background: (selectedTemplateTable.id == t.id ? '#515052' : '') }} key={index} component="div" disablePadding>
                                    <ListItemButton onClick={function () {
                                        getTemplate(dispatch, t.id, function (response) {
                                            setValue(prev => ({ ...prev, name: response.data.name }))
                                            dispatch(setSelectedTemplateTable((response.data)));
                                            var list = JSON.parse(response.data.data);
                                            var t = [...templateList];
                                            var t1 = [];
                                            for (var j = 0; j < t.length; j++) {
                                                var tI = JSON.parse(JSON.stringify(t[j]));
                                                tI.bSelected = false;
                                                for (var i = 0; i < list.length; i++) {
                                                    list[i].bSelected = false;
                                                    if (list[i].id == tI.id) {
                                                        tI = list[i];
                                                        break;
                                                    }
                                                }
                                                t1.push(tI)
                                            }

                                            dispatch(setTemplates(t1));
                                        })
                                    }}>
                                        <ListItemAvatar>
                                            <TableViewOutlined />
                                        </ListItemAvatar>

                                        <ListItemText primary={t.name} />
                                    </ListItemButton>
                                </ListItem>

                            </Grid>
                        ))}
                    </Grid>
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Button sx={{ mt: 2, mr: 2 }} onClick={function () {
                            onHandleCancelTemplateTableModal();
                        }} variant='contained'>
                            Ok
                        </Button>
                    </Box>
                </Dialog>
            )}
            {openHeaderOrderModal && (
                <Dialog open={openHeaderOrderModal} title={'Header'} onHandleCancel={onHandleCancelHeaderModal}>
                    <Header data={null} onHandleCancel={onHandleCancelHeaderModal} id={null} />
                </Dialog>
            )}
            {openOrderModal && (
                <Dialog open={openOrderModal} title={'Add Field'} onHandleCancel={onHandleCancelModal}>
                    <Grid container item>

                        <TextField
                            lg={12}
                            value={field}
                            onChange={function (event) {
                                setField(event.target.value)

                                //setTemplateTableList2(tArr)
                            }}
                            color={'black'}
                            label={'Field'}
                        />
                    </Grid>
                    <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <Button sx={{ mt: 2, mr: 2 }} onClick={function () {
                            var w = JSON.parse(JSON.stringify(workspace))
                            if (!workspace?.templateJson?.fields) {
                                if (!w.templateJson) {
                                    w.templateJson = {
                                        fields: []
                                    }
                                } else {
                                    w.templateJson.fields = []
                                }

                            }
                            var lastI = lastId + 1;
                            setLastId(lastI)
                            w?.templateJson?.fields?.push({
                                label: field,
                                value: "",
                                id: lastI,
                                points: []
                            })
                            setWorkspace(w)
                            onHandleCancelModal();
                        }} variant='contained'>
                            Add
                        </Button>
                    </Box>
                </Dialog>
            )}

            <Grid container item spacing={2} lg={12} sx={{ height: '95%' }} justifyContent='flex-start'>
                <Grid container item spacing={2} lg={12} justifyContent='flex-start'>
                    <AppBar
                        position='static'
                        elevation={0}
                        className='appbar'
                        style={{
                            marginBottom: 0,
                            borderBottom: '2px solid #1e1a22',
                            backgroundColor: '#f5f5f8',
                            color: '#131119',
                            alignItems: 'center',
                            flexDirection: 'start',
                            width: 'calc(100vw - 1px)',
                        }}>

                        {(
                            <Toolbar style={toolbarStyle} id="file_container">
                                <TextButton sx={{ ml: 1, mt: 1, padding: 1 }} style={{ fontSize: 17 }}>
                                    {lastId}   <img src={logo} style={{ width: "50px" }} />
                                </TextButton>
                                {admin?.data?.data?.id &&<Grid container item lg={12} >
                                <Grid container item lg={8} >
                                
                                <Button onClick={handleClick} variant='outlined' sx={{ ml: 1, mt: 1, padding: 1,border: 'none !important' }} >
                                    {`File`} {!bFileMemuOpen ? <FaAngleDown style={{ width: "30px", height: "20px" }} /> : <FaAngleUp style={{ width: "30px", height: "20px" }} />}
                                </Button>


                                <StyledMenu
                                    id='demo-customized-menu'
                                    MenuListProps={{
                                        'aria-labelledby': 'demo-customized-button',
                                    }}
                                    anchorEl={anchorEl}
                                    open={open}
                                    onClick={handleClose}>
                                    {
                                        <Link key={uuidv4()} to='/file' onClick={function (event) { onHandleOpenWorkspaceModal() }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                            <MenuItem onClick={handleClose}> New Workspace</MenuItem>
                                        </Link>
                                    }
                                    {
                                        <Link key={uuidv4()} to='/file' onClick={function (event) {

                                            onHandleOpenWorkspaceListModal()
                                        }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                            <MenuItem onClick={handleClose}> Open Workspace</MenuItem>
                                        </Link>   
                                    }
                                    {
                                        <Link key={uuidv4()} to='/file' onClick={function (event) {
                                            setBActiveWorkspace(true)
                                            onHandleOpenManageWorkspaceModal()
                                        }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                            <MenuItem onClick={handleClose}> Manage Workspace</MenuItem>
                                        </Link>   
                                    }
                                    {
                                        <Link key={uuidv4()} to='/file' onClick={function (event) {
                                            setBActiveTemplate(true)
                                            onHandleOpenManageTemplateModal()
                                        }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                            <MenuItem onClick={handleClose}> Manage Template</MenuItem>
                                        </Link>   
                                    }
                                    {
                                        <Link key={uuidv4()} to='/logout' onClick={function (event) {
                                            //navigate("/login");
                                            //setIsLogin(false)
                                            window.location = "/"
                                        }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                            <MenuItem onClick={handleClose}> Logout</MenuItem>
                                        </Link>   
                                    }
                                        </StyledMenu>
                                        <Button onClick={handleWorkspaceClick} variant='outlined' sx={{ ml: 1, mt: 1, padding: 1, border: 'none !important' }} >
                                            {`Workspace`} {!bWorkspaceMemuOpen ? <FaAngleDown style={{ width: "30px", height: "20px" }} /> : <FaAngleUp style={{ width: "30px", height: "20px" }} />}
                                        </Button>
                                        <StyledMenu
                                            id='demo-customized-menu'
                                            MenuListProps={{
                                                'aria-labelledby': 'demo-customized-button',
                                            }}
                                            anchorEl={anchorElWorkspace}
                                            open={openWorkspace}
                                            onClick={handleCloseWorkspace}>
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) { handleSubmission() }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Open invoice</MenuItem>
                                                </Link>
                                            }
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) {
                                                    dispatch(setPdfData(workspace?.ocrJson?.orgList))
                                                    var w = JSON.parse(JSON.stringify(workspace))
                                                    w.templateJson.cost_items = [];
                                                    w.templateJson.fields = [];
                                                    w.ocrJson.list = workspace?.ocrJson?.orgList;
                                                    setWorkspace(w)
                                                }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Reset Workspace</MenuItem>
                                                </Link>
                                            }
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) {
                                                    getActiveInactiveTemplateList(dispatch, { trash: false }, function (data) {
                                                        setListOfTemplates(data.data)
                                                    });
                                                    onHandleOpenTemplateListModal()
                                                }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Load  Template</MenuItem>
                                                </Link>
                                            }
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) {
                                                    onHandleOpenModal()
                                                }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Add Field</MenuItem>
                                                </Link>
                                            }
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) {
                                                    /*getActiveInactiveTemplateList(dispatch, null, function (data) {
                                                        dispatch(setTemplateTableList((data.data)));
                                                    });*/
                                                   // onHandleOpenTemplateModal()
                                                    var w = JSON.parse(JSON.stringify(workspace));
                                                    var tArr = []
                                                    for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(w?.templateJson?.fields[i]));
                                                        delete tI.value;
                                                        w.templateJson.fields[i] = tI;
                                                    }
                                                    for (var i = 0; i < w.templateJson.cost_items?.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(w.templateJson.cost_items[i]));
                                                        for (var j = 0; j < w.templateJson.cost_items[i].items.length; j++) {

                                                            delete w.templateJson.cost_items[i].items[j].value
                                                            delete w.templateJson.cost_items[i].items[j].label

                                                        }
                                                    }
                                                    console.log(w)
                                                    w.params.lastId = lastId;
                                                    updateWorkspace(dispatch, w, function (data) {
                                                        if (data.status == 1)
                                                            dispatch(snackbarToggle({ type: 'success', message: 'Workspace Template updated successfully' }));
                                                    })
                                                }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Save  Template</MenuItem>
                                                </Link>
                                            }
                                            {
                                                <Link key={uuidv4()} to='/file' onClick={function (event) {
                                                    var w = JSON.parse(JSON.stringify(workspace));
                                                    //w.templateJson.rangeX = sliderObj.value
                                                    //w.templateJson.rangeY = sliderObjY.value

                                                    updateWorkspace(dispatch, w, function (data) {
                                                        if (data.status == 1)
                                                            dispatch(snackbarToggle({ type: 'success', message: 'Workspace updated successfully' }));
                                                    })
                                                }} style={{ textDecoration: 'none', color: 'inherit', fontSize: 17 }}>
                                                    <MenuItem onClick={handleCloseWorkspace}> Save  Workspace</MenuItem>
                                                </Link>
                                            }
                                        </StyledMenu>
                                </Grid>
                                { <Grid container item lg={3} sx={{ marginTop: 0}} justifyContent='flex-end' alignContent='center' spacing={2}>
                                        <Grid container item lg={4} justifyContent='flex-end' >
                                    {<TextFieldLegacy
                                        lg={12}
                                        value={sliderObj.value}
                                        onChange={event => {
                                            setSliderOBj({ value: event.target.value })

                                        }}
                                        color={'#232028'}
                                        label={''}
                                        type={'number'}
                                        />}
                                    </Grid>
                                        <Grid container item lg={4} justifyContent='flex-end' >
                                    <TextFieldLegacy
                                        lg={12}
                                        value={sliderObjY.value}
                                        onChange={event => {
                                            setSliderOBjY({ value: event.target.value })
                                        }}
                                        color={'#232028'}
                                        label={''}
                                        type={'number'}
                                        />
                                    </Grid>
                                        <Grid container item lg={4} justifyContent='flex-end' >
                                    <TextButton sx={{ m: 0, padding: 0 }} onClick={function (event) {

                                        onHandleOpenMergeModal()
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                Merge 
                                            </TextButton>
                                           
                                        </Grid>
                                    {/*<TextButton sx={{ m: 2, padding: 0 }} onClick={function (event) {

                                        drawGrid_2()
                                        // setSlider(slider++)
                                    }} style={{ fontSize: 17, color: '#131119' }}>
                                        Redraw
                                    </TextButton>*/}
                                    </Grid>}
                                    </Grid>}
                                {admin?.data?.data?.id&&false &&<TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) { onHandleOpenWorkspaceModal() }} style={{ fontSize: 17, color: '#131119' }}>
                                    New Workspace
                                </TextButton>
                                }
                                {admin?.data?.data?.id && false &&<TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) {

                                    onHandleOpenWorkspaceListModal()
                                }} style={{ fontSize: 17, color: '#131119' }}>
                                    Open Workspace
                                </TextButton>
                                }
                                {admin?.data?.data?.id && false &&<TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) {
                                    setBActiveWorkspace(true)
                                    onHandleOpenManageWorkspaceModal()
                                }} style={{ fontSize: 17, color: '#131119' }}>
                                    Manage Workspace
                                </TextButton>
                                }
                                {admin?.data?.data?.id && false && <TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) {
                                    setBActiveTemplate(true)
                                    onHandleOpenManageTemplateModal()
                                }} style={{ fontSize: 17, color: '#131119' }}>
                                    Manage Template
                                </TextButton>
                                }
                                {isLogin && false && < TextButton sx={{ mt: 1 }} onClick={function (event) {
                                    //navigate("/login");
                                    //setIsLogin(false)
                                    window.location = "/"
                                }} style={{ fontSize: 17, color: '#131119', marginLeft: "45vw", }}>
                                    Logout
                                </TextButton>}
                                {!isLogin && < TextButton sx={{ mt: 1 }} onClick={function (event) {
                                    navigate("/login");
                                }} style={{ fontSize: 17, color: '#131119', marginLeft: "70vw", }}>
                                    Login
                                </TextButton>}
                                {!isLogin && < TextButton sx={{ mt: 1 }} onClick={function (event) {
                                    navigate("/register");
                                }} style={{ fontSize: 17, color: '#131119', marginLeft: "0vw", }}>
                                    Register
                                </TextButton>}

                            </Toolbar>
                        )}
                    </AppBar>
                </Grid>

                <Routes>
                    <Route exact path='/*' element={<> {isLogin ?
                        <>
                            <Grid container item lg={2} justifyContent={bOpenLeftPanal ? "flex-end" : "flex-start"} sx={{ zIndex: 99, mt: -2, cursor: "pointer" }}>
                                {bOpenLeftPanal && <FaArrowAltCircleLeft style={{ fill: "#232028" }} onClick={() => {
                                    setBOpenLeftPanal(!bOpenLeftPanal)
                                    window.setTimeout(drawGrid_2, 1000);
                                }} />}
                                {!bOpenLeftPanal && <FaArrowAltCircleRight style={{ fill: "#232028" }} onClick={() => {
                                    setBOpenLeftPanal(!bOpenLeftPanal)
                                    window.setTimeout(drawGrid_2, 1000);
                                }} />}
                            </Grid>
                            <Grid container item lg={10}>

                            </Grid>
                            {<Grid container item spacing={2} lg={12} style={{
                                color: '#131119',
                            }} justifyContent='flex-start' sx={{ mt: -4 }}>
                                {bOpenLeftPanal && <Grid container item lg={2} style={{
                                    backgroundColor: '#f5f5f8',
                                    minHeight: '91vh',
                                    overflow: 'auto',
                                    borderRight:"1px solid black"

                                }} justifyContent='flex-start' alignContent='flex-start' className="page-container">
                                    {false &&<Grid container item lg={12} sx={{ mt: -5 }}>

                                        {false && <ul className="x-navigation" >

                                            {
                                                templateList.map((t, index) => (
                                                    <li key={t?.id || uuidv4()} className="active" onClick={function () {
                                                        var tArr = []
                                                        for (var i = 0; i < templateList.length; i++) {
                                                            console.log(templateList[i])
                                                            var tI = JSON.parse(JSON.stringify(templateList[i]));

                                                            if (i == index) {
                                                                tI.bSelected = !tI.bSelected;
                                                            } else {
                                                                tI.bSelected = false;
                                                            }
                                                            tArr.push(tI)
                                                        }
                                                        var tI1 = JSON.parse(JSON.stringify(t));
                                                        tI1.bSelected = !tI1.bSelected;
                                                        dispatch(setSelectedTemplate(tI1));
                                                        dispatch(setTemplates(tArr))
                                                        setBDraw(!bDraw);
                                                        if ((t.id == -1 || t.name === 'Item Identifier') && tI1.bSelected) {
                                                            dispatch(setSelectedIdentifier(t.numPage))
                                                            onHandleOpenItemIdentifierModal();
                                                        }
                                                        if ((t.id == -2 || t.name === 'Item Selection') && tI1.bSelected) {
                                                            dispatch(setSelectedItemSelection(t.numPage))
                                                            onHandleOpenItemSelectionModal();
                                                        }
                                                    }}>
                                                        <Grid style={{ background: (selectedTemplate?.id === t?.id ? '#282727' : '') }}>
                                                            {<FaCaretRight style={{ color: t.bSelected ? 'red' : "#5065af", marginTop: 0 }} />}
                                                            {t.name}
                                                        </Grid>

                                                        <TextButton sx={{ ml: 1, mt: 0 }} onClick={function (event) { }} style={{ fontSize: 17, height: '10px', color: '#131119' }}>

                                                        </TextButton>
                                                    </li>
                                                ))
                                            }
                                        </ul>}



                                        <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            {(workspace?.id && !workspace?.ocrJson?.fileHeight) && <TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) { handleSubmission() }} style={{ fontSize: 17, color: '#131119' }}>
                                                Open invoice
                                            </TextButton>
                                            }
                                        </Grid>
                                        {workspace?.id && < Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                dispatch(setPdfData(workspace?.ocrJson?.orgList))
                                                var w = JSON.parse(JSON.stringify(workspace))
                                                w.templateJson.cost_items = [];
                                                w.templateJson.fields = [];
                                                w.ocrJson.list = workspace?.ocrJson?.orgList;
                                                setWorkspace(w)
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                Reset Workspace
                                            </TextButton>
                                        </Grid>}
                                        {workspace?.ocrJson?.list && <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                getActiveInactiveTemplateList(dispatch, { trash: false }, function (data) {
                                                    setListOfTemplates(data.data)
                                                });
                                                onHandleOpenTemplateListModal()
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Load  Template
                                            </TextButton>

                                        </Grid>
                                        }

                                        {workspace?.ocrJson?.list && <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                onHandleOpenModal()
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Add Field
                                            </TextButton>

                                        </Grid>}

                                        {(workspace?.templateJson?.fields?.length > 0 || workspace?.templateJson?.cost_items?.length > 0) && <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                /*getActiveInactiveTemplateList(dispatch, null, function (data) {
                                                    dispatch(setTemplateTableList((data.data)));
                                                });*/
                                                onHandleOpenTemplateModal()
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Save  Template
                                            </TextButton>

                                        </Grid>
                                        }
                                        {(workspace?.templateJson?.fields?.length > 0 || workspace?.templateJson?.cost_items?.length > 0) && <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                            <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                var w = JSON.parse(JSON.stringify(workspace));
                                                //w.templateJson.rangeX = sliderObj.value
                                                //w.templateJson.rangeY = sliderObjY.value

                                                updateWorkspace(dispatch, w, function (data) {
                                                    if (data.status == 1)
                                                        dispatch(snackbarToggle({ type: 'success', message: 'Workspace updated successfully' }));
                                                })
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Save  Workspace
                                            </TextButton>

                                        </Grid>
                                        }
                                        {workspace?.ocrJson?.list?.length > 0 && <Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between' spacing={ 2}>
                                           
                                            {<TextFieldLegacy
                                                lg={12}
                                                value={sliderObj.value}
                                                onChange={event => {
                                                    setSliderOBj({ value: event.target.value })
                                                    
                                                }}
                                                color={'#232028'}
                                                label={''}
                                                type={'number'}
                                            />}
                                            <TextFieldLegacy
                                                lg={12}
                                                value={sliderObjY.value}
                                                onChange={event => {
                                                    setSliderOBjY({ value: event.target.value })
                                                }}
                                                color={'#232028'}
                                                label={''}
                                                type={'number'}
                                            />
                                            <TextButton sx={{ m: 2, padding: 0 }} onClick={function (event) {
                                               
                                                onHandleOpenMergeModal()
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                Merge
                                            </TextButton>
                                            <TextButton sx={{ m: 2, padding: 0 }} onClick={function (event) {

                                                drawGrid_2()
                                                // setSlider(slider++)
                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                Redraw
                                            </TextButton>
                                        </Grid>}
                                        {/*<Grid container item lg={12} sx={{ marginTop: 2 }} justifyContent='space-between' alignContent='space-between'>
                                        <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) { onHandleOpenItemCreation() }} style={{ fontSize: 17, color: '#131119' }}>
                                            <FaPlus style={{ marginRight: 1, padding: 5 }} /> Item Creation
                                        </TextButton>
                                    </Grid>
                                    */}
                                       
                                    </Grid>}


                                    <Grid container item lg={12} sx={{ mt: 1 }}>
                                        {workspace?.ocrJsonList?.map((invoice, index) => (<>
                                            <ListItem style={{
                                                background: (selectedWorkspaceFile.file_table_id == invoice.file_table_id ? '#b8b8b8' : 'white') }} key={index} component="div" disablePadding>
                                                <ListItemButton onClick={function () {
                                                    setSelectedWorkspaceFile(invoice)
                                                    //dispatch(setPdfData(obj))
                                                    clearData()
                                                    dispatch(setPdfData([]));
                                                    var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
                                                    if (canvas.length != 0) {
                                                        var ctx = null;
                                                        ctx = canvas[0].getContext('2d');
                                                        ctx.clearRect(0, 0, canvas[0].width, canvas[0].height);
                                                    }
                                                    dispatch(setDocs([]));
                                                    getFileTableData(dispatch, { ...invoice }, function (data) {
                                                        setSelectedInvoiceData(data.data)
                                                        var tableDataList = data.data?.params?.dataList
                                                        if (tableDataList) {
                                                            processSlider(data.data?.orglist)
                                                            fillTemplateJsonFromFileData(tableDataList)
                                                            //
                                                        } else {
                                                            var work = JSON.parse(JSON.stringify(workspace))
                                                            work.ocrJson.orgList = data.data.orglist
                                                            handleMouseClick1(work)
                                                        }
                                                        

                                                        //dispatch(setPdfData(data.data.list))
                                                        dispatch(setPdfHeightWidth({
                                                           w: data.data.page_height,
                                                            h: data.data.page_width,
                                                        }))
                                                        const type = 'application/pdf';
                                                        let base64data = `data:${type};base64,${data.data.fileBase64}`;
                                                        dispatch(onChangeDocs({
                                                            uri: base64data
                                                        }))
                                                    })
                                                }}>
                                                    <ListItemAvatar>
                                                        <TableViewOutlined />
                                                    </ListItemAvatar>

                                                    <ListItemText primary={invoice.file_name}  />
                                                </ListItemButton>
                                            </ListItem>
                                                
                                        </>))}
                                       
                                    </Grid>
                                </Grid>}
                                <Grid container item lg={bOpenLeftPanal ? 10 : 12} style={{ background: '#f5f5f8', minHeight: '91vh',padding:0}} justifyContent='flex-start'>
                                    <Grid justifyContent='flex-start' container item lg={bOpenLeftPanal ? 9 : 7} className={bLoading ? 'rainbow' : ''} style={{ background: '#f5f5f8', height: '91vh', overflow: (bLoading ? '' : 'auto'), minHeight: '91vh' }} id="xyz" >
                                        {bLoading && (
                                            <Grid container item spacing={2} lg={8} >

                                                <div id="container">
                                                    <span className="first"></span>
                                                    <span className="second"></span>
                                                </div>
                                            </Grid>
                                        )}
                                        {!bLoading &&
                                            <RectangleSelection
                                                onSelect={(e, coords) => {
                                                    cordinates = coords
                                                }}
                                                onClick={(e, coords) => {
                                                    cordinates = coords
                                                }}
                                                onMouseUp={(event, coords) => {
                                                    console.log('asdf');
                                                    return;
                                                    if (!selectedTemplate.bSelected) {
                                                        return;
                                                    }
                                                    if (!cordinates.origin[1]) {
                                                        return;
                                                    }
                                                    var elem11 = document.getElementsByClassName('react-pdf__Page__textContent');
                                                    if (elem11.length == 0) {
                                                        //return;
                                                    }
                                                    var pdfRenderer = document.getElementById('pdf-renderer');
                                                    var pdfPageWrapper = document.getElementById('pdf-page-wrapper');
                                                    var scT = pdfRenderer.scrollTop
                                                    var scL = pdfRenderer.scrollLeft
                                                    var pdfPTop = pdfPageWrapper.offsetTop
                                                    var pdfPLeft = pdfPageWrapper.offsetLeft

                                                    var top = ((cordinates.origin[1] < cordinates.target[1] ? cordinates.origin[1] : cordinates.target[1]))
                                                    var left = ((cordinates.origin[0] < cordinates.target[0] ? cordinates.origin[0] : cordinates.target[0]))

                                                    var bott = (cordinates.origin[1] > cordinates.target[1] ? cordinates.origin[1] : cordinates.target[1])
                                                    var right = (cordinates.origin[0] > cordinates.target[0] ? cordinates.origin[0] : cordinates.target[0])

                                                    console.log(`T: ${top - bott}  , ${pdfPTop}, ${top} `)
                                                    console.log(`L: ${left - right}  , ${pdfPLeft}, ${left} `)
                                                    var e = []
                                                    var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
                                                    var ctx = null;
                                                    if (canvas[0]) {
                                                        ctx = canvas[0].getContext('2d');
                                                    }
                                                    console.log(canvas[0])
                                                    console.log("ctx : ", ctx)
                                                    ctx.beginPath();
                                                    var x_o = (left - pdfPLeft + scL) //* pdfHeightWidth.w / canvas[0].offsetWidth ;
                                                    var w_o = (right - left) //* pdfHeightWidth.w / canvas[0].offsetWidth ;
                                                    var y_o = (top - pdfPTop + scT) // * pdfHeightWidth.h / canvas[0].offsetHeight;
                                                    var h_o = (bott - top) //* pdfHeightWidth.h / canvas[0].offsetHeight;
                                                    ctx.strokeStyle = "red";
                                                    ctx.lineWidth = 1;
                                                    //ctx.rect(x_o, y_o, w_o, h_o);
                                                    //ctx.stroke();
                                                    for (var i = 0; i < pdfData.length; i++) {
                                                        var x = pdfData[i].x;// * elem11[0].offsetWidth / pdfHeightWidth.w;
                                                        var y = pdfData[i].y;// * elem11[0].offsetHeight / pdfHeightWidth.h;
                                                        var h = pdfData[i].height;// (pdfData[i].b - pdfData[i].t) * elem11[0].offsetHeight / pdfHeightWidth.h;
                                                        var w = pdfData[i].width;// (pdfData[i].r - pdfData[i].l) * elem11[0].offsetWidth / pdfHeightWidth.w;
                                                        if ((x_o < x) && (x_o + w_o > x + w) && (y_o < y) && (y_o + h_o > y + h)) {
                                                            e.push(pdfData[i]);
                                                        }
                                                        if (cordinates.origin[0] == pdfData[i].x && cordinates.origin[1] == pdfData[i].y) {
                                                            var tt = JSON.parse(JSON.stringify(pdfData[i]))
                                                            tt.t = pdfData[i].x;
                                                            tt.l = pdfData[i].y;
                                                            e.push(tt);

                                                        }
                                                    }
                                                    boundingElements1 = e;
                                                    //dispatch(setBoundingElements(e));
                                                    setBoundingsToTamplate();
                                                }}
                                                onMouseDown={(e, coords) => {
                                                    return;
                                                    cordinates = {}
                                                }}
                                                onSelect={(e, coords) => {
                                                    cordinates = coords
                                                }}
                                                style={{
                                                    backgroundColor: "rgba(0,0,255,0.4)",
                                                    borderColor: "blue"
                                                }}
                                            > <DocViewer style={{ width: "100%", height: "100%" }} pluginRenderers={DocViewerRenderers} documents={docs}
                                                config={{
                                                    header: {
                                                        disableHeader: true,
                                                        disableFileName: true,
                                                        retainURLParams: true
                                                    }
                                                }} />
                                            </RectangleSelection>
                                        }
                                    </Grid>
                                    <Grid justifyContent='flex-start' alignContent='flex-start' container item lg={bOpenLeftPanal ? 3 : 5} style={{ background: '#f5f5f8', minHeight: '91vh', borderLeft: "1px solid black" }} alignContent="flex-start">
                                        {<Grid container item lg={12} justifyContent="flex-start" sx={{ fontSize: '10px', overflow: 'auto', height: '45vh' }} spacing={1} alignContent="flex-start">

                                            {
                                                workspace?.templateJson?.fields?.map((t, index) => (
                                                    <Grid key={uuidv4()} container item lg={12} justifyContent="flex-start" alignItems="flex-start" alignContent="flex-start">
                                                        {(t.id != -1 || t.id != -2) && <Grid onClick={() => {
                                                            setSelectedElements(t)
                                                            setIsItems(false)
                                                            drawGrid_2()
                                                        }} container item justifyContent="center" alignItems="center" alignContent="flex-start">

                                                            <Grid container item lg={4}> <span style={{ width: "100%", paddingRight:"10px", fontSize: '16px', textAlign: "right" }}>{t.label}</span></Grid>
                                                            <Grid container item lg={8}><TextField
                                                                lg={12}
                                                                sx={{ color: "white" }}
                                                                rows={5}
                                                                value={t.value}
                                                                bBlur={true}

                                                                onBlur={function (event) {
                                                                    var w = JSON.parse(JSON.stringify(workspace));
                                                                    var tArr = []
                                                                    for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
                                                                        var tI = JSON.parse(JSON.stringify(workspace?.templateJson?.fields[i]));
                                                                        if (i == index ) {                                                                            
                                                                            if (event.target.value == '') {
                                                                                tI.value = "";
                                                                                tI.points = []
                                                                            } else {
                                                                                tI.value = event.target.value;
                                                                            }
                                                                        }

                                                                        tArr.push(tI)

                                                                    }
                                                                    w.templateJson.fields = tArr;
                                                                    setWorkspace(w)

                                                                    setSelectedElements(t)
                                                                    setIsItems(false)
                                                                    drawGrid_2()
                                                                    /* setSelectedElements(t)
                                                                     var tArr = []
                                                                     for (var i = 0; i < templateList.length; i++) {
                                                                         var tI = JSON.parse(JSON.stringify(templateList[i]));
     
                                                                         if (i == index) {
                                                                             tI.value = tI.value + event.target.value;
                                                                         }
                                                                         tArr.push(tI)
                                                                     }*/
                                                                    //dispatch(setTemplates(tArr))
                                                                }}
                                                                color={'#232028'}
                                                            /></Grid>
                                                        </Grid>
                                                        }
                                                    </Grid>
                                                ))
                                            }

                                        </Grid>
                                        }

                                        <Grid justifyContent='flex-start' sx={{ fontSize: '10px', mt: 0, overflow: 'auto', height: '38vh', borderBottom: '1px black solid', borderTop: '1px black solid' }} container item lg={12} >
                                            {workspace?.id&& < TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) { onHandleOpenItemModal(); }} style={{ fontSize: 17, color: '#131119' }}>
                                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Item Creation
                                            </TextButton>
                                            }

                                            {workspace?.id && <TableContainer sx={{ height: "36vh" }}>
                                                <Table >
                                                    <TableBody sx={{ marginTop: 2 }}>
                                                        <TableRow sx={{ '& > *': { fontSize: '14px !important', margin: 0, padding: '10px', } }}>
                                                            {workspace?.templateJson?.cost_items?.map((dData2, index2) => (
                                                                <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px', verticalAlign: "top" }} >
                                                                    <Grid container item lg={12} justifyContent="center">
                                                                        <Typography variant='h7' >
                                                                            {dData2.label}
                                                                        </Typography>
                                                                    </Grid>
                                                                    <Table >
                                                                        <TableBody sx={{ marginTop: 2 }}>
                                                                            {dData2?.items?.map((it, i) => (<TableRow key={uuidv4()} sx={{ '& > *': { fontSize: '14px !important', margin: 0, padding: '10px', } }}>

                                                                                <TableCell style={{ margin: 0, padding: '3px', verticalAlign: "top" }} >

                                                                                    <Grid container item lg={12}>
                                                                                        <Grid container item lg={2}>
                                                                                            {index2 == 0 && <TextButton sx={{ ml: 0, mt: 0, padding: 0 }} onClick={function (event) {
                                                                                                var containerList = [...workspace?.templateJson?.cost_items]
                                                                                                var childList = [...dData2?.items]
                                                                                                /*for (var z = 0; z < childList.length;z++) {
                                                                                                    childList.splice(z, 1);
                                                                                                }*/
                                                                                                for (var k = 0; k < containerList.length; k++) {
                                                                                                    containerList[k].items.splice(i, 1);
                                                                                                }
                                                                                                //containerList[index2].items = childList;
                                                                                                var w = JSON.parse(JSON.stringify(workspace))
                                                                                                w.templateJson.cost_items = containerList;
                                                                                                setWorkspace(w)

                                                                                            }} style={{ fontSize: 17, color: '#131119' }}>
                                                                                                <FaMinus style={{ marginRight: 1, padding: 5 }} />
                                                                                            </TextButton>}
                                                                                        </Grid>
                                                                                        <Grid container item lg={index2 == 0 ? 10 : 12} onClick={() => {

                                                                                            
                                                                                        }}>
                                                                                            <TextField
                                                                                                lg={12}
                                                                                                value={it.label}
                                                                                                bBlur={ true}
                                                                                                onBlur={event => {
                                                                                                    var containerList = [...workspace?.templateJson?.cost_items]
                                                                                                    var childList = [...dData2?.items]
                                                                                                    childList[i].label = event.target.value;
                                                                                                    containerList[index2].items = childList;
                                                                                                    //containerObj.
                                                                                                    var w = JSON.parse(JSON.stringify(workspace))
                                                                                                    w.templateJson.cost_items = containerList;
                                                                                                    setWorkspace(w) //pppp
                                                                                                    setSelectedItem({
                                                                                                        indexParent: index2,
                                                                                                        indexChild: i,
                                                                                                        isItems: true
                                                                                                    })
                                                                                                    setIsItems(true)
                                                                                                }}
                                                                                                color={'#232028'}
                                                                                                label={''}
                                                                                            />
                                                                                        </Grid>
                                                                                    </Grid>
                                                                                </TableCell>


                                                                            </TableRow>))
                                                                            }
                                                                        </TableBody>
                                                                    </Table>
                                                                    {false && <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                                        var containerList = [...workspace?.templateJson?.cost_items]
                                                                        var childList = [...dData2?.items]
                                                                        childList.push({
                                                                            label: "",
                                                                            value: "",
                                                                            points: []
                                                                        })

                                                                        containerList[index2].items = childList;
                                                                        var w = JSON.parse(JSON.stringify(workspace))
                                                                        w.templateJson.cost_items = containerList;
                                                                        setWorkspace(w)

                                                                    }} style={{ fontSize: 17, color: '#131119' }}>
                                                                        <FaPlus style={{ marginRight: 1, padding: 5 }} />
                                                                    </TextButton>}
                                                                </TableCell>
                                                            ))
                                                            }

                                                        </TableRow>
                                                        <TableRow sx={{ '& > *': { fontSize: '14px !important', margin: 0, padding: '10px', } }}>
                                                            <TableCell >

                                                                <TextButton sx={{ ml: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                                                    var containerList = [...workspace?.templateJson?.cost_items]
                                                                    var lastI = lastId ;
                                                                    for (var k = 0; k < containerList.length; k++) {
                                                                        var childList = [...containerList[k]?.items]
                                                                        lastI = lastI + 1;
                                                                        
                                                                        childList.push({
                                                                            id: lastI,
                                                                            label: "",
                                                                            value: "",
                                                                            points: []
                                                                        })

                                                                        containerList[k].items = childList;
                                                                    }
                                                                    setLastId(lastI)

                                                                    var w = JSON.parse(JSON.stringify(workspace))
                                                                    w.templateJson.cost_items = containerList;
                                                                    setWorkspace(w)

                                                                }} style={{ fontSize: 17, color: '#131119' }}>
                                                                    <FaPlus style={{ marginRight: 1, padding: 5 }} />
                                                                </TextButton>

                                                            </TableCell >
                                                        </TableRow>
                                                    </TableBody>
                                                </Table>
                                            </TableContainer>}
                                        </Grid>

                                        {
                                            <Grid container item justifyContent="center" alignItems="center" sx={{ height:"7vh" }}>
                                                <TextButton sx={{ padding: 0 }} onClick={function (event) {
                                                    var dList = [];
                                                    var w = JSON.parse(JSON.stringify(workspace));
                                                    var tArr = []
                                                    for (var i = 0; i < w?.templateJson?.fields?.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(workspace?.templateJson?.fields[i]));
                                                       
                                                        tArr.push({
                                                            id: tI.id,
                                                            data: tI.value,
                                                        })
                                                    }
                                                    for (var i = 0; i < w.templateJson.cost_items?.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(w.templateJson.cost_items[i]));
                                                        for (var j = 0; j < tI.items.length; j++) {
                                                           
                                                            tArr.push({
                                                                id: tI.items[j].id,
                                                                data: tI.items[j].label,
                                                            })
                                                        }
                                                    }
                                                    console.log(tArr)

                                                    updateOcrFileTableData(dispatch, { file_table_id:selectedInvoiceData.id, params: { ...selectedInvoiceData.params, dataList: tArr } }, function (data) {
                                                        console.log(data)
                                                        dispatch(snackbarToggle({ type: 'success', message: 'Items Saved Successfully' }));
                                                    })

                                                }} style={{ fontSize: 17, color: '#131119' }}>
                                                    Save Items
                                                </TextButton>
                                            </Grid>}
                                    </Grid>
                                </Grid>
                            </Grid>}
                        </>
                        : <Login setIsLogin={setIsLogin} />}</>} />
                    <Route exact path='/register' element={<Registration setIsLogin={setIsLogin}></Registration>} />

                </Routes>
            </Grid>
            {snackbar && (
                <Snackbar
                    open={!!snackbar}
                    message={snackbar.message}
                    type={snackbar.type}
                    onClose={onSnackbarHandleClose}
                />
            )}
        </Paper>
    );
}

export default LandingPage;
