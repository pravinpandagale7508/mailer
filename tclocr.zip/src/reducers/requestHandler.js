// JavaScript source code
import { useState, useEffect, useCallback } from 'react';
import { REQUEST_ACTIONS, sendRequest, setCookie, getCookie } from '../utils/Communicator';
import { useSelector, useDispatch } from 'react-redux';
import { URL_CONST, LANGUAGES, mailroom_id } from '../constants/globleConstants';
import { setUser,setAdmin, setAdminUser } from '../reducers/session/sessionSlice';

var bDownLoad = false; 
var downLoadId = 0;
export const uploadFile = (dispatch, data, callback, failedCallback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/uploadFile", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            /* 
             for (var i = 0; i < response.length; i++) {
                 dispatch(onUsersChange(response[i]));
             }
             */
            //setIsLoaded(true);
           
            callback(response)
        },
        failedCallback: error => {
            failedCallback(error)
        }
    });
}
export const getTemplate = (dispatch, id, callback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/getTemplate?id="+id, REQUEST_ACTIONS.GET, {}, {
        successCallback: (response) => {
            console.log(response)
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}
export const getTemplateList1 = (dispatch, data, callback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/getTemplateList", REQUEST_ACTIONS.GET, {}, {
        successCallback: (response) => {
            console.log(response)
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}
export const login = (dispatch, data, callback) => {
    sendRequest(URL_CONST.USER + "/userHandler", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            setCookie("NBO_SESSION_ID", response.session, 30);
            dispatch(setAdmin(response))
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}
export const register = (dispatch, data, callback) => {
    sendRequest(URL_CONST.USER + "/userHandler", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            dispatch(setAdmin(response.data))
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}

export const uploadExtractedData = (dispatch, data, callback, failedCallback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/uploadExtractedData", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)

            callback(response)
        },
        failedCallback: error => {
            failedCallback()
        }
    });
}
export const uploadExtraData = (dispatch, data, callback, failedCallback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/uploadExtraData", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            failedCallback()
        }
    });
}
export const getExtraDataListByKeys = (dispatch, data, callback, failedCallback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/getExtraDataListByKeys", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            failedCallback()
        }
    });
}
export const addTemplate = (dispatch, data, callback) => {
    data.opcode = "addTemplate"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const updateWorkspace = (dispatch, data, callback) => {
    data.opcode = "updateWorkspace"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const addWorkspace = (dispatch, data, callback) => {
    data.opcode = "addWorkspace"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            callback(error)
            //failedCallback()
        }
    });
}
export const getActiveWorkspaceList = (dispatch, data, callback) => {
    data.opcode = "getActiveWorkspaceList"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const getActiveInactiveWorkspaceList = (dispatch, data, callback) => {
    data.opcode = "getActiveInactiveWorkspaceList"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const getWorkspaceList = (dispatch, data, callback) => {
    data.opcode = "getWorkspaceList"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const updateOcrFileTableData = (dispatch, data, callback) => {
    data.opcode = "updateOcrFileTableData"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const getFileTableData = (dispatch, data, callback) => {
    data.opcode = "getFileTableData"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const moveTemplateToTrashCurrent = (dispatch, data, callback) => {
    data.opcode = "moveTemplateToTrashCurrent"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const getActiveInactiveTemplateList = (dispatch, data, callback) => {
    data.opcode = "getActiveInactiveTemplateList"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const getTemplateList = (dispatch, data, callback) => {
    data.opcode = "getTemplateList"
    sendRequest(URL_CONST.OCR_HANDLER, REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            //failedCallback()
        }
    });
}
export const uploadTemplate = (dispatch, data, callback, failedCallback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/uploadTemplate", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            
            callback(response)
        },
        failedCallback: error => {
            failedCallback()
        }
    }, {
        'Content-Length': 0,
        'Content-Type': 'text/plain'
    });
}
export const extractFiles = (dispatch, data, callback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/extractFiles", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}

export const loadFiles = (dispatch, data, callback) => {
    sendRequest(URL_CONST.FILE_STORAGE + "/loadFiles", REQUEST_ACTIONS.POST, data, {
        successCallback: (response) => {
            console.log(response)
            callback(response)
        },
        failedCallback: error => {
            console.log(error)
        }
    });
}
export const downloadPdf = (dispatch, id,callback) => {
    let loginObj = {  }
    sendRequest(URL_CONST.FILE_STORAGE +"/downloadPdf?id="+id, REQUEST_ACTIONS.GET, loginObj, {
        successCallback: (response) => {
            callback(response)
           /* 
            for (var i = 0; i < response.length; i++) {
                dispatch(onUsersChange(response[i]));
            }
            */
            //setIsLoaded(true);
        },
        failedCallback: error => {

        }
    });
}
export const downloadDocx = (dispatch, id,callback) => {
    let loginObj = {}
    send_file_data(loginObj,URL_CONST.FILE_STORAGE + "/downloadDocx?id=" + id,callback)
    
}


function send_data_get(url, fileName) {
    fetch(url)
        .then(response =>
            response.blob()
        )
        .then(response => {
            const blob = new Blob([response], { type: 'application/pdf' });
            const downloadUrl = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = downloadUrl;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
        })
}

var send_file_data = function (data, rest_url ,callback) {

   return fetch(rest_url, {
        method: 'GET',
    })
        .then(response => response.blob())
       .then(response => {
           //callback(response)
           const blob = new Blob([response], { type: 'application/msword' });
           callback(blob)
           const downloadUrl = window.URL.createObjectURL(blob);

           document.getElementById("asdf").src = "https://docs.google.com/gview?embedded=true&url="+URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = downloadUrl;
            a.download = "file.docx";
            document.body.appendChild(a);
            //a.click();
        })
        /**/

}
function toFixed(x) {
    if (Math.abs(x) < 1.0) {
        var e = parseInt(x.toString().split('e-')[1]);
        if (e) {
            x *= Math.pow(10, e - 1);
            x = '0.' + (new Array(e)).join('0') + x.toString().substring(2);
        }
    } else {
        var e = parseInt(x.toString().split('+')[1]);
        if (e > 20) {
            e -= 20;
            x /= Math.pow(10, e);
            x += (new Array(e + 1)).join('0');
        }
    }
    return x;
}
export const exportItems = (data, headers) => {
    var d = []
    for (var i = 0; i < data.length-1; i++) {
        var t = {}
        t[headers[0]] = data[i][0]
        t[headers[1]] = data[i][1] + "!";
        t[headers[2]] = data[i][2]
        t[headers[3]] = data[i][3]
        t[headers[4]] = data[i][4]
        t[headers[5]] = data[i][5]
        t[headers[6]] = data[i][6]
        d.push(t)
    }
    exportCSVFile(headers, d,"Items")
}
function exportCSVFile(headers, items, fileTitle) {

    var csv = convertToCSV1(items, headers);

    var exportedFilenmae = fileTitle;

    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            try {
                var url = window.URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", exportedFilenmae);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } catch (err) {
                if (err.message) {
                    console.log(err.message)
                }
                console.log(err)
            }

        }
    }
}
function convertToCSV1(items, header1) {
    const replacer = (key, value) => value === null ? '' : value // specify how you want to handle null values here
    const header = header1
    const csv = [
        header.join(','), // header row first
        ...items.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','))
    ].join('\r\n')
    return csv;
}
