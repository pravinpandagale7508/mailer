import { createSlice } from '@reduxjs/toolkit';

export const templateSlice = createSlice({
    name: 'template',
    initialState: {
        templateList: [],
        fileTable: { name: "" },
        selectedTemplateTable: { name: "" },
        templateTableList: [],
        pdfData: [],
        docData: [],
        moreRowDocData: [],
        itemHeaders1: [{ name: "QTY per item", id: 1 }, { name: "Item description", id: 2 }, { name: "Item's value", id: 3 }, { name: "Unit of Measure", id: 4 }, { name: "Curancy", id: 5 }, { name: "Invoice SUB Total", id: 6 }, { name: "Item 's Code (Option)", id: 7 }, { name: "Incoterms (Option)", id: 8 }],
        itemHeaders: [{ name: "QTY per item", id: 1 }, { name: "Item description", id: 2 }, { name: "Item's value", id: 3 }, { name: "Unit of Measure", id: 4 }, { name: "Curancy", id: 5 }, { name: "Invoice SUB Total", id: 6 }, { name: "Item 's Code (Option)", id: 7 }, { name: "Incoterms (Option)", id: 8 }],


        selectedTemplate: { id: 0 },
        selectedIdentifier: 0,
        selectedItemSelection: 0,
        boundingElements: [],
        itemCreation: [[""]],
        mergeData: {},
        bLoading: false,
        pdfHeightWidth: { h: 0, w: 0 },
        cordinates: {
            origin: [],
            target: []
        },
        docs: [
            //{ uri: "https://redbox-go.com/info.pdf" }//"http://localhost:3000/docs.html"}
        ]
    },
    reducers: {
        setItemCreation: (state, { payload }) => {
            state.itemCreation = payload;
        },
        setFileTable: (state, { payload }) => {
            state.fileTable = payload;
        },
        setMergeData: (state, { payload }) => {
            state.mergeData = payload;
        },
        setMoreRowDocData: (state, { payload }) => {
            state.moreRowDocData = payload;
        },
        setSelectedItemSelection: (state, { payload }) => {
            state.selectedItemSelection = payload;
        },
        setSelectedIdentifier: (state, { payload }) => {
            state.selectedIdentifier = payload;
        },
        setSelectedTemplateTable: (state, { payload }) => {
            state.selectedTemplateTable = payload;
        },
        setTemplateTableList: (state, { payload }) => {
            state.templateTableList = payload;
        },
        setSelectedTemplate: (state, { payload }) => {
            state.selectedTemplate = payload;
        },
        setBoundingElements: (state, { payload }) => {
            state.boundingElements = payload;
        },
        setPdfHeightWidth: (state, { payload }) => {
            state.pdfHeightWidth = payload;
        },
        setItemHeaders1: (state, { payload }) => {
            state.itemHeaders1 = payload;
        },
        setItemHeaders: (state, { payload }) => {
            state.itemHeaders = payload;
        },
        setDocData: (state, { payload }) => {
            state.docData = payload;
        },
        setDocDataItem: (state, { payload, index }) => {
            state.docData[payload.index] = payload.data;
        },
        setPdfData: (state, { payload }) => {
            state.pdfData = payload;
        },
        onLoading: (state, { payload }) => {
            state.bLoading = payload;
        },
        setDocs: (state, { payload }) => {
            state.docs = payload;
        },
        onChangeDocs: (state, { payload }) => {
            state.docs.push(payload);
        },
        setCordinates: (state, { payload }) => {
            state.cordinates = payload;
        },
        setTemplates: (state, { payload }) => {
            state.templateList = payload;
        },
        addTemplate: (state, { payload }) => {
            state.templateList.push(payload);
        },
        expandTemplateItem: (state, { payload, index }) => {
            for (var i = 0; i < state.templateList.length; i++) {
                if (state.templateList[i].id == payload.id) {
                    state.templateList[i] = payload;
                    break;
                }
            }
        },
        setItemHeader: (state, { payload, index }) => {
            for (var i = 0; i < state.itemHeaders.length; i++) {
                if (state.itemHeaders[i].id == payload.id) {
                    state.itemHeaders[i] = payload;
                    break;
                }
            }
        },
    },
});

// Action creators are generated for each case reducer function
export const { setTemplates, setItemCreation, setFileTable, setMergeData, setMoreRowDocData, setSelectedItemSelection, setSelectedIdentifier, setSelectedTemplateTable, setTemplateTableList, setSelectedTemplate, setBoundingElements, setItemHeaders, setPdfHeightWidth, setItemHeaders1, setDocData, setDocDataItem, setItemHeader, setDocs, setPdfData, addTemplate, expandTemplateItem, setCordinates, onChangeDocs, onLoading } = templateSlice.actions;

export default templateSlice.reducer;
