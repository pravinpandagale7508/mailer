import { createSlice } from '@reduxjs/toolkit';

export const parameterSlice = createSlice({
    name: 'parameter',
    initialState: {
        crmList: [],
        listOfAirExportAFs: [],
        listOfLclExportImportAFs: [],
        qsTypeList: [],
        qsStatusList: [],
        listOfServiceType: [],
        listOfAirLine: [],
        listOfShipmentTypes: [],
        listOfIncoterms: [],
        listOfChargesTypes: [],
        listOfProductCharges: [],
        listOfMeasurementUnits: [],
        countryList: [],
        listOfFunctionTypes: [],
        listOfAgentNetwork: [],
        portList: [],
        crmListFilter: [],
        listOfFLCTypes20: [],
        listOfCountryAndOrigins: [],
        listOfFLCTypes40: [],
        listOfAirPort: [],
        listOfKgFactor: [],
        listOfExchangeRates: [],
        listOfProductCategories: [],
        listOfPort: [],
        adminList: [],
        listOfcurrency: [],
        listOfAirImportExport: [],
        listOfLclImportExport: [],
        listOfFclImportExport: [],
        productForeignChargesItem: [],
        selectedCrm: {},
        commonFilterData:
        {
            id: 0,
            cutomerCrmId: "",
            countryId: "-1",
            from: "All",
            to: "All",
            flcType20: "",
            flctype40: "",
            total: "",
            createdDate: 0,
            quoteType1: -1,
            quoteType: [],
            incoId1: -1,
            incoId: [],
            status1: -1,
            status: [],
            userId1: -1,
            userId: [],
            serviceType1: -1,
            serviceType: [],
            currency1: -1,
            currency: [],
        }
        ,
    },
    reducers: {
        setSelectedCrm: (state, { payload }) => {
            state.selectedCrm = payload
        },
        setCommonFilterData: (state, { payload }) => {
            state.commonFilterData = payload
        },
        setCrmListByFilter: (state, { payload }) => {
            state.crmListFilter = []
            state.crmListFilter = payload;
        },
        onCrmChange: (state, { payload }) => {
            var bUpdated = false;
            for (var i = 0; i < state.crmList.length; i++) {
                if (payload.id === state.crmList[i].id) {
                    bUpdated = true;
                    state.crmList[i] = payload;
                }
            }
            if (!bUpdated) {
                state.crmList.push(payload);
            }
        },
        onCountryChange: (state, { payload }) => {

            var bUpdated = false;
            for (var i = 0; i < state.countryList.length; i++) {
                if (payload.id === state.countryList[i].id) {
                    bUpdated = true;
                    state.countryList[i] = payload;
                }
            }
            if (!bUpdated) {
                state.countryList.push(payload);
            }
        },
        onAirPortChange: (state, { payload }) => {
            var bUpdated = false;
            for (var i = 0; i < state.listOfAirPort.length; i++) {
                if (payload.id === state.listOfAirPort[i].id) {
                    bUpdated = true;
                    state.listOfAirPort[i] = payload;
                }
            }
            if (!bUpdated) {
                state.listOfAirPort.push(payload);
            }
        },
        onPortChange: (state, { payload }) => {
            var bUpdated = false;
            for (var i = 0; i < state.listOfPort.length; i++) {
                if (payload.id === state.listOfPort[i].id) {
                    bUpdated = true;
                    state.listOfPort[i] = payload;
                }
            }
            if (!bUpdated) {
                state.listOfPort.push(payload);
            }
        },
        onAdminChange: (state, { payload }) => {
            var bUpdated = false;
            for (var i = 0; i < state.adminList.length; i++) {
                if (payload.id === state.adminList[i].id) {
                    bUpdated = true;
                    state.adminList[i] = payload;
                }
            }
            if (!bUpdated) {
                state.adminList.push(payload);
            }
        },
        setQsTypeList: (state, { payload }) => {
            state.qsTypeList = payload
        },
        setQsStatusList: (state, { payload }) => {
            state.qsStatusList = payload
        },
        setListOfIncoterms: (state, { payload }) => {
            state.listOfIncoterms = payload
        },
        setAirImportExport: (state, { payload }) => {
            state.listOfAirImportExport = payload
        },
        setAirExportAFs: (state, { payload }) => {
            state.listOfAirExportAFs = payload
        },
        setLclExportImportAFs: (state, { payload }) => {
            state.listOfLclExportImportAFs = payload
        },
        setFclImportExport: (state, { payload }) => {
            state.listOfFclImportExport = payload
        },
        setLclImportExport: (state, { payload }) => {
            state.listOfLclImportExport = payload
        },
        setListOfServiceType: (state, { payload }) => {
            state.listOfServiceType = payload
        },
        setListOfExchangeRates: (state, { payload }) => {
            state.listOfExchangeRates = payload
        },
        setListOfcurrency: (state, { payload }) => {
            state.listOfcurrency = payload
        },
        setListOfKgFactor: (state, { payload }) => {
            state.listOfKgFactor = payload
        },
        setListOfProductCharges: (state, { payload }) => {
            state.listOfProductCharges = payload
        },
        setListOfProductCategories: (state, { payload }) => {
            state.listOfProductCategories = payload
        },
        setListOfShipmentTypes: (state, { payload }) => {
            state.listOfShipmentTypes = payload
        },
        setAgentNetwork: (state, { payload }) => {
            state.listOfAgentNetwork = payload
        },
        setProductForeignChargesItem: (state, { payload }) => {
            state.productForeignChargesItem = payload
        },
        setFunctionTypes: (state, { payload }) => {
            state.listOfFunctionTypes = payload
        },
        setChargesTypes: (state, { payload }) => {
            state.listOfChargesTypes = payload
        },
        setMeasurementUnits: (state, { payload }) => {
            state.listOfMeasurementUnits = payload
        },
        setFLCTypes20: (state, { payload }) => {
            state.listOfFLCTypes20 = payload
        },
        setFLCTypes40: (state, { payload }) => {
            state.listOfFLCTypes40 = payload
        },
        setCountryAndOrigins: (state, { payload }) => {
            state.countryList = payload
        },
        setPorts: (state, { payload }) => {
            state.listOfPort = payload
        },
        setAirPorts: (state, { payload }) => {
            state.listOfAirPort = payload
        },
        setAirLines: (state, { payload }) => {
            state.listOfAirLine = payload
        },

    },
});
// Action creators are generated for each case reducer function
export const { setSelectedCrm, onCountryChange, setCommonFilterData, onAirPortChange, setProductForeignChargesItem, setLclExportImportAFs, setAirExportAFs, setLclImportExport, setFclImportExport, setAirImportExport, setCrmListByFilter, setAirPorts, setAgentNetwork, setFunctionTypes, setAirLines, setPorts, setFLCTypes40, setFLCTypes20, onPortChange, setCountryAndOrigins, setMeasurementUnits, setListOfShipmentTypes, setChargesTypes, setListOfProductCharges, setListOfProductCategories, setListOfKgFactor, setListOfServiceType, setListOfcurrency, setQsTypeList, setListOfExchangeRates, setQsStatusList, setListOfIncoterms } = parameterSlice.actions;

export default parameterSlice.reducer;
