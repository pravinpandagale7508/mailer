import { configureStore } from '@reduxjs/toolkit';
import snackbarSlice from '../reducers/snackbarSlicer';
import templateSlice from '../reducers/templateSlicer';
import sessionSlice from '../reducers/session/sessionSlice';
export default configureStore({
  reducer: {
        snackbar: snackbarSlice,
        template: templateSlice,
        session: sessionSlice,
  },
  middleware: getDefaultMiddleware => getDefaultMiddleware({ serializableCheck: false }),
});
