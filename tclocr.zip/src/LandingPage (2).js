import base64 from 'binary-base64';
import './fontawesome/font-awesome.min.css';
import RectangleSelection from "react-rectangle-selection"
import './App.css';
import './loader.scss';
import { v4 as uuidv4 } from 'uuid';
import { useEffect, useState, useRef } from 'react';
import React from 'react';
import { Grid, Paper, Table, TableHead, TableBody, TableContainer, TableCell, TableRow, Typography, } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import TextButton from '@mui/material/IconButton';
import { TextField, SelectField } from './style-guide';
import { FaPlus, FaCaretRight, FaCaretDown, FaCloudDownloadAlt } from "react-icons/fa";
import DocViewer, { DocViewerRenderers } from "react-doc-viewer";
import DocCustomRenderer from "./DocCustomRenderer";
import { Template } from './component/template/template'
import { ItemTable } from './component/ItemTable/ItemTable'
import { Header } from './component/header/header'
import { Dialog, Snackbar } from './style-guide';
import { expandTemplateItem, setPdfHeightWidth, setCordinates, onChangeDocs, onLoading, setItemHeaders1, setItemHeaders, setDocs, setPdfData, setDocData, setItemHeader } from './reducers/templateSlicer';
import { uploadFile, downloadDocx, loadFiles, extractFiles, exportItems } from './reducers/requestHandler';
import { template_type, test_b_doc, test_b_pdf } from './constants/globleConstants'
import { snackbarToggle } from './reducers/snackbarSlicer';
export const LandingPage = props => {
    const dispatch = useDispatch();
    const canvas = useRef();
    const [value, setValue] = useState({
        id: null,
        name: null,
    });
    let ctx = null;
    // const navigate = useNavigate();
    const { snackbar } = useSelector(state => state.snackbar);
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));

    const [openItemOrderModal, setOpenItemOrderModal] = useState(false);
    const onHandleOpenItemModal = () => setOpenItemOrderModal(true);
    const onHandleCancelItemModal = () => setOpenItemOrderModal(false);

    const [openHeaderOrderModal, setOpenHeaderOrderModal] = useState(false);
    const onHandleOpenHeaderModal = () => setOpenHeaderOrderModal(true);
    const onHandleCancelHeaderModal = () => setOpenHeaderOrderModal(false);

    const [selectedElements, setSelectedElements] = useState([]);
    const [openOrderModal, setOpenOrderModal] = useState(false);
    const onHandleOpenModal = () => setOpenOrderModal(true);
    const onHandleCancelModal = () => setOpenOrderModal(false);
    const { templateList, docs, bLoading, docData, pdfData, itemHeaders, itemHeaders1, pdfHeightWidth } = useSelector(state => state.template);
    const toolbarStyle = {
        minHeight: '70px',
        color: '#131119',
        width: 'calc(100vw - 50px)',
        justifyContent: 'start',
        alignItems: 'center',
        flexDirection: 'start',
        float: 'left'
    };
    const [selectedTemplate, setSelectedTemplate] = useState({ id: 0 });
    var cOrdi = {}
    function getPos(el) {
        // yay readability
        for (var lx = 0, ly = 0;
            el != null;
            lx += el.offsetLeft, ly += el.offsetTop, el = el.offsetParent);
        return { x: lx, y: ly };
    }
    var setCanvasOnlick = function () {

    }
    useEffect(() => {
        if (docs.length > 0)
            window.setTimeout(setCanvasOnlick, 2000);
    }, [selectedTemplate, templateList, docs]);

    const changeHandler = (event) => {
        dispatch(onLoading(true))
        var formData = new FormData();
        for (var i = 0; i < event.target.files.length; i++) {
            formData.append("file", event.target.files[i], event.target.files[i].name);
        }

        uploadFile(dispatch, formData, function (data) {

            loadFiles(dispatch, { id: data.data.id }, function (response) {

                extractFiles(dispatch, { id: data.data.id }, function (response1) {
                    dispatch(setPdfHeightWidth({
                        h: response1.data.fileHeight,
                        w: response1.data.fileWidth,
                    }))
                    const type = 'application/pdf';
                    let base64data = `data:${type};base64,${data.data.pdfFile}`;
                    dispatch(onChangeDocs({
                        uri: base64data
                    }))
                    dispatch(setDocData(test_b_doc))
                    dispatch(setPdfData(test_b_pdf))
                    dispatch(onLoading(false))
                    /*
                    fetch("/ocr/" + data.data.fileName + "_doc.json")
                        .then(response => {
                            return response.json();
                        })
                        .then(jsondata => dispatch(setDocData(jsondata)));

                    fetch("/ocr/" + data.data.fileName + "_pdf.json")
                        .then(response => {
                            return response.json();
                        })
                        .then(jsondata => dispatch(setPdfData(jsondata)));
                    */

                })
                /* const type = 'application/pdf';
                 let base64data = `data:${type};base64,${data.data.pdfFile}`;
                 dispatch(onChangeDocs({
                     uri: base64data
                 }))
                 dispatch(onLoading(false))
                 */
            })

        }, function () {

        })
    };
    const handleSubmission = () => {
        var fileInput = document.getElementById('file');
        var element = document.getElementById("file_container");
        if (fileInput) {
            element.removeChild(fileInput);
        }
        var x = document.createElement("INPUT");
        x.setAttribute("type", "file");
        x.setAttribute("id", 'file');
        x.style.display = "none";
        element.appendChild(x);

        document.getElementById("file").addEventListener("change", changeHandler, true);
        document.getElementById('file').click();

    };
    var cordinates = {
        origin: [0, 0],
        target: [0, 0]
    }
    return (
        <Paper sx={{ width: '100%', overflow: 'hidden', maxHeight: '98.3vh' }}>

            {openItemOrderModal && (
                <Dialog open={openItemOrderModal} title={'ItemTable'} onHandleCancel={onHandleCancelItemModal}>
                    <ItemTable data={docData} onHandleCancel={onHandleCancelItemModal} setDocData={setDocData} id={null} />
                </Dialog>
            )}
            {openHeaderOrderModal && (
                <Dialog open={openHeaderOrderModal} title={'Header'} onHandleCancel={onHandleCancelHeaderModal}>
                    <Header data={null} onHandleCancel={onHandleCancelHeaderModal} id={null} />
                </Dialog>
            )}
            {openOrderModal && (
                <Dialog open={openOrderModal} title={'Template'} onHandleCancel={onHandleCancelModal}>
                    <Template data={null} onHandleCancel={onHandleCancelModal} id={null} />
                </Dialog>
            )}

            <Grid container item spacing={2} lg={12} sx={{ height: '95%' }} justifyContent='flex-start'>
                <Grid container item spacing={2} lg={12} justifyContent='flex-start'>
                    <AppBar
                        position='static'
                        elevation={0}
                        className='appbar'
                        style={{
                            marginBottom: 0,
                            borderBottom: '2px solid #1e1a22',
                            backgroundColor: '#232028',
                            color: '#131119',
                            alignItems: 'center',
                            flexDirection: 'start',
                            width: 'calc(100vw - 1px)',
                        }}>

                        {(
                            <Toolbar style={toolbarStyle} id="file_container">
                                <TextButton sx={{ ml: 1, mt: 1, padding: 1 }} onClick={handleSubmission} style={{ fontSize: 17, color: '#131119' }}>
                                    Upload invoice
                                </TextButton>
                                <TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) { }} style={{ fontSize: 17, color: '#131119' }}>
                                    Open invoice
                                </TextButton>
                                <TextButton sx={{ ml: 1, mt: 1 }} onClick={function (event) { }} style={{ fontSize: 17, color: '#131119' }}>
                                    Download invoice
                                </TextButton>

                            </Toolbar>
                        )}
                    </AppBar>
                </Grid>
                <Grid container item spacing={2} lg={12} style={{
                    color: '#131119',
                }} justifyContent='flex-start'>
                    <Grid container item lg={3} style={{
                        backgroundColor: '#131119',
                        minHeight: '91vh',
                        overflow: 'auto'

                    }} justifyContent='flex-start' alignContent='flex-start' className="page-container">
                        <Grid container item lg={12} justifyContent='flex-end' alignContent='flex-end'>
                            <TextButton sx={{ mr: 1, mt: 0, padding: 0 }} onClick={function (event) {
                                onHandleOpenModal()
                            }} style={{ fontSize: 17, color: '#131119' }}>
                                <FaPlus style={{ marginRight: 1, padding: 5 }} /> Add
                            </TextButton>

                        </Grid>
                        <ul className="x-navigation" >
                            {
                                templateList.map((t, index) => (
                                    <li key={t?.id || uuidv4()} className="active" onClick={function () { var tI = JSON.parse(JSON.stringify(t)); tI.bSelected = !tI.bSelected; setSelectedTemplate(tI); dispatch(expandTemplateItem(tI)) }}>
                                        <Grid style={{ background: (selectedTemplate.id === t.id ? '#282727' : '') }}>
                                            {!t.bSelected && <FaCaretRight style={{ color: "#5065af", marginTop: 0 }} />}
                                            {t.bSelected && <FaCaretDown style={{ color: "#5065af", marginTop: 0 }} />}
                                            {t.name}
                                        </Grid>
                                        {t.bSelected && <ul style={{ marginLeft: '20px', width: "calc(100% - 20px)" }}>
                                            <li onClickCapture={event => event.stopPropagation()}>
                                                <Grid ><Grid ><FaCaretDown style={{ color: "#5065af", marginTop: 0 }} />{template_type.find(u => u.id === Number(t.templateType))?.name}</Grid >
                                                    <ul style={{ marginLeft: '20px', width: "calc(100% - 20px)" }} onClickCapture={event => event.stopPropagation()}>

                                                        <li>
                                                            <Grid container item lg={12} sx={{ marginTop: 0, fontSize: '12px' }} justifyContent='flex-start' alignContent='flex-start'>
                                                                <Grid container item lg={3} style={{ backgroundColor: '#232028', fontSize: '12px', color: "#5065af" }}>
                                                                    <FaCaretRight style={{ color: "#5065af", marginTop: 0 }} />
                                                                    <span style={{ backgroundColor: '#232028', color: "#5065af", padding: 0, fontSize: '12px' }}> Page: </span>
                                                                </Grid>

                                                                <Grid container item lg={7} justifyContent='flex-start' alignContent='flex-start'>

                                                                    <Grid container item lg={12} style={{ backgroundColor: '#232028' }}>
                                                                        <TextField
                                                                            required
                                                                            lg={12}
                                                                            value={t.numPage}
                                                                            onChange={function (e) { var tI = JSON.parse(JSON.stringify(t)); tI.numPage = e.target.value; dispatch(expandTemplateItem(tI)) }}
                                                                            label=''
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        </li>
                                                        <li>
                                                            <Grid container item lg={12} sx={{ marginTop: 0 }} justifyContent='flex-start' alignContent='flex-start'>
                                                                <Grid container item lg={3} style={{ backgroundColor: '#232028', color: "#5065af" }}>
                                                                    <FaCaretRight style={{ color: "#5065af", marginTop: 0 }} />
                                                                    <span style={{ backgroundColor: '#232028', color: "#5065af", padding: 0, fontSize: '12px' }}> Width: </span>
                                                                </Grid>

                                                                <Grid container item lg={7} justifyContent='flex-start' alignContent='flex-start'>

                                                                    <Grid container item lg={12} style={{ backgroundColor: '#232028' }}>
                                                                        <TextField
                                                                            required
                                                                            lg={12}
                                                                            value={t.width}
                                                                            onChange={function (e) { var tI = JSON.parse(JSON.stringify(t)); tI.width = e.target.value; dispatch(expandTemplateItem(tI)) }}
                                                                            label=''
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        </li>
                                                        <li>
                                                            <Grid container item lg={12} sx={{ marginTop: 0 }} justifyContent='flex-start' alignContent='flex-start'>
                                                                <Grid container item lg={3} style={{ backgroundColor: '#232028', color: "#5065af" }}>
                                                                    <FaCaretRight style={{ color: "#5065af", marginTop: 3 }} />
                                                                    <span style={{ backgroundColor: '#232028', color: "#5065af", padding: 5, fontSize: '12px' }}> Height: </span>
                                                                </Grid>

                                                                <Grid container item lg={7} justifyContent='flex-start' alignContent='flex-start'>

                                                                    <Grid container item lg={12} style={{ backgroundColor: '#232028' }}>
                                                                        <TextField
                                                                            required
                                                                            lg={12}
                                                                            value={t.height}
                                                                            onChange={function (e) { var tI = JSON.parse(JSON.stringify(t)); tI.height = e.target.value; dispatch(expandTemplateItem(tI)) }}
                                                                            label=''
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        </li>
                                                        <li>
                                                            <Grid container item lg={12} sx={{ marginTop: 0 }} justifyContent='flex-start' alignContent='flex-start'>
                                                                <Grid container item lg={3} style={{ backgroundColor: '#232028', color: "#5065af" }}>
                                                                    <FaCaretRight style={{ color: "#5065af", marginTop: 3, fontSize: '12px' }} />
                                                                    <span style={{ backgroundColor: '#232028', color: "#5065af", padding: 5, fontSize: '12px' }}> Top: </span>
                                                                </Grid>

                                                                <Grid container item lg={7} justifyContent='flex-start' alignContent='flex-start'>

                                                                    <Grid container item lg={12} style={{ backgroundColor: '#232028' }}>
                                                                        <TextField
                                                                            required
                                                                            lg={12}
                                                                            value={t.top}
                                                                            onChange={function (e) { var tI = JSON.parse(JSON.stringify(t)); tI.top = e.target.value; dispatch(expandTemplateItem(tI)) }}
                                                                            label=''
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        </li>
                                                        <li>
                                                            <Grid container item lg={12} sx={{ marginTop: 0 }} justifyContent='flex-start' alignContent='flex-start'>
                                                                <Grid container item lg={3} style={{ backgroundColor: '#232028', color: "#5065af" }}>
                                                                    <FaCaretRight style={{ color: "#5065af", marginTop: 2, fontSize: '12px' }} />
                                                                    <span style={{ backgroundColor: '#232028', color: "#5065af", padding: 5, fontSize: '12px' }}> Left: </span>
                                                                </Grid>

                                                                <Grid container item lg={7} justifyContent='flex-start' alignContent='flex-start'>

                                                                    <Grid container item lg={12} style={{ backgroundColor: '#232028' }}>
                                                                        <TextField
                                                                            required
                                                                            lg={12}
                                                                            value={t.bottom}
                                                                            onChange={function (e) { var tI = JSON.parse(JSON.stringify(t)); tI.bottom = e.target.value; dispatch(expandTemplateItem(tI)) }}
                                                                            label=''
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>
                                                        </li>
                                                    </ul>
                                                </Grid>

                                            </li>

                                        </ul>
                                        }
                                        <TextButton sx={{ ml: 1, mt: 0 }} onClick={function (event) { }} style={{ fontSize: 17, height: '10px', color: '#131119' }}>

                                        </TextButton>
                                    </li>
                                ))
                            }
                        </ul>

                        <TextButton sx={{ ml: 1, mt: 0 }} onClick={function (event) { }} style={{ fontSize: 17, height: '50px', color: '#131119' }}>
                            Download Template
                        </TextButton>
                    </Grid>
                    <Grid container item lg={9} style={{ background: '#27232b', minHeight: '91vh' }} justifyContent='flex-start'>
                        <Grid justifyContent='flex-start' container item lg={7} className={bLoading ? 'rainbow' : ''} style={{ background: '#27232b', height: '91vh', overflow: (bLoading ? '' : 'auto'), minHeight: '91vh' }} id="xyz" >
                            {bLoading && (
                                <Grid container item spacing={2} lg={8} >

                                    <div id="container">
                                        <span className="first"></span>
                                        <span className="second"></span>
                                    </div>
                                </Grid>
                            )}
                            {!bLoading &&
                                <RectangleSelection
                                    onSelect={(e, coords) => {
                                        cordinates = coords
                                    }}
                                    onMouseUp={(event, coords) => {
                                        if (!cordinates.origin[1]) {
                                            return;
                                        }
                                        var elem11 = document.getElementsByClassName('react-pdf__Page__textContent');
                                        if (elem11.length == 0) {
                                            return;
                                        }
                                        var pdfRenderer = document.getElementById('pdf-renderer');
                                        var pdfPageWrapper = document.getElementById('pdf-page-wrapper');
                                        var scT = pdfRenderer.scrollTop
                                        var scL = pdfRenderer.scrollLeft
                                        var pdfPTop = pdfPageWrapper.offsetTop
                                        var pdfPLeft = pdfPageWrapper.offsetLeft

                                        var top = ((cordinates.origin[1] < cordinates.target[1] ? cordinates.origin[1] : cordinates.target[1]))
                                        var left = ((cordinates.origin[0] < cordinates.target[0] ? cordinates.origin[0] : cordinates.target[0]))

                                        var bott = (cordinates.origin[1] > cordinates.target[1] ? cordinates.origin[1] : cordinates.target[1])
                                        var right = (cordinates.origin[0] > cordinates.target[0] ? cordinates.origin[0] : cordinates.target[0])

                                        console.log(`T: ${top - bott}  , ${pdfPTop}, ${top} `)
                                        console.log(`L: ${left - right}  , ${pdfPLeft}, ${left} `)
                                        var e = []
                                        var canvas = document.getElementsByClassName('react-pdf__Page__canvas');
                                        var ctx = null;
                                        if (canvas[0]) {
                                            ctx = canvas[0].getContext('2d');
                                        }
                                        console.log(canvas[0])
                                        console.log("ctx : ", ctx)
                                        ctx.beginPath();
                                        var x_o = (left - pdfPLeft - scL) //* pdfHeightWidth.w / canvas[0].offsetWidth ;
                                        var w_o = (right - left) //* pdfHeightWidth.w / canvas[0].offsetWidth ;
                                        var y_o = (top - pdfPTop - scT) // * pdfHeightWidth.h / canvas[0].offsetHeight;
                                        var h_o = (bott - top) //* pdfHeightWidth.h / canvas[0].offsetHeight;
                                        ctx.strokeStyle = "red";
                                        ctx.lineWidth = 1;
                                        ctx.rect(x_o, y_o, w_o, h_o);
                                        ctx.stroke();
                                        for (var i = 0; i < pdfData.length; i++) {
                                            var x = pdfData[i].l * elem11[0].offsetWidth / pdfHeightWidth.w;
                                            var y = pdfData[i].t * elem11[0].offsetHeight / pdfHeightWidth.h;
                                            var h = (pdfData[i].b - pdfData[i].t) * elem11[0].offsetHeight / pdfHeightWidth.h;
                                            var w = (pdfData[i].r - pdfData[i].l) * elem11[0].offsetWidth / pdfHeightWidth.w;
                                            if ((x_o < x) && (x_o + w_o > x + w) && (y_o < y) && (y_o + h_o > y + h)) {
                                                e.push(pdfData[i]);
                                            }

                                            if (ctx) {
                                                ctx.beginPath();

                                                ctx.strokeStyle = "black";
                                                ctx.lineWidth = 1;
                                                ctx.rect(x, y, w, h);
                                                ctx.stroke();
                                            }
                                        }


                                        console.log(e)
                                    }}
                                    onMouseDown={(e, coords) => {
                                        cordinates = {}
                                    }}
                                    style={{
                                        backgroundColor: "rgba(0,0,255,0.4)",
                                        borderColor: "blue"
                                    }}
                                > <DocViewer onClick={function (event) {
                                    // alert("clientX: " + event.clientX + " clientY: " + event.clientY + " offsetX: " + event.offsetX + " offsetY: " + event.offsetY + " pageX: " + event.pageX + " pageY: " + event.pageY)
                                }} style={{ width: "100%", height: "100%" }} pluginRenderers={DocViewerRenderers} documents={docs}
                                    config={{
                                        header: {
                                            disableHeader: true,
                                            disableFileName: true,
                                            retainURLParams: false
                                        }
                                    }} />
                                </RectangleSelection>
                            }
                        </Grid>
                        <Grid justifyContent='flex-start' alignContent='flex-start' container item lg={5} style={{ background: '#f5f5f8', minHeight: '91vh' }}>
                            {<Grid container item lg={12} sx={{ fontSize: '10px', overflow: 'auto', height: '47vh', border: '1px gray solid' }}>
                                {pdfData?.length > 0 && pdfData?.map(pData => (
                                    <Grid key={uuidv4()} container item lg={12} >
                                        <ul>

                                            <li>
                                                {pData.s} , {pData.x}
                                            </li>
                                            <li>
                                                Top-Left: {pData.t}, {pData.l}
                                            </li>
                                            <li>
                                                Bot-Right: {pData.b}, {pData.r}
                                            </li>
                                        </ul>
                                    </Grid>
                                ))
                                }
                            </Grid>
                            }

                            <Grid justifyContent='flex-start' sx={{ fontSize: '10px', mt: 0, overflow: 'auto', height: '41vh', border: '1px gray solid' }} container item lg={12} >

                                <TableContainer sx={{ height: "40vh" }}>
                                    <Table>
                                        {itemHeaders.length >= 7 && false && <TableHead>
                                            <TableRow sx={{ '& > *': { borderBottom: '1px solid gray', fontWeight: 'bold', fontSize: '10px !important', margin: 0, padding: '1px',  } }}>
                                                {
                                                    itemHeaders?.map((header, index) => (
                                                        <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px' }}>
                                                            <Typography variant='h7' >
                                                                <SelectField
                                                                    required
                                                                    value={header.slected}
                                                                    lg={12}
                                                                    onChange={function (event) {
                                                                        var tI = JSON.parse(JSON.stringify(header));
                                                                        tI.slected = event.target.value + "";
                                                                        dispatch(setItemHeader(tI))
                                                                    }}
                                                                    bNew={true}
                                                                    callBackForNew={function (data, itm) {
                                                                        var t = []
                                                                        data.forEach(function (element) {
                                                                            t.push(JSON.parse(JSON.stringify(element)))
                                                                        });
                                                                        dispatch(setItemHeaders1(t))
                                                                    }}
                                                                    label={""}
                                                                    options={itemHeaders1}
                                                                />
                                                            </Typography>
                                                        </TableCell>
                                                    ))
                                                }
                                            </TableRow>
                                        </TableHead>
                                        }
                                        <TableBody>
                                            {
                                                docData?.length > 0 && docData?.map((dData, index) => (
                                                    <TableRow key={uuidv4()} sx={{ '& > *': { borderBottom: '1px solid gray', fontSize: '10px !important', margin: 0, padding: '1px',  } }}>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[0]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[1]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[2]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[3]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[4]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[5]}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell style={{ margin: 0, padding: '3px' }} >
                                                            <Typography variant='h7' >
                                                                {dData[6]}
                                                            </Typography>
                                                        </TableCell>
                                                    </TableRow>
                                                ))
                                            }
                                        </TableBody>
                                    </Table>
                                </TableContainer>



                            </Grid>

                            <Grid justifyContent='flex-start' sx={{ fontSize: '10px', overflow: 'none', mt: -0, height: '3vh' }} container item lg={12} justifyContent="end">

                                <TextButton sx={{ mr: 2, mt: 0, padding: 0 }} onClick={function (event) {
                                    onHandleOpenItemModal();
                                    dispatch(setItemHeaders([]));
                                }} style={{ fontSize: 13, color: '#131119' }}>
                                    <span style={{ fontSize: 10, color: '#131119' }}> Continue...</span>
                                </TextButton>
                                {false && <TextButton sx={{ mr: 2, mt: 0, padding: 0 }} onClick={function (event) {
                                    onHandleOpenHeaderModal();
                                    dispatch(setItemHeaders([]));
                                }} style={{ fontSize: 13, color: '#131119' }}>
                                    <FaPlus style={{ marginRight: 1, padding: 0 }} /> <span style={{ fontSize: 10, color: '#131119' }}> Header</span>
                                </TextButton>
                                }
                                {false && <TextButton disabled={itemHeaders.length < 7 || docData?.length <= 0} sx={{ mr: 5, mt: 0, padding: 0 }} onClick={function (event) {
                                    exportItems(docData, itemHeaders)
                                }} style={{ fontSize: 15, color: (itemHeaders.length < 7 || docData?.length <= 0) ? 'gray' : '#131119' }}>
                                    <FaCloudDownloadAlt style={{ marginRight: 1, padding: 0 }} /> <span style={{ fontSize: 10 }}> Export</span>
                                </TextButton>
                                }
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>

            </Grid>
            {snackbar && (
                <Snackbar
                    open={!!snackbar}
                    message={snackbar.message}
                    type={snackbar.type}
                    onClose={onSnackbarHandleClose}
                />
            )}
        </Paper>
    );
}

export default LandingPage;
