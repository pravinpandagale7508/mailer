import { Fragment, useCallback, useEffect, useState } from 'react';
import React from 'react';

export const IFrame = (props) => {
   // console.log(props.iframe)
   const iframe = function () {
        return {
            __html: props.iframe
        }
    }
    return (
        <div>            
            <div dangerouslySetInnerHTML={iframe()} />
        </div>
    );
}

export default IFrame;