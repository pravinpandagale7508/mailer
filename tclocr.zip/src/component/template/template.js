import { useState, useCallback, useEffect } from 'react';
import { Grid, Button } from '@mui/material';
import { SelectField, TextField, MultilineField } from '../../style-guide';
import { useDispatch, useSelector } from 'react-redux';
import { template_type } from '../../constants/globleConstants'
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { addTemplate } from '../../reducers/templateSlicer';
import { Dialog, Snackbar } from '../../style-guide';
export const Template = props => {
    const dispatch = useDispatch();
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const { snackbar } = useSelector(state => state.snackbar);
    const { templateList } = useSelector(state => state.template);
    const [value, setValue] = useState(
        props.data
            ? {
                id: props.data.id,
                name: props.data.name,
                templateType: props.data.templateType,
                numPage: props.data.numPage,
                width: props.data.width,
                height: props.data.height,
                top: props.data.top,
                left: props.data.left,
            }
            : {
                id: null,
                name: null,
                templateType: null,
                numPage: null,
                width: null,
                height: null,
                top: null,
                left: null,
            },
    );

    const save = () => {
        value.id = templateList.length+1
        dispatch(addTemplate(value))
        
        props.onHandleCancel();

    };

    const update = () => {
        props.onHandleCancel();
    };
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        if (!isLoaded) {
            //getWarehouseList();
            // getPackages();
        }
    }, [dispatch, failedCallback]);


    return (
        <div>
            <Grid container item spacing={2}>
                <Grid container item spacing={2}>
                    {/*<SelectField
                        required
                        value={value.templateType}
                        lg={6}
                        onChange={event => setValue(prev => ({ ...prev, templateType: event.target.value }))}
                        label='Template'
                        options={template_type}
                    />*/}
                    <TextField
                        required
                        lg={12}
                        value={value.name}
                        onChange={event => setValue(prev => ({ ...prev, name: event.target.value }))}
                        label='Name'
                    />
                    {/*<TextField
                        required
                        lg={6}
                        value={value.numPage}
                        onChange={event => setValue(prev => ({ ...prev, numPage: event.target.value }))}
                        label='Page'
                        type='number'
                    />*/}
                </Grid>
                <Grid container item justifyContent='flex-end' lg={11}>
                    <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={props.data?.id ? update : save}>
                        Save
                    </Button>
                    <Button variant='contained' sx={{ mt: 2 }}  onClick={props.onHandleCancel}>
                        Cancel
                    </Button>
                </Grid>
            </Grid>
            {snackbar && (
                <Snackbar open={!!snackbar} message={snackbar.message} type={snackbar.type} onClose={onSnackbarHandleClose} />
            )}
        </div>
    );
};

export default Template;
