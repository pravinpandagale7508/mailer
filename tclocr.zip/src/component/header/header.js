import { useState, useCallback, useEffect } from 'react';
import { Grid, Button } from '@mui/material';
import { SelectField, TextField, MultilineField } from '../../style-guide';
import { useDispatch, useSelector } from 'react-redux';
import { template_type } from '../../constants/globleConstants'
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { setItemHeaders } from '../../reducers/templateSlicer';
import { Dialog, Snackbar } from '../../style-guide';
export const Header = props => {
    const dispatch = useDispatch();
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const { snackbar } = useSelector(state => state.snackbar);
    const { templateList } = useSelector(state => state.template);
    const [value, setValue] = useState(
        props.data
            ? {
                id: props.data.id,
                header1: props.data.header1,
                header2: props.data.header2,
                header3: props.data.header3,
                header4: props.data.header4,
                header5: props.data.header5,
                header6: props.data.header6,
                header7: props.data.header7,
            }
            : {
                id: null,
                header1: null,
                header2: null,
                header3: null,
                header4: null,
                header5: null,
                header6: null,
                header7: null,
            },
    );

    const save = () => {
        var t = [];
        t.push(value.header1);
        t.push(value.header2);
        t.push(value.header3);
        t.push(value.header4);
        t.push(value.header5);
        t.push(value.header6);
        t.push(value.header7);
        dispatch(setItemHeaders(t))
        
        props.onHandleCancel();

    };

    const update = () => {
        props.onHandleCancel();
    };
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        if (!isLoaded) {
            //getWarehouseList();
            // getPackages();
        }
    }, [dispatch, failedCallback]);


    return (
        <div>
            <Grid container item spacing={2}>
                <Grid container item spacing={2}>
                    <TextField
                        required
                        lg={6}
                        value={value.header1}
                        onChange={event => setValue(prev => ({ ...prev, header1: event.target.value }))}
                        label='Header-1'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header2}
                        onChange={event => setValue(prev => ({ ...prev, header2: event.target.value }))}
                        label='Header-2'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header3}
                        onChange={event => setValue(prev => ({ ...prev, header3: event.target.value }))}
                        label='Header-3'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header4}
                        onChange={event => setValue(prev => ({ ...prev, header4: event.target.value }))}
                        label='Header-4'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header5}
                        onChange={event => setValue(prev => ({ ...prev, header5: event.target.value }))}
                        label='Header-5'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header6}
                        onChange={event => setValue(prev => ({ ...prev, header6: event.target.value }))}
                        label='Header-6'
                    />
                    <TextField
                        required
                        lg={6}
                        value={value.header7}
                        onChange={event => setValue(prev => ({ ...prev, header7: event.target.value }))}
                        label='Header-7'
                    />
                </Grid>
                <Grid container item justifyContent='flex-end' lg={11}>
                    <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={props.data?.id ? update : save}>
                        Save
                    </Button>
                    <Button variant='contained' sx={{ mt: 2 }}  onClick={props.onHandleCancel}>
                        Cancel
                    </Button>
                </Grid>
            </Grid>
            {snackbar && (
                <Snackbar open={!!snackbar} message={snackbar.message} type={snackbar.type} onClose={onSnackbarHandleClose} />
            )}
        </div>
    );
};

export default Header;
