import { useState, useCallback, useEffect } from 'react';
import { Grid, Button } from '@mui/material';
import { SelectField, TextField, MultilineField } from '../../style-guide';
import { useDispatch, useSelector } from 'react-redux';
import { template_type } from '../../constants/globleConstants'
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { setItemHeaders, setDocData } from '../../reducers/templateSlicer';
import { Dialog, Snackbar } from '../../style-guide';
import { v4 as uuidv4 } from 'uuid';
import { uploadExtraData, uploadExtractedData} from '../../reducers/requestHandler';
import { ItemRow } from './ItemRow'
export const ItemTable = props => {
    const dispatch = useDispatch();
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const { snackbar } = useSelector(state => state.snackbar);
    const { mergeData, fileTable, templateList} = useSelector(state => state.template);
    const getObject = () => {
        var t = {};
        if (props.data?.length > 0) {

            for (var i = 0; i < props.data?.length; i++) {
                for (var j = 0; j < 7; j++) {
                    var key = i + "" + j
                    t[key] = props.data[i][j];
                }
            }
        }
        return t
    }
    const [value, setValue] = useState(props.data);
    
    
    const save = (index,d) => {
        dispatch(setDocData(value))
        for (var i = 0; i < value.length; i++) {
            var row = value[i];
            var key = row[0];
            var data = { hsCode: '', note: ''}
            if (row[row.length-2]) {
                data.hsCode = row[row.length-2]
            }
            if (row[value.length-1]) {
                data.note = row[row.length-1]
            }
           /* if (row[9]) {
                data.incoterms = row[9]
            }
            if (row[10]) {
                data.currency = row[10]
            }*/
            var obj = {
                key: key,
                data: JSON.stringify(data)
            }
            var callBack = function () {}
            if (i == value.length - 1) {
                callBack = function () {
                    dispatch(snackbarToggle({ type: 'success', message: 'Data added successfully' }));
                }
            }
            uploadExtraData(dispatch, obj, callBack, function () {

            })
        }
        var extractedData = {
            items: mergeData,
            templateItems: templateList,
            headers:[]
        }
        var dataToSave = {
            id: fileTable.id,
            data: JSON.stringify(extractedData)
        }
        uploadExtractedData(dispatch, dataToSave, function () { dispatch(snackbarToggle({ type: 'success', message: 'ExtractedData added successfully' })); }, function () {

        })
        props.onHandleCancel();

    };

    const update = (index, d) => {
        var t = [];
        for (var i = 0; i < value.length; i++) {
            if (i == index) {
                t.push(JSON.parse(JSON.stringify(d)))
            } else {
                t.push(JSON.parse(JSON.stringify(value[i])))
            }
        }
        setValue(t)
    };
    const [test, setText] = useState("");
    const [isLoaded, setIsLoaded] = useState(false);
    useEffect(() => {
        
    }, [dispatch, failedCallback]);

    const p = (
        value?.length > 0 && value?.map((dData, index) => (<Grid  key={uuidv4()} container item spacing={1} lg={12}>
            <ItemRow data={dData} index={index} callback={update} />
        </Grid>))
    )
    return (
        <div>
            <Grid container item spacing={2} >
                { p}
                <Grid container item justifyContent='flex-end' lg={11} sx={{  ml: 12 }}>
                    <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={save}>
                        Save
                    </Button>
                    <Button variant='contained' sx={{ mt: 2, mr: -2  }}  onClick={props.onHandleCancel}>
                        Cancel
                    </Button>
                </Grid>
            </Grid>
            
        </div>
    );
};

export default ItemTable;
