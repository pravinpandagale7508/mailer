import { useState, useCallback, useEffect } from 'react';
import { Grid, Button, Box } from '@mui/material';
import { SelectField, TextField, MultilineField } from '../../style-guide';
import { useDispatch, useSelector } from 'react-redux';
import { template_type } from '../../constants/globleConstants'
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { setItemHeaders, setDocDataItem } from '../../reducers/templateSlicer';
import { Dialog, Snackbar } from '../../style-guide';
import { FaPen, FaCheck, FaEdit, FaPenSquare } from "react-icons/fa";
export const ItemRow = props => {
    const dispatch = useDispatch();
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const { snackbar } = useSelector(state => state.snackbar);
    const { templateList } = useSelector(state => state.template);
    const getObject = () => {
        var t = {
            hsCode:"",
            note:"",
        };
        if (props.data?.length > 0) {
            for (var i = 0; i < props.data?.length; i++) {
                var key = "header" + i
                if (i == props.data?.length - 2) {
                    key = "hsCode";
                }
                if (i == props.data?.length - 1) {
                    key = "note";
                }
                t[key] = props.data[i];
            }
        }
        return t
    }
    const [value, setValue] = useState(getObject());

    const save = () => {
        var t = [];
        var ks = Object.keys(value);
        for (var i = 0; i < props.data?.length; i++) {
            var key = "header" + i
            if (i == props.data?.length - 2) {
                key = "hsCode";
            }
            if (i == props.data?.length - 1) {
                key = "note";
            }            
            t.push(value[key]);
        }
        props.callback(props.index,t);

    };

    const getHeaderLable = (index) => {
        if (index == props.data?.length - 2) {
            return "HsCode";
        }
        if (index == props.data?.length - 1) {
            return "Note";
        }
       return  'Header-' + (index + 1)
    }
    const update = () => {
        props.onHandleCancel();
    };
    const [isLoaded, setIsLoaded] = useState(false);
    const [isDisabled, setIsDisabled] = useState(true);
    useEffect(() => {
        if (!isLoaded) {
            //getWarehouseList();
            // getPackages();
        }
    }, [dispatch, failedCallback]);


    return (
        <Grid container item spacing={1} lg={12}>
            {props.data?.length > 0 && props.data?.filter(function (obj,ind) {
                return ind < props.data?.length - 2;
            }).map((dData, index) => (
                <TextField
                    color={'#232028'}
                    lg={(index==2)?2:1.2}
                    value={value["header" + index]}
                    onChange={event => setValue(prev => ({ ...prev, ["header" + index]: event.target.value }))}
                    label={getHeaderLable(index)}
                    onBlur={save}
                />
            ))
            }

            <TextField
                color={'#232028'}
                lg={1}
                value={value.hsCode}
                onChange={event => setValue(prev => ({ ...prev, hsCode: event.target.value }))}
                label='HS code'
                onBlur={save}
            />
            <TextField
                color={'#232028'}
                lg={1.5}
                value={value.note}
                onChange={event => setValue(prev => ({ ...prev, note: event.target.value }))}
                label='Note'
                onBlur={save}
            />
            {snackbar && (
                <Snackbar open={!!snackbar} message={snackbar.message} type={snackbar.type} onClose={onSnackbarHandleClose} />
            )}
        </Grid>

    );
};

export default ItemRow;
