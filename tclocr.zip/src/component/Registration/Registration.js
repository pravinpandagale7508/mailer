﻿/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
/* eslint-disable no-empty */
import { Fragment, useCallback, useEffect, useState } from 'react';
import React from 'react';
import { BrowserRouter as Router, Link, Route, Routes, useNavigate, useLocation } from 'react-router-dom';
import { v4 as uuidv4 } from 'uuid';
import { Button, Table, TableBody, TableContainer, Paper, Grid, Checkbox, FormControlLabel } from '@mui/material';
import { SelectField, TextField, MultilineField } from '../../style-guide';

import { REQUEST_ACTIONS, sendRequest, setCookie, getCookie } from '../../utils/Communicator';
import { useDispatch, useSelector } from 'react-redux';
import { getSession, setLanguages, onLanguageChange, setPackages, selectPackage, setShipping_list } from '../../reducers/user-reducers/UserSlicer';
import { login, register, getShippingRequestList } from '../../reducers/requestHandler';
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { Dialog, Snackbar } from '../../style-guide';
import { FaEye, FaEyeSlash, FaCircle } from "react-icons/fa";


export const Registration = (props) => {
    const { setIsActivateUser, setIsChangePass, isLogin, setIsLogin, setIsRegister, setIsForgot, get_shipping_list_count, setIsPersonal } = props;

    const { snackbar } = useSelector(state => state.snackbar);
    const navigate = useNavigate();
    const onSnackbarHandleClose = () => dispatch(snackbarToggle(false));
    const [value, setValue] = new useState({
        userName: "",
        password: "",
        email: "",
        mobile: "",
    });

    const [userName, setUserName] = new useState("");
    const [password, setPassword] = new useState("");
    const [rememberMe, setRememberMe] = new useState(true);
    const [session, setSession] = new useState(getCookie("SESSION_ID"));
    const [isEnable, setEnabled] = new useState(true);
    const [isPackageLoaded, setPackageLoaded] = new useState(false);
    const [isEye, setIsEye] = new useState(true);
    const [hasError, setHasError] = new useState(false);
    const dispatch = useDispatch();
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const [isLoaded, setIsLoaded] = useState(true);

    const goTo = (e) => {
    }
    const keyPressed = (e) => {
        if (e.keyCode === 13) {
            doLogin();
        }
    }
    const doLogin = () => {
        if (rememberMe) {
            setCookie("REMEMBER_USER_NAME", userName, 30);
            setCookie("REMEMBER_USER_PASSWORD", password, 30);
        } else {
            setCookie("REMEMBER_USER_NAME", "", 30);
            setCookie("REMEMBER_USER_PASSWORD", "", 30);
        }
        //login = (dispatch, data, callback)
        login(dispatch, { userName: userName, password: password, opcode: "login" }, function (response) {
            if (response.status === 1) {
                setCookie("SESSION_ID", response.session, 30);


                setIsLogin(true)
                //  ping();
            } else {
                dispatch(snackbarToggle({ type: 'error', message: "Invalid login credentials." }));
            }
        });

    }
    const registerUser = () => {
        
        //login = (dispatch, data, callback)
        register(dispatch, { userName: value.userName, password: value.password, email: value.email, mobile: value.mobile, opcode: "register" }, function (response) {
            if (response.status === 1) {
                setCookie("SESSION_ID", response.session, 30);
               

                setIsLogin(true)
                navigate("/");
                //  ping();
            } else {
                dispatch(snackbarToggle({ type: 'error', message: "Invalid login credentials." }));
            }
        });

    }
    useEffect(() => {
        var userNa = getCookie("REMEMBER_USER_NAME")
        var pass = getCookie("REMEMBER_USER_PASSWORD")
        if (userNa) {
            setUserName(userNa);
            setPassword(pass);
        } else {
            setUserName("");
            setPassword("");
        }
    }, []);
    return (

        <Grid container item sx={{ p: 5 }} lg={12} justifyContent="center">
            <Grid container item sx={{ p: 5 }} lg={7} justifyContent="center">

                <Grid container item lg={8} justifyContent="space-between" spacing={2}>
                    <Grid container item lg={12} justifyContent="center" >
                        {'Registration'}
                    </Grid>
                    <Grid container item lg={12} justifyContent="space-between">
                        <TextField
                            className='text-field'
                            required
                            lg={12}
                            dir="ltr"
                            value={value.userName}
                            onChange={event => {
                                setValue(prev => ({ ...prev, userName: event.target.value }));
                            }}
                            onBlur={() => { setUserName(userName?.trim()) }}
                            label='Username'
                        />
                    </Grid>
                    <Grid container item justifyContent='flex-end'>

                        <TextField
                            className='text-field'
                            required
                            lg={12}
                            dir="ltr"
                            value={value.password}
                            onChange={event => {
                                setValue(prev => ({ ...prev, password: event.target.value }));
                            }}
                            label='Password'
                            type={`${isEye ? 'password' : 'text'}`}
                            onKeyDown={e => keyPressed(e)}
                            parentClassName={'prefix-password'}
                        />
                        {/*<Grid container item lg={1} onClick={() => { setIsEye(!isEye) }} className="prefix-field" alignItems={'center'}>
                            {isEye
                                ? <FaEye style={{ fill: "#625252", width: "100%", height: "50%" }} />
                                : <FaEyeSlash style={{ fill: "#625252", width: "100%", height: "50%" }} />}
                        </Grid>*/}
                    </Grid>
                    <Grid container item lg={12} justifyContent="space-between">
                        <TextField
                            className='text-field'
                            required
                            lg={12}
                            dir="ltr"
                            value={value.email}
                            onChange={event => {
                                setValue(prev => ({ ...prev, email: event.target.value }));
                            }}

                            label='Email'
                        />
                    </Grid>
                    <Grid container item lg={12} justifyContent="space-between">
                        <TextField
                            className='text-field'
                            
                            lg={12}
                            dir="ltr"
                            value={value.mobile}
                            onChange={event => {
                                setValue(prev => ({ ...prev, mobile: event.target.value }));
                            }}
                            label='Mobile'
                        />
                    </Grid>
                </Grid>
                <Grid container item className='form-action' justifyContent="center" sx={{mt:2}}>
                    <Button disabled={!value.userName || !value.password || !value.email} variant='contained' onClick={() => registerUser()} >Register</Button>
                </Grid>

            </Grid>
        </Grid>
    );
}

export default Registration;