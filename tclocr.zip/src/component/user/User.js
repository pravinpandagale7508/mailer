import React, { useCallback, useEffect, useState } from 'react';
import './User.scss';
import { REQUEST_ACTIONS, sendRequest, setCookie, getCookie } from '../../utils/Communicator';
import { useDispatch, useSelector } from 'react-redux';
import { getSession, setLanguages, onLanguageChange, setPackages, selectPackage } from '../../reducers/user-reducers/UserSlicer';
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { URL, LANGUAGES } from '../../constants/global-constants';


export const User = () => {
    const user = useSelector(state => state.user);
    var c = user.user;
    const userInfo = new Map(Object.entries(user));
    const s = user;
    const [userName, setUserName] = new useState("");
    const [password, setPassword] = new useState("");
    const [session, setSession] = new useState(getCookie("SESSION_ID"));
    const [isEnable, setEnabled] = new useState(true);
    const [isPackageLoaded, setPackageLoaded] = new useState(false);
    const [hasError, setHasError] = new useState(false);
	const dispatch = useDispatch();
    const failedCallback = useCallback(message => dispatch(snackbarToggle({ type: 'error', message })), [dispatch]);
    const [isLoaded, setIsLoaded] = useState(true);
    const onLangChange = function (lang) {
        dispatch(onLanguageChange(lang.target.value))
    }

    dispatch(setLanguages(LANGUAGES))
    useEffect(() => {
        if (!user.userInfo.session) {
            ping();
           // getPackages();
        }
    }, [dispatch, failedCallback, user]);
    const doLogin = () => {
        setEnabled(false);
        setHasError(false);
        let loginObj = { "userName": userName, "password": password,opcode:"login" }
        sendRequest(URL.USER_HANDLER, REQUEST_ACTIONS.POST, loginObj, {
            successCallback: (response) => {
                
                if (response.misc.CODE === 1) {
                    setCookie("SESSION_ID", response.session, 30);
                    dispatch(getSession(response))
                  //  ping();
                } else {
                    setEnabled(true);
                    setHasError(true);
                }
            },
            failedCallback: error => {
                setEnabled(true);
                setHasError(true);
            }
        });
    }
    const logOut = () => {
        setEnabled(false);
        setHasError(false);
        let loginObj = { "sessionId": session, opcode: "logout" }
        sendRequest(URL.USER_HANDLER, REQUEST_ACTIONS.POST, loginObj, {
            successCallback: (response) => {

                if (response.misc.CODE === 1) {
                    setCookie("SESSION_ID", "", 30);
                    setEnabled(false);
                    setHasError(false);
                } else {
                    setEnabled(true);
                    setHasError(true);
                }
            },
            failedCallback: error => {
                setEnabled(true);
                setHasError(true);
            }
        });
    }
    const ping = () => {
        setEnabled(false);
        setHasError(false);
        let loginObj = { "session": session, opcode: "ping" }
        sendRequest(URL.USER_HANDLER, REQUEST_ACTIONS.POST, loginObj, {
            successCallback: (response) => {
                console.log(response)
                if (response.misc.CODE === 1) {
                    setCookie("SESSION_ID", response.session, 30);
                    dispatch(getSession(response))
                    if (!isPackageLoaded) {
                        getPackages();
                        setPackageLoaded(true);
                    }
                } else {
                    setEnabled(true);
                    setHasError(true);
                }
               
            },
            failedCallback: error => {
                setEnabled(false);
                setHasError(true);
            }
        });
    }

    const getPackages = () => {
        let loginObj = { "session": session, opcode: "listShippingRequest" }
        sendRequest(URL.SHIPPING_HANDLER, REQUEST_ACTIONS.POST, loginObj, {
            successCallback: (response) => {
                console.log(response)
                if (response.misc.CODE === 1) {
                    dispatch(setPackages(response.data))
                } else {
                    setEnabled(true);
                    setHasError(true);
                }

            },
            failedCallback: error => {
                setEnabled(false);
                setHasError(true);
            }
        });
    }

    const keyPressed = (e) => {
      if(e.keyCode === 13){
        doLogin();
      }
    }
    useEffect(() => {
        setIsLoaded(user);
    }, [user]);
    return (
        <div className="login-main-container">
            <div className="login-container">
                <div className="login-title">
                    <div className="login-title-strong"></div>
                    <div className="login-title-sub">Welcome To Redbox World. Enjoy...</div>
                </div>
                <div className="login_form"  >
                    <div className="login-label" hidden={!isEnable}>Username</div>
                    <input type="text" className="login-input" hidden={!isEnable} disabled={!isEnable} onChange={e => setUserName(e.target.value)} />
                    <div className="login-label password" hidden={!isEnable}>Password</div>
                    <input type="password" hidden={!isEnable} className="login-input" disabled={!isEnable} onKeyDown={e => keyPressed(e)} onChange={e => setPassword(e.target.value)} />
                    <div hidden={!isEnable}>
                        <button type="button" value="Login" disabled={!isEnable} className="login-button" onClick={doLogin}>
                            <span className="btn-label">Login</span>
                            {!isEnable &&
                                <em className="btn-loading" />
                            }
                        </button>
                    </div>
                    <div className="login-label" hidden={isEnable}>Firstname:  {user.userInfo.user.firstName}</div>
                    <div className="login-label" hidden={isEnable}>LastName:  {user.userInfo.user.lastName}</div>
                    <div className="login-label" hidden={isEnable}>Token:  {user.userInfo.user.token}</div>
                    <div className="login-label" hidden={isEnable}>userName:  {user.userInfo.user.userName}</div>
                    <div className="login-label" hidden={isEnable}>Current Language:  {user.currentLanguage}</div>
                    <select value={user.currentLanguage} onChange={onLangChange}>
                        {user.languages.map((option) => (
                            <option value={option}>{option}</option>
                        ))}
                    </select>
                    <button onClick={logOut}>LogOut</button>;

                    <div className="App">
                        <table>
                            <tr>
                                <th>HAWB</th>
                                <th>Num</th>
                                <th>Desc</th>
                            </tr>
                            {user.packages.map((val, key) => {
                                return (
                                    <tr key={key}>
                                        <td>{val.hawb}</td>
                                        <td>{val.numPackages}</td>
                                        <td>{val.shippingDesc}</td>
                                    </tr>
                                )
                            })}
                        </table>
                    </div>
                </div>
                <div className="login-error">{hasError && "Invalid login!"}</div>
            </div>
        </div>
    );
}

export default User;