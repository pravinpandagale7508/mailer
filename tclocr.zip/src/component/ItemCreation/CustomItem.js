
import { v4 as uuidv4 } from 'uuid';
import { useEffect, useState, useRef } from 'react';
import React from 'react';
import { RadioGroup, Radio, FormLabel, Box, FormControlLabel, Checkbox, Grid, Button, Paper, Table, TableHead, TableBody, TableContainer, TableCell, TableRow, Typography, } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import TextButton from '@mui/material/IconButton';
import { FaPlus,FaMinus, FaCaretRight, FaCaretDown, FaCloudDownloadAlt, FaLevelDownAlt } from "react-icons/fa";
import { Dialog, Snackbar, TextField} from '../../style-guide';
import { template_type } from '../../constants/globleConstants'
import { snackbarToggle } from '../../reducers/snackbarSlicer';
import { setItemHeaders, setItemCreation, setDocData } from '../../reducers/templateSlicer';;
export const CustomItemDlg = props => {
    const dispatch = useDispatch();
    const canvas = useRef();
    let ctx = null;
    // const navigate = useNavigate();
    const { mergeData, itemCreation, docData, docs, pdfHeightWidth } = useSelector(state => state.template);
    const getObject = () => {
        var t = {};
        if (itemCreation?.length > 0) {
            for (var i = 0; i < itemCreation?.length; i++) {
                for (var j = 0; j < itemCreation[i].length; j++) {
                    var key = i + "_" + j
                    t[key] = itemCreation[i][j];
                }
            }
        }
        return t
    }
    const [value, setValue] = useState(getObject());
    useEffect(() => {
        setValue(getObject())
    }, [itemCreation]);


    return (
        <Paper sx={{ width: '100%', overflow: 'none', maxHeight: '98.3vh' }}>
            <Dialog maxWidth={'xl'} sx={{ background: '#f5f5f8', minWidth: '80vw', maxWidth: '98vw !important', color: '#232028' }} open={props.open} title={'Item Creation'} onHandleCancel={props.onHandleCancel}>
                <Grid justifyContent='flex-start' alignItems='flex-start' container item lg={12} >
                    <Grid justifyContent='flex-start' container item lg={7} style={{ height: '80vh'}}>
                        {docs.length > 0 && <iframe src={docs[0].uri}
                            frameborder="0" style={{ "overflow": "hidden", "overflowX": "hidden", "overflowY": "hidden", "height": "100%", "width": "100%", "top": "0px", "left": "0px", "right": "0px", "bottom": "0px" }} height={Number(pdfHeightWidth.h)+30} width="100%" />
                        }
                    </Grid>
                    <Grid justifyContent='flex-start' container item lg={5} >
                        <TableContainer sx={{ maxHeight: '80vh'}}>
                            <Table sx={{ marginTop: 2, width: (itemCreation[0]?.length * 100) + 'px', maxHeight: (itemCreation.length * 20)+'px', overflow: 'auto'}}>
                                <TableBody sx={{ marginTop: 2}}>
                                    {itemCreation.length == 0 && <TableRow key={uuidv4()} sx={{ '& > *': { border: 'none', fontSize: '14px !important', margin: 0, padding: '10px',  } }}>
                                        <TableCell sx={{ cursor: 'pointer', border: 'none' }} key={uuidv4()} style={{ margin: 0, padding: '3px' }} >
                                            <FaPlus style={{ marginRight: 1, padding: 0 }} onClick={function () {
                                                dispatch(setItemCreation([[""]]))
                                            }} />
                                        </TableCell>
                                    </TableRow>
                                }
                                    {itemCreation.length >0 &&itemCreation.map((t, index) => (
                                        <TableRow key={uuidv4()} sx={{ '& > *': { border: 'none', fontSize: '14px !important', margin: 0, padding: '10px',  } }}>
                                            {t.map((t1, index1) => (
                                                <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px',minWidth:'100px !important', width: '100px', height: '50px', border:'none' }} >
                                                    <TextField
                                                        color={'#232028'}
                                                        lg={12}
                                                        value={value[index + "_" + index1]}
                                                        bBlur={ true}
                                                        onBlur={function (event) {
                                                            //setValue(prev => ({ ...prev, [index + "_" + index1]: event.target.value }))
                                                            var rowArr = [];
                                                            for (var i = 0; i < itemCreation?.length; i++) {
                                                                var cellArr = JSON.parse(JSON.stringify(itemCreation[i]));
                                                                for (var j = 0; j < itemCreation[i].length; j++) {
                                                                    var key = i + "_" + j
                                                                    if (index == i && index1 == j) {
                                                                        cellArr[j] = event.target.value;
                                                                    }
                                                                }
                                                                rowArr.push(cellArr)
                                                            }
                                                            dispatch(setItemCreation(rowArr))
                                                        }}
                                                    />
                                                </TableCell>
                                            ))
                                            }
                                            {index == 0 && <TableCell sx={{ cursor: 'pointer',border:'none' }}  key={uuidv4()} style={{ margin: 0, padding: '3px' }} >
                                                <FaPlus style={{ marginRight: 1, padding: 0 }} onClick={function () {
                                                    var t = []
                                                    for (var i = 0; i < itemCreation.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(itemCreation[i]));
                                                        var p1 = JSON.parse(JSON.stringify(itemCreation[i][0]));
                                                        p1 = ""
                                                        tI.push(p1)
                                                        t.push(tI)
                                                    }
                                                    //t.push(itemCreation[0])
                                                    dispatch(setItemCreation(t))
                                                }} />
                                            </TableCell>
                                            }
                                            {index > 0 && <TableCell sx={{ cursor: 'pointer',border:'none' }}  key={uuidv4()} style={{ margin: 0, padding: '3px' }} >
                                                <FaMinus style={{ marginRight: 1}} onClick={function () {
                                                    var t = []
                                                    for (var i = 0; i < itemCreation.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(itemCreation[i]));
                                                        t.push(tI)
                                                    }
                                                    t.splice(index, 1)
                                                    dispatch(setItemCreation(t))
                                                }} />
                                            </TableCell>
                                            }
                                        </TableRow>
                                    ))
                                    }
                                    <TableRow sx={{ '& > *': { border: 'none', fontSize: '14px !important', margin: 0, padding: '10px',  } }} onClick={function () {

                                    }}>

                                        {itemCreation.length > 0 && <TableCell sx={{ cursor: 'pointer', border: 'none' }} key={uuidv4()} style={{ margin: 0, padding: '3px' }} >
                                            <FaPlus style={{ marginRight: 1, padding: 0 }} onClick={function () {
                                                var t = []
                                                for (var i = 0; i < itemCreation.length; i++) {
                                                    var tI = JSON.parse(JSON.stringify(itemCreation[i]));

                                                    t.push(tI)
                                                }
                                                var row = JSON.parse(JSON.stringify(itemCreation[0]));
                                                for (var i = 0; i < row.length; i++) {
                                                    row[i] = "";
                                                }
                                                t.push(row)
                                                dispatch(setItemCreation(t))
                                            }}/>
                                        </TableCell>
                                        }
                                        {itemCreation.length>0&&itemCreation[0]?.filter(function (obj, ind) {
                                            return ind < itemCreation[0].length - 1;
                                        }).map((t1, index1) => (
                                            <TableCell key={uuidv4()} style={{ margin: 0, padding: '3px' }} sx={{ cursor: 'pointer', border: 'none' }}  >
                                                <FaMinus style={{ marginRight: 1, padding: 0 }} onClick={function () {
                                                    var t = []
                                                    for (var i = 0; i < itemCreation.length; i++) {
                                                        var tI = JSON.parse(JSON.stringify(itemCreation[i]));
                                                        tI.splice(index1 + 1, 1)
                                                        t.push(tI)
                                                    }
                                                    //t.push(itemCreation[0])
                                                    dispatch(setItemCreation(t))
                                                }} />
                                            </TableCell>
                                        ))
                                        }
                                    </TableRow>

                                </TableBody>
                            </Table>
                        </TableContainer>
                        
                    </Grid>
                </Grid>
                <Grid container item justifyContent='flex-end' lg={11} sx={{ ml: 12 }}>
                    <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                        props.onHandleCancel()
                        if (itemCreation.length == 0) {
                            return;
                        }
                        var t = [...docData]
                        t.push(itemCreation)
                        dispatch(setDocData(t))
                        props.handleMergeData(t)

                    }}>
                        Save
                    </Button>
                    <Button variant='contained' sx={{ mt: 2, mr: 2 }} onClick={function () {
                        dispatch(setItemCreation([[""]]))
                    }}>
                        Reset
                    </Button>
                </Grid>
            </Dialog>
        </Paper>
    );
}

export default CustomItemDlg;
