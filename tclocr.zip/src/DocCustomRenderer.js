import React from "react";
const DocCustomRenderer = ({ mainState }) => {
    if (!mainState.currentDocument) return null;
    console.log(mainState);
    return (
        <div id="my-png-renderer">
            <iframe id="asdf" src="{mainState.currentDocument.uri}">
            </iframe>
        </div>
    );
};
DocCustomRenderer.fileTypes = [
    "docx",
    "doc",
    "image/svg+xml",
    "svg",
    "jpeg",
    "image/jpg",
    "image/jpeg"
];
DocCustomRenderer.weight = 1;
const myCustomFileLoaderCode = () => {
    return <div>hello we are loding</div>;
};
DocCustomRenderer.fileLoader = ({
    documentURI,
    signal,
    fileLoaderComplete
}) => {
    myCustomFileLoaderCode()
        .then(() => {
            // Whenever you have finished you must call fileLoaderComplete() to remove the loading animation
            setTimeout(() => {
                fileLoaderComplete();
            }, 1000);
        })
        .cacth(() => {
            return <div>hello</div>;
        });
};
export default DocCustomRenderer;
