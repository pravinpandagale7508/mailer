import { memo } from 'react';

import { Grid, TextField } from '@mui/material';

const TextFieldWrapper = ({
    label,
    value,
    className,
    sx,
    onChange,
    onKeyDown,
    onBlur,
    readOnly,
    required,
    direction = "ltr",
    tabindex,
    placeholder,
    type,
    xs,
    sm,
    md,
    lg,
    endAdornment,
}) => {
    let inputProps = { sx: { fontSize: '0.8rem', padding: '0px', direction: direction, color:"black" } }

    if (type == 'number') {
        inputProps = { min: 0, sx: { fontSize: '0.8rem', padding: '0px', color: "black" } }
    }

    return (
        <Grid item xs={xs} sm={sm} md={md} lg={lg} className={className}>
            <TextField
                InputProps={{
                    readOnly,
                    ...inputProps,
                    endAdornment,
                }}
                error={required && (value == null || value == '')}
                required={required}
                placeholder={placeholder}
                tabIndex={tabindex}
                fullWidth
                direction={direction}
                size='small'
                type={type}
                label={label}
                value={value || ''}
                onChange={onChange}
                onBlur={onBlur}
                onKeyDown={onKeyDown}
                sx={{ ...sx, direction: direction, background: readOnly ? "#d5d5d5" : '' }}
                autoComplete="new-password"
            />
        </Grid>
    );
};

TextFieldWrapper.defaultProps = {
    label: '',
    value: '',
    className: '',
    placeholder: '',
    readOnly: false,
    required: null,
    endAdornment: null,
    xs: 12,
    sm: 6,
    md: 4,
    lg: 2,
};

export default memo(TextFieldWrapper);
