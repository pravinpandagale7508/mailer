import { memo } from 'react';

import { useEffect, useState, useRef } from 'react';
import { Grid, TextField, Box, Button } from '@mui/material';
import { FaWindowClose } from "react-icons/fa";

import TextButton from '@mui/material/IconButton';
const TextFieldWrapper = ({
    label,
    value,
    onBlur,
    bBlur,
    onChange,
    onKeyDown,
    readOnly,
    required,
    placeholder,
    type,
    color,
    xs,
    sm,
    md,
    lg,
    endAdornment,
}) => {
    let inputProps = { sx: { color: color ? color : '', border: '1px solid #484444', fontSize: '0.8rem', padding: '0px', background: (readOnly ? '#e4e1e7' : ''), cursor: (readOnly ? 'not-allowed' : 'auto') } }

    if (type == 'number') {
        inputProps = { min: 0, sx: { color: color ? color : '', border: '1px solid #484444', fontSize: '0.8rem', padding: '0px', background: (readOnly ? '#e4e1e7' : ''), cursor: (readOnly ? 'not-allowed' : 'auto') } }
    }
    const [value1, setValue1] = useState(value);
    useEffect(() => {
    }, [value1]);
    return (
        <Grid item xs={xs} sm={sm} md={md} lg={lg} justifyContent='flex-start' alignItems='end' container item>
            <Grid item lg={11.9}>
                <TextField
                    InputProps={{
                        readOnly,
                        ...inputProps,
                        endAdornment,
                    }}
                    InputLabelProps={{ sx: { color: color ? color : '', fontSize: '0.8rem' } }}
                    error={required && (value1 === null || value1 === '')}
                    required={required}
                    placeholder={placeholder}
                    fullWidth
                    size='small'
                    type={type}
                    label={label}
                    value={value1 || ''}
                    onChange={function (e) { setValue1(e.target.value); if (onChange) { onChange(e) } }}
                    onBlur={onBlur}
                    onKeyDown={onKeyDown}
                />
            </Grid>
            {type!='number' &&<Grid item lg={0.1} sx={{ marginLeft: -1, marginBottom: '5px' }}>
                <Button sx={{ display: 'flex', justifyContent: 'start', alignItems: 'start', height: "30px", minWidth: '30px !important', marginLeft: -2, marginTop: -2 }} color='secondary' onClick={function () {
                    setValue1("");
                    var e = { target: { value: '' } };
                    if (onChange) { onChange(e) }
                    if (bBlur) { onBlur(e); }
                }} >X</Button>
            </Grid>}
        </Grid>
    );
};

TextFieldWrapper.defaultProps = {
    label: '',
    value: '',
    placeholder: '',
    readOnly: false,
    required: null,
    endAdornment: null,
    xs: 12,
    sm: 6,
    md: 4,
    lg: 2,
};

export default memo(TextFieldWrapper);
