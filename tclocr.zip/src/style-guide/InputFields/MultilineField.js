import { memo } from 'react';

import { Grid, TextField } from '@mui/material';

const MultilineFieldWrapper = ({ sx, rows, label, value, onBlur, onChange, required, xs, sm, md, lg 
    ,endAdornment}) => {
    let inputProps = { sx: { color:  '#232028', border: '1px solid #484444', fontSize: '0.8rem', padding: '0px'} }

    
    return (
        <Grid item xs={xs} sm={sm} md={md} lg={lg} sx={sx} style={{color:"white"}}>
            <TextField
                InputProps={{
                    ...inputProps,
                    endAdornment,
                }}
                InputLabelProps={{ sx: { color:  '#232028', fontSize: '0.8rem' } }}
                fullWidth
                multiline
                rows={rows}
                label={label}
                value={value || ''}
                onChange={onChange}
                onBlur={onBlur}
                required={required}
            />
        </Grid>
    );
};

MultilineFieldWrapper.defaultProps = {
    rows: '',
    label: '',
    value: '',
    required: null,
    xs: 12,
    sm: 6,
    md: 4,
    lg: 2,
    sx: null
};

export default memo(MultilineFieldWrapper);
